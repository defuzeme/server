/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef STARTER_HPP
#define STARTER_HPP

#include <QStringList>
#include <QSplashScreen>
#include "cores.hpp"
#include "plugins.hpp"
#include "exception.hpp"

/** The start-up sequence.
  * It's displaying a splashscreen while loading CORES and static PLUGINS.
  *
  * The sequence:
  * - Set the applications general variables
  * - Display the splashscreen
  * - Create the CORES
  * - Call init() on each
  * - Create the PLUGINS
  * - Call init() on each
  * - Close the splashscreen
  * - Give control to the main window
  *
  *\attention CORES constructors are called with 1 arguments: the command line arguments.
  **/

class Starter : public QObject
{
	Q_OBJECT
public:
	Starter();
	~Starter();
	Cores*			loadCores();						///< Create, init and return all CORES.
	Plugins*		loadPlugins();						///< Create, init and return all PLUGINS.

private slots:
	void			message(const QString& msg) const;	///< Display message on splash screen

private:
	void			initializationError(Exception &e);	///< Show exception details

	Cores			*cores;
	Plugins			*plugins;
	QStringList		arguments;							///< The command line arguments.
	QSplashScreen	*splashScreen;
};

#endif // STARTER_HPP
