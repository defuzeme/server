/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef MAIN_HPP
#define MAIN_HPP

#include <QtCore/QString>
#include <QtCore/QDateTime>

const static QString gl_APPLICATION_NAME = "defuze.me";
const static QString gl_APPLICATION_VERSION = "0.5.7";
const static QString gl_ORGANIZATION_DOMAIN = "defuze.me";
const static QString gl_ORGANIZATION_NAME = "defuze.me";
const static QString gl_VERSION_CODENAME = "beta";

const static QString gl_API_HOSTNAME = "api.defuze.me";
//const static QString gl_API_HOSTNAME = "localhost:3000";
const static QString gl_PUSH_HOSTNAME = "push.defuze.me:8080";
//const static QString gl_PUSH_HOSTNAME = "localhost:8080";

const unsigned short gl_RC_PORT = 3456;
const unsigned short gl_AD_ASK_PORT = 3457;
const unsigned short gl_AD_REPLY_PORT = 3458;

#endif // MAIN_HPP
