/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef AUDIOEFFECT_HPP
#define AUDIOEFFECT_HPP

#include "audioeffectwidget.hpp"

namespace Audio
{
	class AudioEffect : public QObject
	{
		Q_OBJECT
	public:
		virtual void				apply(short *data, int len)=0;
		virtual	AudioEffectWidget	*getWidget()=0;
	protected:
		AudioEffect();
		AudioEffectWidget	*widget;
	};
}

#endif // AUDIOEFFECT_HPP
