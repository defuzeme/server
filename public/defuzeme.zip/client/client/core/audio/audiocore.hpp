/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef AUDIOCORE_HPP
#define AUDIOCORE_HPP

#include "core.hpp"
#include "thread.hpp"
#include <QList>
#include <QMap>
#include <QVector>
#include <QAudioDeviceInfo>
#include <QThread>
#include <QDateTime>

namespace Audio
{
	class AudioIO;
	class AudioDecoder;
	class AudioOutputDevice;
	class AudioMixer;
	class AudioOutputDevices;

	/** The main class handling Audio functions
	  ** This class inherit QThread to play send the audio to the AudioOutput inside a thread.
	  **/

	class AudioCore : public Thread, public Core
	{
		Q_OBJECT
	public:
		AudioCore(QStringList &arguments);
		~AudioCore();
		void							init(Cores *cores);
		void							aboutToQuit();
		QList<QAudioDeviceInfo>			availableDevices(QAudio::Mode mode) const;

		AudioDecoder					*newAudioDecoder(QString playerName);

		AudioMixer						*newAudioMixer(const QString& name = "", AudioIO *input = 0);

		AudioOutputDevice						*newAudioDevice(QAudioDeviceInfo device = QAudioDeviceInfo::defaultOutputDevice());
//		AudioOutputDevice						*getAudioOutputDevice(QString name);


		static QString					formatSeconds(int seconds);
		AudioMixer*						getMasterMixer();
		QList<AudioMixer*>&				getMixers();
		void							startCrossfade(AudioMixer* from, AudioMixer* to);
		void							stopCrossfade();
	signals:
		void							crossfadeFinished();

	private:
		void							initCodecs();
		void							run();

		AudioMixer*						masterMixer;
		bool							stopThread;
		int								nbDecoder;
		int								nbOutput;
		int								nbMixer;
		bool							crossfading;
		AudioMixer						*crossfadeFrom, *crossfadeTo;
		int								crossfadeFromVolume, crossfadeToVolume;
		QDateTime						crossfadeStart;
		Cores							*_cores;

		QList<AudioMixer*>							audioMixersList;
		QMap<QString, AudioOutputDevices*>			audioOutputDevices;
		QMap<QString, AudioMixer*>					audioMixers;

		QMap<QString, AudioDecoder*>				audioDecoders;
	};
}

#endif // AUDIOCORE_HPP
