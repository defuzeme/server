/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef AUDIOEFFECTVOLUME_HPP
#define AUDIOEFFECTVOLUME_HPP

#include "audioeffect.hpp"

namespace Audio
{
	class AudioEffectVolume : public AudioEffect
	{
		Q_OBJECT
	public:
		AudioEffectVolume();
		int&						volume();
		void						setVolume(int value);
		virtual void				apply(short *data, int len);
		double						levelToDB(double level);
		double						levelToRatio(double level);
		virtual	AudioEffectWidget	*getWidget();
	private:
		int		_volume, _oldVolume;
		double	l_level, r_level;
	signals:
		void setMixerWidgetVolume(int);
	};
}

#endif // AUDIOEFFECTVOLUME_HPP
