/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "audioio.hpp"
#include "audiooutputdevicethread.hpp"
#include <QDebug>

using namespace Audio;

AudioOutputDeviceThread::AudioOutputDeviceThread(QAudioDeviceInfo device) : input(0)
{
	_audioDevice = device;
	audioOutput = 0;
	_isStarted = false;
}

AudioOutputDeviceThread::~AudioOutputDeviceThread()
{
	quit();
	wait();
	if (audioOutput)
		audioOutput->stop();
}

bool	AudioOutputDeviceThread::isStarted()
{
	return _isStarted;
}

void	AudioOutputDeviceThread::changeFormat(QAudioFormat format)
{
	qDebug() << "Set format";
	_format = format;
	audioOutput = new QAudioOutput(_audioDevice, _format);
	connect(audioOutput, SIGNAL(stateChanged(QAudio::State)), SLOT(stateChanged(QAudio::State)));
	startThread();
}

void	AudioOutputDeviceThread::stateChanged(QAudio::State state)
{
//	qDebug() << "state changed: " << state;
	if (state == QAudio::IdleState)
	{
		// If audio output goes underrun (no available data) retry later!
		QTimer::singleShot(100, this, SLOT(startAudio()));
	}
}

QAudio::State	AudioOutputDeviceThread::state()
{
	if (audioOutput)
		return audioOutput->state();
	return QAudio::StoppedState;
}

void	AudioOutputDeviceThread::startThread()
{
	if (input)
	{
		qDebug() << "Start thread";
		start();
		QObject::moveToThread(this);
	}
}

void	AudioOutputDeviceThread::setInput(AudioIO *i)
{
	qDebug() << "setInput : " << i->getName();
	input = i;
}

void	AudioOutputDeviceThread::startAudio()
{
//	qDebug() << "StartAudio!";
	if (isStarted() && state() == QAudio::SuspendedState)
	{
		audioOutput->resume();
		qDebug() << "Device resume";
	}
	else if (isStarted() && state() != QAudio::ActiveState)
	{
		audioOutput->start(input);
//		qDebug() << "Device start : " << input->isOpen();
	}
	else
	{
		qDebug() << "Device not started !!!";
	}
}

void	AudioOutputDeviceThread::stopAudio()
{
	if (isStarted())
	{
		audioOutput->stop();
		qDebug() << "Device stop";
	}
}


void	AudioOutputDeviceThread::pauseAudio()
{
	if (isStarted())
	{
		audioOutput->suspend();
		qDebug() << "Device suspend";
	}
}

void  AudioOutputDeviceThread::run()
{
	audioOutput = new QAudioOutput(_audioDevice, _format);
	connect(audioOutput, SIGNAL(stateChanged(QAudio::State)), SLOT(stateChanged(QAudio::State)));
	_isStarted = true;
	exec();
}
