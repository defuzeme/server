/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef AUDIOEFFECTBALANCE_HPP
#define AUDIOEFFECTBALANCE_HPP

#include "audioeffect.hpp"

namespace Audio
{
	class AudioEffectBalance : public AudioEffect
	{
	public:
		AudioEffectBalance();
		virtual void				apply(short *data, int len);
		virtual	AudioEffectWidget	*getWidget();
		int&						balance();
	private:
		int		_balance;
	};
}

#endif // AUDIOEFFECTBALANCE_HPP
