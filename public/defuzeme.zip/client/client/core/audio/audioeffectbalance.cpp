/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "audioeffectbalance.hpp"
#include "audioeffectbalancewidget.hpp"
#include "math.h"

using namespace Audio;

AudioEffectBalance::AudioEffectBalance()
{
	_balance = 0;
	widget = 0;
}

int&	AudioEffectBalance::balance()
{
	return _balance;
}

void	AudioEffectBalance::apply(short *data, int len)
{
	for(int i = 0; i < (len / 2); i++)
	{
		if ((i % 2 && _balance < 0) || (_balance > 0 && i%2 == 0))
			data[i] *= ((10 - abs(_balance)) / 10.);
	}
}

AudioEffectWidget*	AudioEffectBalance::getWidget()
{
	if (!widget)
		widget = new AudioEffectBalanceWidget(this);
	return widget;
}
