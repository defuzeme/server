/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "audiomixer.hpp"
#include <QDebug>
#include "audioplayer.hpp"
#include "audioeffectvolume.hpp"
#include "audioeffectbalance.hpp"

using namespace Audio;

AudioMixer::AudioMixer(const QString& name, AudioIO *input)
{
	_isStarted = false;
	_name = name;
	_type = AudioMixerType;
	if (input)
	{
		audioInputs.insert(input->getName(), input);
		input->setOutput(this);
	}
	AudioEffect *volumeEffect = new  AudioEffectVolume();
	effects.insert("Volume", volumeEffect);
	AudioEffect *balanceEffect = new  AudioEffectBalance();
	effects.insert("Balance", balanceEffect);
	open(QIODevice::ReadWrite);
}


bool	AudioMixer::isStarted()
{
	return _isStarted;
}

void	AudioMixer::applyEffects(char *data, int len)
{
	foreach(AudioEffect *effect, effects)
	{
		effect->apply((short*)data, len);
	}
}

void	AudioMixer::addInput(AudioIO *input)
{
	audioInputs.insert(input->getName(), input);
	input->setOutput(this);
}

QMap<QString, AudioEffect*>&	AudioMixer::getEffects()
{
	return effects;
}

qint64	AudioMixer::writeData(const char *data, qint64 maxlen)
{
	Q_UNUSED(data);
	Q_UNUSED(maxlen);
	return 0;
}

qint64	AudioMixer::readData(char *data, qint64 maxlen)
{
	Q_UNUSED(data);
	Q_UNUSED(maxlen);
	return 0;
}

qint64	AudioMixer::readData(char *data, qint64 maxlen, AudioIO *from)
{
	AudioIO *input = getAudioInput(from);
	qint64 bytesRead = 0;

	if (input)
	{
		bytesRead = input->readData(data, maxlen, from);
		applyEffects(data, maxlen);
	}
	return bytesRead;
}

qint64 AudioMixer::bytesAvailable() const
{
	qint64 bAv = 0;
	return bAv;
}

AudioIO	*AudioMixer::getAudioInput(const AudioIO* output)
{
	foreach(AudioIO* input, audioInputs)
	{
		if (input->getOutputDevice(output) == output)
			return input;
	}
	return 0;
}

const AudioIO *AudioMixer::getOutputDevice(const AudioIO* output) const
{
	foreach(AudioIO* input, audioInputs)
	{
		if (input->getOutputDevice(output) == output)
			return output;
	}
	return 0;
}
