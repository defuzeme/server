/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef AUDIOIO_HPP
#define AUDIOIO_HPP

#include <QString>
#include <QIODevice>

namespace Audio
{
	enum IOType
	{
		InputDeviceType,
		OutputDeviceType,
		AudioMixerType,
		AudioPlayerType
	};

	class AudioIO : public QIODevice
	{
	public:
		IOType	getType() const;
		QString	getName() const;
		void	setOutput(AudioIO *output);

		virtual qint64	readData(char *data, qint64 maxlen, AudioIO *from)=0;
		virtual const AudioIO *getOutputDevice(const AudioIO* input) const=0;
		virtual AudioIO *getAudioInput(const AudioIO *output)=0;

	protected:
		AudioIO();

		virtual qint64	readData(char *data, qint64 maxlen)=0;
		virtual qint64	writeData(const char *data, qint64 maxlen)=0;

		AudioIO*	_output;
		QString		_name;
		IOType		_type;
	};
}

#endif // AUDIOIO_HPP
