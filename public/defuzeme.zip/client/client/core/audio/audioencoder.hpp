/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef AUDIOENCODER_HPP
#define AUDIOENCODER_HPP

#include "audioio.hpp"

namespace Audio
{
	class AudioEncoder : public AudioIO
	{
	public:
		AudioEncoder(AudioIO *input);

	protected:
		qint64	writeData(const char *data, qint64 maxlen);
		qint64	readData(char *data, qint64 maxlen);

	};
}

#endif // AUDIOENCODER_HPP
