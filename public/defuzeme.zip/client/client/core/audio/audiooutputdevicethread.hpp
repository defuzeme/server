/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef AUDIO_OUTPUT_DEVICE_THREAD_HPP
#define AUDIO_OUTPUT_DEVICE_THREAD_HPP

#include <QAudioOutput>
#include <QAudioDeviceInfo>
#include <QThread>
#include "audioio.hpp"
#include "thread.hpp"

namespace Audio
{
	class AudioOutputDevice;

	/**
	  ** This clas inherit QThread so it doesn't interfer with the UI.
	  ** It can only be instantiated by AudioOutputDevice
	  ** It use a QAudioOutput in pull mode
	  **/

	class AudioOutputDeviceThread : public Thread
	{
		Q_OBJECT
		friend class AudioOutputDevice;
	private slots:
		void				startAudio();
		void				stopAudio();
		void				pauseAudio();
		QAudio::State		state();
		void				stateChanged(QAudio::State);
		void				setInput(AudioIO *input);
		void				changeFormat(QAudioFormat);

	private:
		AudioOutputDeviceThread(QAudioDeviceInfo device = QAudioDeviceInfo::defaultOutputDevice());
		~AudioOutputDeviceThread();

		void				startThread();
		bool				isStarted();

		void				run();

		QAudioFormat		_format;
		QAudioOutput*		audioOutput;
		bool				_isStarted;
		QAudioDeviceInfo	_audioDevice;
		AudioIO				*input;
	};
}

#endif // AUDIO_OUTPUT_DEVICE_THREAD_HPP
