/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef AUDIOMIXER_HPP
#define AUDIOMIXER_HPP

#include "audioio.hpp"
#include <QMap>
#include <QStringList>
#include <QList>
#include "audioeffect.hpp"
#include "audiocore.hpp"

namespace Audio
{

	/**
	  ** This class must be instantiated by AudioCore::newAudioMixer(...)
	  **/

	class AudioMixer : public AudioIO
	{
		friend AudioMixer* AudioCore::newAudioMixer(const QString &name, AudioIO *input);

		Q_OBJECT
	public:
		void							addInput(AudioIO *input);
		bool							isStarted();

		qint64							bytesAvailable() const;

		QMap<QString, AudioEffect*>		&getEffects();

		qint64							readData(char *data, qint64 maxlen, AudioIO *from);
		AudioIO							*getAudioInput(const AudioIO *output);
		const AudioIO					*getOutputDevice(const AudioIO *input) const;

	signals:

	public slots:

	protected:
		qint64							writeData(const char *data, qint64 maxlen);
		qint64							readData(char *data, qint64 maxlen);
	private:
		AudioMixer(const QString& name, AudioIO *input);
		QMap<QString, AudioEffect*>		effects;
		QMap<QString, AudioIO*>			audioInputs;
		bool							_isStarted;
		void							applyEffects(char* data, int len);
	};
}

#endif // AUDIOMIXER_HPP
