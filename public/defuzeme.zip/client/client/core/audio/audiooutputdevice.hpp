/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef AUDIO_OUTPUT_HPP
#define AUDIO_OUTPUT_HPP

#include <QAudioOutput>
#include <QAudioDeviceInfo>
#include <QThread>
#include "audioio.hpp"
#include "audiocore.hpp"

namespace Audio
{
	class AudioCore;
	class AudioOutputDeviceThread;

	/**
	  ** This class represent an Output device.
	  ** It Contains a thread (AudioOutputDeviceThread) so the playing doesn't interfer with the UI.
	  ** This clas must be instantiated by AudioCore::newAudioDevice(...)
	  **/

	class AudioOutputDevice : public AudioIO
	{
		Q_OBJECT
		friend AudioOutputDevice* AudioCore::newAudioDevice(QAudioDeviceInfo device = QAudioDeviceInfo::defaultOutputDevice());
	public:
		~AudioOutputDevice();

		QAudio::State	state();
		bool			setFormat(QAudioFormat format);
		void			setInput(AudioIO *input);
		bool			isStarted();

		void			start();
		void			stop();
		void			pause();
		AudioIO *getAudioInput(const AudioIO *output);
		const AudioIO	*getOutputDevice(const AudioIO *input) const;
		qint64	readData(char *data, qint64 maxlen, AudioIO *from);

	signals:
		void			startAudio();
		void			stopAudio();
		void			pauseAudio();
		void			changeFormat(QAudioFormat format);
	protected:
		qint64	writeData(const char *data, qint64 maxlen);
		qint64	readData(char *data, qint64 maxlen);

	private:
		AudioIO						*input;
		AudioOutputDeviceThread		*audioThread;
		AudioOutputDevice(const QString& name, QAudioDeviceInfo device = QAudioDeviceInfo::defaultOutputDevice());
	};
}

#endif // AUDIO_OUTPUT_HPP
