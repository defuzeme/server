/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "audioencoder.hpp"

using namespace Audio;

AudioEncoder::AudioEncoder(AudioIO *input)
{
	Q_UNUSED(input);
}


qint64	AudioEncoder::writeData(const char *, qint64)
{
	return 0;
}

qint64	AudioEncoder::readData(char *, qint64)
{
	return 0;
}
