/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "cores.hpp"
#include "guicore.hpp"
#include "paramscore.hpp"
#include "dbcore.hpp"
#include "networkcore.hpp"
#include "audiocore.hpp"

Cores::Cores(QStringList &arguments)
{
	_db = new DB::DBCore(arguments);
	_params = new Params::ParamsCore(arguments);
	_audio = new Audio::AudioCore(arguments);
	_gui = new Gui::GuiCore(arguments);
	_net = new Network::NetworkCore(arguments);
}

Cores::~Cores()
{
	delete _net;
	delete _gui;
	delete _audio;
	delete _params;
	delete _db;
}

void Cores::init()
{
	_db->init(this);
	_params->init(this);
	_audio->init(this);
	_gui->init(this);
	_net->init(this);
}

void Cores::aboutToQuit()
{
	_net->aboutToQuit();
	_gui->aboutToQuit();
	_audio->aboutToQuit();
	_params->aboutToQuit();
	_db->aboutToQuit();
	deleteLater();
}

Gui::GuiCore* Cores::gui()
{
	return _gui;
}

DB::DBCore* Cores::db()
{
	return _db;
}

Network::NetworkCore* Cores::net()
{
	return _net;
}

Audio::AudioCore* Cores::audio()
{
	return _audio;
}

Params::ParamsCore* Cores::params()
{
	return _params;
}
