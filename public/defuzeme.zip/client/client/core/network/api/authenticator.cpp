#include "authenticator.hpp"
#include "logger.hpp"

using namespace Network;

Authenticator::Authenticator(NetworkCore& net) : network(net), authenticating(false)
{
	setParamsName("authenticator");
}

Authenticator::~Authenticator()
{
}

void	Authenticator::defineParams()
{
}

void	Authenticator::invalidate()
{
	setParameter("token", QVariant());
	getToken();
}

QVariantMap		Authenticator::getRadioInfo() const
{
	return getParameter("radio", QVariant()).toMap();
}

void	Authenticator::receiveResponse()
{
	if (reply->error())
	{
		QVariant data = network.apiParser().parse(reply->readAll());
		QString	error = data.toMap()["error"].toString();
		Logger::log(QString("Authenticator: can't authenticate: %1").arg(reply->errorString()));
		password.clear();
		setParameter("token", QVariant());
		emit failed(error);
	}
	else
	{
		QVariant data = network.apiParser().parse(reply->readAll());
		setParameter("token", data.toMap()["token"].toString());
		setParameter("radio", data.toMap()["radio"].toMap());
		Logger::log(QString("Authenticator: new token received: %1").arg(getParameter("login").toString()));
		commitParameters();
		emit authenticated();
	}
	authenticating = false;
	reply->deleteLater();
}

void	Authenticator::authenticate(const QString& login, const QString& password)
{
	QNetworkRequest	request;
	QVariantMap		data;

	// store login to autofill forms
	setParameter("login", login);
	this->password = password;
	setParameter("token", "pending");

	// build POST data hash
	data["login"] = login;
	data["password"] = password;

	// create request
	request = network.apiRequest("session");

	Logger::log(QString("Authenticator: authenticating user %1").arg(login));

	// send request to web service
	reply = network.web().post(request, network.apiParser().serialize(data));

	// handle events
	connect(reply, SIGNAL(finished()), SLOT(receiveResponse()));
}

void	Authenticator::cancel()
{
	if (getParameter("token", "").toString() == "pending")
		reply->abort();
	setParameter("token", QVariant());
	authenticating = false;
	Logger::log("Authenticator: authentication cancelled by user");
}

const QString	Authenticator::getToken()
{
	if (!hasToken() && 	!authenticating)
	{
		authenticating = true;
		// Try to authenticate if no token is stored
		if (getParameter("login", "").toString().length() == 0 || password.length() == 0)
		{
			// If we need some credentials, ask them to the user
			// Change the token to a fake value not to request credentials several times
			emit needCredentials(getParameter("login", "").toString());
		}
		else
		{
			// If we have cached credentials, just use them
			// Change the token to a fake value not to request token several times
			authenticate(getParameter("login", "").toString(), password);
		}
	}
	// Remember token fetching is asynchronous, so is no token is stored
	// getToken will never return it synchronously
	return getParameter("token", "").toString();
}

bool	Authenticator::hasToken() const
{
	return getParameter("token", "").toString().length() > 0;
}


