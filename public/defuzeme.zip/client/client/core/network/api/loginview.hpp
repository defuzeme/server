#ifndef LOGINVIEW_H
#define LOGINVIEW_H

#include <QWidget>
#include <QCloseEvent>

namespace Ui {
	class LoginView;
}

namespace Network {
	/** This is the authentication window displayed by the authenticator
	  * to querry the user's credentials
	  **/

	class LoginView : public QWidget
	{
		Q_OBJECT

	public:
		explicit LoginView(const QString& login);
		~LoginView();

	signals:
		void	authenticate(const QString& login, const QString& password);
		void	cancelled();

	protected:
		void	closeEvent(QCloseEvent *event);

	private slots:
		void	on_button_connect_clicked();
		void	on_button_postpone_clicked();
		void	on_button_cancel_clicked();
		void	login_failed(const QString error);
		void	login_sucess();
		void	on_password_field_textChanged(QString );
		void	on_login_field_textChanged(QString );

		void on_password_field_returnPressed();

	private:
		void	clear_controls();
		bool	success;
		Ui::LoginView *ui;
	};
}

#endif // LOGINVIEW_H
