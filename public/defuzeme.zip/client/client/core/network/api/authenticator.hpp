/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

namespace Network {
	class Authenticator;
}

#ifndef AUTHENTICATOR_HPP
#define AUTHENTICATOR_HPP

#include <QString>
#include "networkcore.hpp"
#include "dbcore.hpp"
#include "main.hpp"
#include "parameterizable.hpp"

namespace Network
{
	/** This class is used by the NetworkCore to handle and maintaing authentication informations for the webservice API
	  *
	  * You should not instantiate it, the networkCore contain one.
	  * The networkCore will automatically call this class to fill API auth informations
	  * If the authenticator need credentials, it will emit needCredentials event so the receiver can fills required credentials and call back authenticate()
	  **/

	class Authenticator : public Params::Parameterizable
	{
		Q_OBJECT
	public:
		Authenticator(NetworkCore& net);
		~Authenticator();
		const QString	getToken();
		bool			hasToken() const;
		QVariantMap		getRadioInfo() const;

	public slots:
		void			authenticate(const QString& login, const QString& password);
		void			cancel();										///< Cancel the authentication request and clear the token
		void			invalidate();									///< Destroy token and query a new one

	private slots:
		void			receiveResponse();

	signals:
		void			failed(const QString& message);					///< Emited if the server rejected the authentication
		void			authenticated();								///< Emited after the authenticator sucessfully received a new token
		void			needCredentials(const QString& login);			///< Emited when the authenticator need credentials

	private:
		void			defineParams();

		NetworkCore&	network;										///< Keep a reference on the network core to send requests
		QString			password;										///< Keep the password cached no to ask it every time to the user
		QNetworkReply	*reply;
		bool			authenticating;
	};
}

#endif // AUTHENTICATOR_HPP
