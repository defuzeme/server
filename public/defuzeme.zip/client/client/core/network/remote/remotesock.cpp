/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include <QHostAddress>
#include "remotesock.hpp"
#include "logger.hpp"
#include "status.hpp"

using namespace Network;

RemoteSock::RemoteSock(QTcpSocket *sock) : sock(sock)
{
	connect(sock, SIGNAL(disconnected()), SLOT(deleteLater()));
	connect(sock, SIGNAL(readyRead()), SLOT(receive()));
	nextEventId = 1;
}

RemoteSock::~RemoteSock()
{
	sock->deleteLater();
}

QString		RemoteSock::ip() const {
	return sock->peerAddress().toString();
}

int			RemoteSock::port() const {
	return sock->peerPort();
}

const Parser&		RemoteSock::eventParser() const
{
	static JsonParser	parser;
	return parser;
}

RemoteEvent&	RemoteSock::newEvent(const QString& name)
{
	RemoteEvent	*event = new RemoteEvent(this);

	event->uid = nextEventId;
	event->event = name;
	nextEventId++;
	return *event;
}

void			RemoteSock::sendEvent(RemoteEvent *event)
{
	sock->write(event->toStream());
}

const QString&	RemoteSock::getToken() const
{
	return token;
}

const QString&	RemoteSock::getDevice() const
{
	return device;
}

const QString&	RemoteSock::getVersion() const
{
	return version;
}

void			RemoteSock::receive()
{
	int			split;

	buffer += sock->readAll();
	while ((split = buffer.indexOf('\0')) >= 0)
	{
		qDebug() << "received event (" + QString::number(split) + "): " + buffer.left(split);
		RemoteEvent	event(this, buffer.left(split));

		buffer.remove(0, split+1);
		if (event.isReply())
		{
			RemoteEvent	*request = event.getRequest();
			if (request)
			{
				emit request->receiveReply(event);
				events.remove(request->getUid());
				delete request;
			}
			else
			{
				Logger::log(QString("Remote: bad event reply id received: %1").arg(event.getRequestId()));
			}
		}
		else
		{
			emit receiveEvent(event);
		}
	}
}
