/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

namespace Network {
	class RemoteSock;
}

#ifndef REMOTESOCK_HPP
#define REMOTESOCK_HPP

#include <QObject>
#include <QTcpSocket>
#include "remoteevent.hpp"
#include "parser.hpp"

namespace Network
{
	/** The RemoteSock class represents a remote connection from the mobile application.
	  *
	  * It will handle json events formating & automatic message id attribution.
	  * It will also protect the socket from injections and bad formatted data.
	  **/
	class RemoteSock : public QObject
	{
		friend class Doorman;
		friend class RemoteEvent;

		Q_OBJECT
	public:
		RemoteSock(QTcpSocket *sock);
		~RemoteSock();
		QString			ip() const;
		int				port() const;
		RemoteEvent&	newEvent(const QString& name);		///< Generate a new event linked to this client
		void			sendEvent(RemoteEvent *event);		///< Send a prepared event
		const Parser&	eventParser() const;				///< Return correct event parser
		const QString&	getToken() const;
		const QString&	getDevice() const;
		const QString&	getVersion() const;

	signals:
		void			receiveEvent(const RemoteEvent&);	///< This signal is emited when a new event is received and parsed

	public slots:
		void			receive();							///< This slot is called when data is received

	private:
		QTcpSocket		*sock;								///< Stores the tcp socket
		QString			token, device, version;				///< Stores informations on the device
		QByteArray		buffer;								///< Stores pending data chunks
		unsigned		nextEventId;						///< Autoincremented event id
		QMap<unsigned, RemoteEvent*>	events;				///< Stores all sent events
	};
}

#endif // REMOTESOCK_HPP
