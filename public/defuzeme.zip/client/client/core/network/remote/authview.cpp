#include "authview.hpp"
#include "ui_authview.h"

using namespace Network;

AuthView::AuthView(const RemoteEvent& event) :
	QWidget(0), ui(new Ui::AuthView), remote(event.getRemote()), msgid(event.getUid())
{
	accept = false;
	permanent = false;
	ui->setupUi(this);
	ui->device_name->setText(QString("%1 (defuze.me v%2)").arg(remote->getDevice(), remote->getVersion()));
	ui->device_ip->setText(remote->ip());
}

AuthView::~AuthView()
{
    delete ui;
}

void AuthView::closeEvent(QCloseEvent *close_event)
{
	emit answered(remote, msgid, accept, permanent);
	close_event->accept();
}

void AuthView::on_button_accept_clicked()
{
	accept = true;
	permanent = ui->permanent_check->isChecked();
	close();
}

void AuthView::on_button_reject_clicked()
{
	permanent = ui->permanent_check->isChecked();
	close();
}
