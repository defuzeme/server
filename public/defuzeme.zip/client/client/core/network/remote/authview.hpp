#ifndef AUTHVIEW_H
#define AUTHVIEW_H

#include <QWidget>
#include <QCloseEvent>
#include "remoteevent.hpp"

namespace Ui {
    class AuthView;
}

namespace Network {
	/** This is the autorization window displayed by the remote device doorman
	  * to querry the user's approval when a device is trying to connect
	  **/

	class AuthView : public QWidget
	{
		Q_OBJECT

	public:
		explicit AuthView(const RemoteEvent& event);
		~AuthView();

	protected:
		void	closeEvent(QCloseEvent *close_event);

	private slots:
		void	on_button_accept_clicked();
		void	on_button_reject_clicked();

	signals:
		void	answered(RemoteSock*, unsigned, bool, bool);	///< Signal emited when the user answer

	private:
		Ui::AuthView	*ui;
		bool			accept, permanent;						///< Stores what the use choosed
		RemoteSock		*remote;								///< Pointer to the remote device
		unsigned		msgid;									///< Authentication request message id
	};
}

#endif // AUTHVIEW_H
