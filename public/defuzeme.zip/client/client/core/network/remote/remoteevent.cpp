/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "remoteevent.hpp"

using namespace Network;

RemoteEvent::RemoteEvent(RemoteSock *remote, const QByteArray& packet) : remote(remote)
{
	if (packet.size() > 0)
	{
		QVariant	json = remote->eventParser().parse(packet);
		event = json.toMap()["event"].toString();
		uid = json.toMap()["uid"].toUInt();
		replyTo = json.toMap()["replyTo"].toUInt();
		if (json.toMap().contains("data"))
			data = json.toMap()["data"].toMap();
	}
	else
	{
		uid = 0;
		replyTo = 0;
	}
}

RemoteEvent::~RemoteEvent()
{
}

unsigned		RemoteEvent::getUid() const
{
	return uid;
}

bool			RemoteEvent::isReply() const
{
	return (getRequestId() > 0);
}

unsigned		RemoteEvent::getRequestId() const
{
	return replyTo;
}

RemoteSock*		RemoteEvent::getRemote() const
{
	return remote;
}

RemoteEvent*	RemoteEvent::getRequest() const
{
	return remote->events[getRequestId()];
}

const QString&	RemoteEvent::getEvent() const
{
	return event;
}

void			RemoteEvent::send()
{
	remote->sendEvent(this);
	deleteLater();
}

void			RemoteEvent::sendWithReply(const QObject *receiver, const char *method)
{
	connect(this, SIGNAL(receiveReply(const RemoteEvent&)), receiver, method);
	remote->events[getUid()] = this;
	remote->sendEvent(this);
}

void			RemoteEvent::setData(const QVariantMap& data)
{
	this->data = data;
}

QVariant&		RemoteEvent::operator[](const QString& key)
{
	return data[key];
}

QVariant		RemoteEvent::operator[](const QString& key) const
{
	return data[key];
}

QByteArray		RemoteEvent::toStream() const
{
	QByteArray	out;
	QVariantMap	map;

	map["event"] = getEvent();
	map["uid"] = getUid();
	if (isReply())
		map["replyTo"] = getRequestId();
	if (!data.empty())
		map["data"] = data;
	out = remote->eventParser().serialize(map);
		out += '\0';
	return out;
}

RemoteEvent&	RemoteEvent::newReply(const QString& name) const
{
	RemoteEvent	&event = remote->newEvent(name);

	event.replyTo = this->uid;
	return event;
}

void			RemoteEvent::autoReply(AutoReplyType type) const
{
	if (type == OK)
		newReply("ok").send();
	if (type == NO_CHANGES)
		newReply("noChanges").send();
	if (type == ERROR)
		newReply("error").send();
}

