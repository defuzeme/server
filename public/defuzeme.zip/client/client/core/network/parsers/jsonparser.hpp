/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

namespace Network {
	class JsonParser;
}

#ifndef JSONPARSER_HPP
#define JSONPARSER_HPP

#include <QScriptEngine>
#include <QScriptValueIterator>
#include <QString>
#include "parser.hpp"

namespace Network
{
	/** This class implement Json parsing and generation using QScriptEngine
	  **/

	class JsonParser : public Parser
	{
	public:
		JsonParser();

		QVariant	parse(const QByteArray& data) const;
		QByteArray	serialize(const QVariant& data) const;

		static void	test();																	///< Perform some unit tests
	private:
		QVariant	partialParse(const QScriptValue& value) const;
		QByteArray	partialSerialize(const QVariant& value, const short spaces) const;

		QByteArray	join( const QList<QByteArray>& list, const QByteArray& sep) const;		///< This method allows to join QByteArray together
		QString		sanitizeString(const QString& input) const;								///< This method provide json string escaping
		QByteArray	indent(const short spaces) const;										///< This method return a blank QByteArray to indent easily
	};
}

#endif // JSONPARSER_HPP
