/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

namespace Network {
	class Parser;
}

#ifndef PARSER_HPP
#define PARSER_HPP

#include <QVariant>
#include <QByteArray>

namespace Network
{
	/** This abstract class handle generic data parsing. child classes must be instancied to process parsing (like JsonParser)
	  *
	  * The parse method generate a QVariant data structure from a byte stream and must be implemented by child classes
	  * The generate method generate a byte stream from a QVariant structure using underlying format implemented by child classes
	  **/

	class Parser
	{
	public:
		virtual QVariant	parse(const QByteArray& data) const = 0;
		virtual QByteArray	serialize(const QVariant& data) const = 0;
	};
}

#include "jsonparser.hpp"

#endif // PARSER_HPP
