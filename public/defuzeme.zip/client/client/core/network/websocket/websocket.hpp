/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

namespace Network {
	class WebSocket;
}

#ifndef WEBSOCKET_HPP
#define WEBSOCKET_HPP

#include <QTcpSocket>
#include <QUrl>
#include "webframe.hpp"

namespace Network
{
	/** This class is a C++/Qt implementation of the WebSocket 07 draft specifications
	  * http://tools.ietf.org/html/draft-ietf-hybi-thewebsocketprotocol-07
	  **/

	const QByteArray WebSocketSecret = "258EAFA5-E914-47DA-95CA-C5AB0DC85B11";

	class WebSocket : public QTcpSocket
	{
		Q_OBJECT
	public:
		explicit WebSocket(const QString& uri);
		~WebSocket();
		void		onMessage(const QObject* receiver, const char* method);
		void		onOpen(const QObject* receiver, const char* method);
		void		onClose(const QObject* receiver, const char* method);
		void		send(WebFrame& frame);

	signals:
		void		messageSignal(const QByteArray& data);
		void		openSignal();
		void		closeSignal(const QString& error);

	public slots:
		void		connect();

	private slots:
		void		errorSlot(QAbstractSocket::SocketError error);
		void		handshake();
		void		receive();

	private:
		void		generateToken();
		bool		validToken(const QByteArray& accept);
		bool		parseHandshake();
		bool		parseFrame();

		QUrl		uri;
		QByteArray	buffer;
		WebFrame*	frame;
		QVariantMap	header;
		QByteArray	token;
		bool		handshaking;
	};
}

#endif // WEBSOCKET_HPP
