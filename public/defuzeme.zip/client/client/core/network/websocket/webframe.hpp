/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

namespace Network {
	class WebFrame;
}

#ifndef WEBFRAME_HPP
#define WEBFRAME_HPP

#include <QByteArray>
#include <QString>
#include <QIODevice>

namespace Network {
	const qint64	MaxRead = 1 << 16;
	const int		MaxFrameSize = 1 << 16;

	/** This class is a part of the C++/Qt implementation of the WebSocket protocol
	  * It represents a network frame (sent or received)
	  * It supports frame concatenation, data masking, multiframe encoding
	  **/

	class WebFrame
	{
		enum OpCode {
			CONTINUATION = 0,
			TEXT = 1,
			BINARY = 2,
			CLOSE = 8,
			PING = 9,
			PONG = 10
		};

	public:
		WebFrame(const QByteArray &binary);
		WebFrame(const QString &text);
		static WebFrame*	fromStream(QIODevice* device);
		void				append(QIODevice* device);
		bool				complete() const;
		const QByteArray&	content() const;
		QByteArray			encoded();
		bool				isMultiFrame() const;
		int					remainingFrames() const;

	private:
		WebFrame();
		void				init(const QByteArray &data, bool masked = true);
		void				generateMask();
		void				applyMask(int until = -1);

		bool				fin;
		bool				rsv1, rsv2, rsv3;
		OpCode				opcode;
		bool				masked;
		qint64				length;
		QByteArray			mask;
		QByteArray			payload;
	};
}

#endif // WEBFRAME_HPP
