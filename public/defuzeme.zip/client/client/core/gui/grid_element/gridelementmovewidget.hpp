/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef GRIDELEMENTMOVEWIDGET_HPP
#define GRIDELEMENTMOVEWIDGET_HPP

#include <QLabel>

namespace Gui
{
	class GridElement;
	class Tab;

	/** The widget used to start dragging a Gui::GridElement.
	  **/

	class GridElementMoveWidget : public QLabel
	{
		Q_OBJECT
	public:
		explicit 	GridElementMoveWidget(QWidget *parent = 0);
		void		mousePressEvent(QMouseEvent *event);

	private:
		GridElement	*gridElement;
		Tab			*tab;

	signals:

	public slots:

	};
}

#endif // GRIDELEMENTMOVEWIDGET_HPP
