/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "gridelementmovewidget.hpp"
#include "gridelement.hpp"
#include "exception.hpp"
#include "gridwidget.hpp"
#include "tab.hpp"
#include <QMouseEvent>

using namespace Gui;

GridElementMoveWidget::GridElementMoveWidget(QWidget *parent) :
	QLabel(parent)
{
	setAcceptDrops(true);
	if (!(gridElement = dynamic_cast<GridElement*>(parent->parentWidget())))
		throw_exception(0x01, tr("Move widget parent must be a GridElement."));
	tab = gridElement->getGridWidget()->getTab();
}

void GridElementMoveWidget::mousePressEvent(QMouseEvent *event)
{
	if (event->button() == Qt::LeftButton)
	{
		QDrag *drag = new QDrag(this);
		QMimeData *mimeData = new QMimeData;
		mimeData->setData("application/x-defuzeme-gridelement", gridElement->getModule()->getUniqId().toUtf8());
		drag->setMimeData(mimeData);
		drag->setPixmap(QPixmap::grabWidget(gridElement).scaledToWidth(qMin(200, gridElement->width()),
																	   Qt::SmoothTransformation));
		tab->showDropLocations(gridElement->getPosition());
		drag->exec();
		tab->cleanGrid();
	}
}
