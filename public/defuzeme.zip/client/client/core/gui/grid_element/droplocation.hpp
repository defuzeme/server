/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef DROPLOCATION_HPP
#define DROPLOCATION_HPP

#include "ui_droplocation.h"

namespace Gui
{
	class Tab;

	/** The place where it's possible to drop a grid element.
	  * The widget will accept drop with mime-type 'application/x-defuzeme-gridelement'.
	  *
	  * \todo Document the data for the mime-type 'application/x-defuzeme-gridelement'
	  **/

	class DropLocation : public QWidget, private Ui::DropLocation
	{
		Q_OBJECT
	public:
		explicit DropLocation(Tab *tab,
							  QPoint targetPosition,
							  bool newColumn,
							  QWidget *parent = 0);
		void	dragEnterEvent(QDragEnterEvent *event);
		void	dragLeaveEvent(QDragLeaveEvent *event);
		void	dropEvent(QDropEvent *event);

	protected:
		void	changeEvent(QEvent *e);
		Tab		*tab;
		QPoint	targetPosition;
		bool	newColumn;
	};
}

#endif // DROPLOCATION_HPP
