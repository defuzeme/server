/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include <QDebug>
#include "gridelement.hpp"
#include "gridwidget.hpp"

using namespace Gui;

GridElement::GridElement(const QString &title, GridWidget *parent) :
	QWidget(parent), gridWidget(parent)
{
	setupUi(this);
	titleLabel->setText("<b>" + title + "</b>");
	paramsButton->hide();
}

void GridElement::showParams()
{
	//module->parametersCategory->show();
}

void GridElement::setModule(Module *module)
{
	this->module = module;
	this->setSizePolicy(module->colSizePolicy, module->sizePolicy);
	elementWidget->addWidget(module->getWidget());
	elementWidget->setStretch(1, 1);
	setPosition(module->getPosition());
//	if (module->hasParameters())
//	{
//		paramsButton->show();
//		connect(paramsButton, SIGNAL(clicked()), this, SLOT(showParams()));
//	}
}

Module *GridElement::getModule() const
{
	return module;
}

GridWidget *GridElement::getGridWidget() const
{
	return gridWidget;
}

int GridElement::getColumn() const
{
	return position.x();
}

void GridElement::setColumn(int column)
{
	setPosition(QPoint(column, position.y()));
}

int GridElement::getRow() const
{
	return position.y();
}

void GridElement::setRow(int row)
{
	setPosition(QPoint(position.x(), row));
}

const QPoint& GridElement::getPosition() const
{
	return position;
}

void GridElement::setPosition(QPoint position)
{
	this->position = position;
	//positionLabel->setText("(" + QVariant(position.x()).toString() + "," + QVariant(position.y()).toString() + ")");
}

void GridElement::changeEvent(QEvent *e)
{
	QWidget::changeEvent(e);
	switch (e->type()) {
	case QEvent::LanguageChange:
		retranslateUi(this);
		break;
	default:
		break;
	}
}
