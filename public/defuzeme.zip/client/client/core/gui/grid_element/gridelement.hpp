/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef GRIDELEMENT_HPP
#define GRIDELEMENT_HPP

#include "ui_gridelement.h"
#include "module.hpp"

namespace Gui
{
	class GridWidget;

	/** The visible elements inside tabs.
	  * - Contained in a Gui::GridWidget at defined column and row
	  * - Contains a Gui::Module
	  * - Can be drap&drop inside their Gui::GridWidget
	  * - Is always created by the Gui::GuiCore
	  **/

	class GridElement : public QWidget, private Ui::GridElement
	{
		Q_OBJECT
	public:
		explicit GridElement(const QString &title, GridWidget *parent = 0);
		void			setModule(Module *module);
		Module*			getModule() const;
		GridWidget*		getGridWidget() const;
		int				getColumn() const;
		void			setColumn(int column);
		int				getRow() const;
		void			setRow(int row);
		const QPoint&	getPosition() const;
		void			setPosition(QPoint position);

	protected:
		void			changeEvent(QEvent *e);
		Module			*module;
		GridWidget		*gridWidget;
		QPoint			position;

	public slots:
		void			showParams();
	};
}

#endif // GRIDELEMENT_HPP
