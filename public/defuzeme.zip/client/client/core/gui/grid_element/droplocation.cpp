/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "droplocation.hpp"
#include "modulefactory.hpp"
#include "gridelement.hpp"
#include "tab.hpp"
#include <QDragEnterEvent>
#include <QDragLeaveEvent>
#include <QDropEvent>

using namespace Gui;

DropLocation::DropLocation(Tab *tab, QPoint targetPosition, bool newColumn, QWidget *parent) :
	QWidget(parent), tab(tab), targetPosition(targetPosition), newColumn(newColumn)
{
	setupUi(this);
	setAcceptDrops(true);
}

void DropLocation::dragEnterEvent(QDragEnterEvent *event)
{
	if (event->mimeData()->hasFormat("application/x-defuzeme-gridelement"))
	{
		setStyleSheet("background-color:rgb(230, 255, 108);border-radius:2px;");
		event->accept();
	}
	else
		event->ignore();
}

void DropLocation::dragLeaveEvent(QDragLeaveEvent *event)
{
	setStyleSheet("background-color:rgba(200,200,200, 128);border-radius:2px;");
	event->accept();
}

void DropLocation::dropEvent(QDropEvent *event)
{
	if (event->mimeData()->hasFormat("application/x-defuzeme-gridelement"))
	{
		QString moduleId = QString::fromUtf8(event->mimeData()->data("application/x-defuzeme-gridelement"));
		Module* module = ModuleFactory::getModule(moduleId);
		GridElement *gridElement = tab->getGridElementByModule(module);
		tab->insertGridElement(gridElement, targetPosition, newColumn);
		event->accept();
		delete this;
	}
}

void DropLocation::changeEvent(QEvent *e)
{
	QWidget::changeEvent(e);
	switch (e->type()) {
	case QEvent::LanguageChange:
		retranslateUi(this);
		break;
	default:
		break;
	}
}
