/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef UICONFIGURATION_HPP
#define UICONFIGURATION_HPP

#include <QtGui/QDesktopWidget>
#include <QtGui/QApplication>

namespace Gui
{
	/** Store the screen(s) configuration used.
	  **/

	class UiConfiguration
	{
	public:
		UiConfiguration();

	private:
		void			_dump();
		QDesktopWidget	*desktop;
	};
}

#endif // UICONFIGURATION_HPP
