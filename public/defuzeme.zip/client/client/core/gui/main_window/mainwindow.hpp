/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef MAINWINDOW_HPP
#define MAINWINDOW_HPP

#include "tab.hpp"
#include "tabwidget.hpp"
#include <QtCore/QList>
#include <QtCore/QHash>
#include <QtGui/QMainWindow>

namespace Gui
{
	class GuiCore;

	/** The main window(s).
	  * Contain the menu, the tabs, and the modules grid.
	  * Up to 1 per screen.
	  **/

	class MainWindow : public QMainWindow
	{
		Q_OBJECT
	public:
		MainWindow(GuiCore *guiCore, QWidget *parent = 0);
		~MainWindow();
		void					addTab(Tab *tab, const QString &icon, bool active = false);			///< Add a new Tab to the window
		Tab						*currentTab();														///< Return the current tab
		TabWidget* 				getTabWidget() const;
		QList<Tab*>				getTabs() const;

	private:
		QList<Tab*>				tabs;
		QHash<QWidget*, Tab*>	gridsTabs;
		TabWidget				*tabWidget;
	};
}

#endif // MAINWINDOW_HPP
