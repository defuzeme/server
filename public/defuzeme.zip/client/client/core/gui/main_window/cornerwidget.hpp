/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef CORNERWIDGET_HPP
#define CORNERWIDGET_HPP

#include "ui_cornerwidget.h"
#include "about.hpp"
#include <QGraphicsDropShadowEffect>

namespace Gui
{
	class GuiCore;

	/** The top-left menu.
	  **/

	class CornerWidget : public QWidget, private Ui::CornerWidget
	{
		Q_OBJECT
		friend class TabWidget;
	public:
		explicit CornerWidget(GuiCore *guiCore, QWidget *parent = 0);

	protected:
		void changeEvent(QEvent *e);

	private slots:
		void on_fullscreenButton_clicked();
		void on_quitButton_clicked();
		void on_parametersButton_clicked();
		void on_aboutButton_clicked();

	private:
		GuiCore *guiCore;
		void setTextShadowEffects();
		void setTextShadow(QGraphicsDropShadowEffect *effect, QWidget *button);
		QGraphicsDropShadowEffect *parametersButtonEffect;
		QGraphicsDropShadowEffect *quitButtonEffect;
		QGraphicsDropShadowEffect *fullscreenButtonEffect;
		QGraphicsDropShadowEffect *helpButtonEffect;
		QGraphicsDropShadowEffect *aboutButtonEffect;
	};
}

#endif // CORNERWIDGET_HPP
