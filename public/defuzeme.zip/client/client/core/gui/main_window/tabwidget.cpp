/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "tabwidget.hpp"
#include <QTabBar>
#include "cornerwidget.hpp"
#include "mainwindow.hpp"
#include "guicore.hpp"

using namespace Gui;

TabWidget::TabWidget(GuiCore *guiCore, MainWindow *parent) : QTabWidget(parent)
{
	this->guiCore = guiCore;
	mainWindow = parent;
	menuWidget = new CornerWidget(guiCore);
	if (mainWindow->isFullScreen())
		menuWidget->fullscreenButton->setText(tr("Windowed"));
	setCornerWidget(menuWidget);
}

void TabWidget::paintEvent(QPaintEvent *)
{
}

void TabWidget::setDrawBase(bool enable)
{
	tabBar()->setDrawBase(enable);
}
