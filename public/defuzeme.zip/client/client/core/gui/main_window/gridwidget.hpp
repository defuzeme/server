/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef GRIDWIDGET_HPP
#define GRIDWIDGET_HPP

#include "ui_gridwidget.h"

namespace Gui
{
	class Tab;

	/** The only-one-in-a-tab Grid containing the Gui::GridElement.
	  * Contains an horizontal layout, which contains several vertical layouts.
	  **/

	class GridWidget : public QWidget, private Ui::GridWidget
	{
		Q_OBJECT
	public:
		explicit GridWidget(Tab *tab, QWidget *parent = 0);
		QHBoxLayout	*getColumnsLayout();
		QVBoxLayout	*getColumn(int column);
		Tab*		getTab() const;

	protected:
		void		changeEvent(QEvent *e);
		Tab			*tab;
	};
}

#endif // GRIDWIDGET_HPP
