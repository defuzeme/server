/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "gridwidget.hpp"

using namespace Gui;

GridWidget::GridWidget(Tab *tab, QWidget *parent) :
	QWidget(parent), tab(tab)
{
	setupUi(this);
	setLayoutDirection(Qt::LeftToRight);
	setAutoFillBackground(true);
}

QHBoxLayout *GridWidget::getColumnsLayout()
{
	return columnsLayout;
}

QVBoxLayout *GridWidget::getColumn(int column)
{
	return dynamic_cast<QVBoxLayout*>(getColumnsLayout()->itemAt(column)->layout());
}

Tab *GridWidget::getTab() const
{
	return tab;
}

void GridWidget::changeEvent(QEvent *e)
{
	QWidget::changeEvent(e);
	switch (e->type()) {
	case QEvent::LanguageChange:
		retranslateUi(this);
		break;
	default:
		break;
	}
}
