/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef TAB_HPP
#define TAB_HPP

#include "gridwidget.hpp"
#include "gridelement.hpp"
#include <QtCore/QString>
#include <QMultiMap>

namespace Gui
{
	class Module;

	/** The logical representation of a tab in the Gui::TabWidget.
	  * The graphical representation is the contained Gui::GridWidget.
	  **/

	class Tab
	{
	public:
		Tab(const QString &name);
		~Tab();
		QString							getName() const;											///< Return the tab title
		GridWidget*						getGrid() const;
		void							addModule(Module *module);									///< Used to add a module to a tab. This will automatically create a new Gui::GridElement.
		int								columnCount() const;
		GridElement*					getGridElementByModule(Module* module) const;				///< Return the Gui::GridElement containing the given Gui::Module.
		void							cleanGrid(QWidget *targetDropLocation = 0);
		void							showDropLocations(QPoint sourcePosition);
		void							insertGridElement(GridElement *gridElement,
														  QPoint &targetPosition,
														  bool newColumn);

	private:
		void							showColumnDropLocations(int &column, int &orientation, int &offset, QPoint &sourcePosition);
		void							showRowDropLocations(int column, int initialColumn, QPoint &sourcePosition);
		void							showDropLocation(QPoint targetPosition, bool newColumn);
		QString							name;
		GridWidget						*grid;
		QHash<Module*, GridElement*>	elements;
	};
}

#endif // TAB_HPP
