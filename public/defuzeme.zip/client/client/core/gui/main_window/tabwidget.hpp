/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef TABWIDGET_HPP
#define TABWIDGET_HPP

#include <QtGui/QTabWidget>

namespace Gui
{
	class CornerWidget;
	class MainWindow;
	class GuiCore;

	/** The main tab widget.
	  * Derived from QTabWidget, it allows both DrawBase and DocumentMode to be enabled at the same time.
	  **/

	class TabWidget : public QTabWidget
	{
	public:
		TabWidget(GuiCore *guiCore, MainWindow *parent = 0);
		void			setDrawBase(bool enable);

	protected:
		void			paintEvent(QPaintEvent *);

	private:
		CornerWidget	*menuWidget;
		MainWindow		*mainWindow;
		GuiCore			*guiCore;
	};
}

#endif // TABWIDGET_HPP
