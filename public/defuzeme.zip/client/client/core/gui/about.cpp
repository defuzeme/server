/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "about.hpp"
#include "main.hpp"
#include <QResource>
#include <QDebug>

About::About(QWidget *parent) :
	QWidget(parent)
{
	QResource::registerResource("/usr/local/lib/defuze.me/about.rcc");
	QResource::registerResource("resources/about.rcc");
	QResource::registerResource("../Resources/about.rcc");
	QResource::registerResource("/Applications/defuze.me.app/Contents/Resources/about.rcc");
	setupUi(this);
	logo->setPixmap(QPixmap(":/images/defuze-me-small"));
	setStyleSheet("#contents { border-image:url(:/images/defuze-small) 0; }");
	setWindowFlags(Qt::Dialog | Qt::MSWindowsFixedSizeDialogHint);
	setAttribute(Qt::WA_DeleteOnClose, false);
	versionLabel->setText(versionLabel->text().arg(gl_APPLICATION_VERSION, gl_VERSION_CODENAME));
	scrollArea->viewport()->setAttribute(Qt::WA_AcceptTouchEvents);
}

About::~About()
{
	QResource::unregisterResource("/usr/lib/defuze.me/about.rcc");
	QResource::unregisterResource("resources/about.rcc");
	QResource::unregisterResource("../resources/about.rcc");
	QResource::unregisterResource("/Applications/defuze.me.app/Contents/resources/about.rcc");
}

void About::changeEvent(QEvent *e)
{
	QWidget::changeEvent(e);
	switch (e->type()) {
	case QEvent::LanguageChange:
		retranslateUi(this);
		break;
	default:
		break;
	}
}
