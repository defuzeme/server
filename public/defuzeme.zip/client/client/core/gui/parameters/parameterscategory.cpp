/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "parameterscategory.hpp"

using namespace Gui;

ParametersCategory::ParametersCategory(const QString &title, QWidget *parent) :
	QWidget(parent), title(title)
{
	path = title;
	setupUi(this);
}

void ParametersCategory::addPage(ParametersPage *page)
{
	tabWidget->addTab(page, page->getTitle());
}

const QString &ParametersCategory::getTitle() const
{
	return title;
}

const QString &ParametersCategory::getPath() const
{
	return path;
}


void ParametersCategory::changeEvent(QEvent *e)
{
	QWidget::changeEvent(e);
	switch (e->type()) {
	case QEvent::LanguageChange:
		retranslateUi(this);
		break;
	default:
		break;
	}
}
