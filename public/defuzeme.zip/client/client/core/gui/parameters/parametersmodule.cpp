/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "parametersmodule.hpp"
#include "qtwin.h"
#include "guicore.hpp"
#include <QLabel>

using namespace Gui;

ParametersModule::ParametersModule(GuiCore *guiCore, QWidget *parent):
	QWidget(parent), guiCore(guiCore)
{
	setupUi(this);
	setWindowFlags(Qt::Tool);
	if (guiCore->getPublicParameter("aero", QVariant(true)).toBool())
	{
		if (QtWin::isCompositionEnabled())
		{
			QtWin::extendFrameIntoClientArea(this);
			setContentsMargins(0, 0, -2, -2);
		}
	}
}

void ParametersModule::registerCategory(ParametersCategory *category)
{
	categories[category->getPath()] = category;
	stackedWidget->addWidget(category);
}

QHash<QString, ParametersCategory*>& ParametersModule::getCategories()
{
	return categories;
}

void ParametersModule::changeEvent(QEvent *e)
{
	QWidget::changeEvent(e);
	switch (e->type()) {
	case QEvent::LanguageChange:
		retranslateUi(this);
		break;
	default:
		break;
	}
}
