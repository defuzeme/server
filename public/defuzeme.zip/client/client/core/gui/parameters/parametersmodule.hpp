/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef PARAMETERSMODULE_HPP
#define PARAMETERSMODULE_HPP

#include "ui_parametersmodule.h"
#include "parameterscategory.hpp"

namespace Gui
{
	class GuiCore;

	class ParametersModule : public QWidget, private Ui::ParametersModule
	{
		Q_OBJECT

	public:
		explicit ParametersModule(GuiCore *guiCore, QWidget *parent = 0);
		void									registerCategory(ParametersCategory* category);
		QHash<QString, ParametersCategory*>&	getCategories();

	protected:
		void									changeEvent(QEvent *e);

	private:
		QList<QString>							categoriesPath;
		QHash<QString, ParametersCategory*>		categories;
		GuiCore *guiCore;
	};
}

#endif // PARAMETERSMODULE_HPP
