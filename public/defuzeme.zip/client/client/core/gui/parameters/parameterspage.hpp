/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef PARAMETERSPAGE_HPP
#define PARAMETERSPAGE_HPP

#include <QWidget>

namespace Gui
{
	class ParametersPage : public QWidget
	{
		Q_OBJECT
	public:
		explicit ParametersPage(const QString &title, const QString &category, QWidget *parent = 0);
		const QString&	getPath() const;
		const QString&	getTitle() const;
		const QString&  getCategory() const;

	private:
		QString			title;
		QString			path;
		QString         category;

	};
}

#endif // PARAMETERSPAGE_HPP
