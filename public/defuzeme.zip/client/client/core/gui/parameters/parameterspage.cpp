/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "parameterspage.hpp"

using namespace Gui;

ParametersPage::ParametersPage(const QString &title, const QString &category, QWidget *parent) :
	QWidget(parent), title(title), category(category)
{
	path = title;
}

const QString &ParametersPage::getPath() const
{
	return path;
}

const QString &ParametersPage::getTitle() const
{
	return title;
}

const QString &ParametersPage::getCategory() const
{
	return category;
}
