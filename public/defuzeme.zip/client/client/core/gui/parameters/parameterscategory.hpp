/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef PARAMETERSWIDGET_HPP
#define PARAMETERSWIDGET_HPP

#include "ui_parameterscategory.h"
#include "parameterspage.hpp"

namespace Gui
{
	class ParametersCategory : public QWidget, private Ui::ParametersCategory
	{
		Q_OBJECT

	public:
		explicit ParametersCategory(const QString &title, QWidget *parent = 0);
		const QString &getTitle() const;
		const QString &getPath() const;
		void addPage(ParametersPage *page);

	protected:
		void changeEvent(QEvent *e);
		QString title;
		QString path;
	};
}

#endif // PARAMETERSWIDGET_HPP
