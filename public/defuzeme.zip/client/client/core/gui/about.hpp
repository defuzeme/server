/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef ABOUT_HPP
#define ABOUT_HPP

#include "ui_about.h"

/** The about window.
  * Displays:
  * - the logo
  * - the catch-line
  * - the license
  * - the team
  * - the version
  *
  * \todo Remove the anoying noise when you click outside the window
  **/

class About : public QWidget, private Ui::About
{
	Q_OBJECT

public:
	explicit About(QWidget *parent = 0);
	~About();

protected:
	void changeEvent(QEvent *e);
};

#endif // ABOUT_HPP
