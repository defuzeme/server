/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

namespace Gui {
	class ModuleFactory;
}

#ifndef MODULEFACTORY_HPP
#define MODULEFACTORY_HPP

#include <QtCore/QHash>
#include <QWidget>
#include "module.hpp"

namespace Gui
{
	/** A Factory to create a new Module.
	  * It will check for the uniqueness of the new Module's name.
	  **/

	class ModuleFactory
	{
		friend class GuiCore;
		friend class Module;

	public:
		static Module*					create(const QString uniqName,
											   QPoint position,
											   ModuleWidget *widget,
											   int tabIndex = 0);
		static Module*					getModule(const QString& uniqId);

	private:
		ModuleFactory();
		static void						initModuleFactory(GuiCore *_guiCore);
		static QHash<QString, Module*>	modules;
		static GuiCore*					guiCore;
	};
}

#endif // MODULEFACTORY_HPP
