/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "modulefactory.hpp"
#include "exception.hpp"
#include <QVariant>

using namespace Gui;

QHash<QString, Module*> ModuleFactory::modules = QHash<QString, Module*>();
GuiCore* ModuleFactory::guiCore = 0;

ModuleFactory::ModuleFactory()
{
}

Module* ModuleFactory::create(const QString uniqName, QPoint position, ModuleWidget *widget, int tabIndex)
{
	if (!guiCore)
		throw_exception(0x01, QObject::tr("Cannot create a new Module: Factory not initialized."));
	QString normalizedName = uniqName.toLower();
	if (normalizedName.isEmpty() || modules.contains(normalizedName))
		throw_exception(0x02, QObject::tr("Cannot create a new Module."));
	Module *module = new Module(guiCore);
	module->setWidget(widget);
	QString uniqId = normalizedName;
	int i = 0;
	while (modules.contains(uniqId))
	{
		++i;
		uniqId = normalizedName + "_" + QVariant(i).toString();
	}
	module->setUniqId(uniqId);
	module->setPosition(position);
	module->setTabIndex(tabIndex);
	modules[uniqId] = module;
	return module;
}

Module* ModuleFactory::getModule(const QString &uniqId)
{
	return modules[uniqId];
}

void ModuleFactory::initModuleFactory(GuiCore *_guiCore)
{
	guiCore = _guiCore;
}
