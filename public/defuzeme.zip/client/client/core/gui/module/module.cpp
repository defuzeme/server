/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "module.hpp"
#include "guicore.hpp"
#include "exception.hpp"
#include "parametersmodule.hpp"

using namespace Gui;

Module::Module(GuiCore *guiCore) : guiCore(guiCore)
{
	widget = 0;
	position.setX(-1);
	position.setY(0);
	tabIndex = 0;
	sizePolicy = QSizePolicy::Preferred;
	colSizePolicy = QSizePolicy::Expanding;
}

void Module::setPosition(QPoint position)
{
	this->position = position;
	if (position.x() < -1)
		position.setX(-1);
	if (position.y() < 0)
		position.setY(0);
}

void Module::setTitle(const QString &title)
{
	this->title = title;
}

void Module::setWidget(ModuleWidget *widget)
{
	this->widget = widget;
	this->title = widget->windowTitle();
}

void Module::setTabIndex(int tabIndex)
{
	this->tabIndex = tabIndex;
}

void Module::setUniqId(const QString &uniqId)
{
	if (ModuleFactory::modules.contains(uniqId))
		throw_exception(0x01, tr("Can't create two modules with the same ID."));
	this->uniqId = uniqId;
}

void Module::setSizePolicy(const QSizePolicy::Policy &sizePolicy, const QSizePolicy::Policy &colSizePolicy)
{
	this->sizePolicy = sizePolicy;
	this->colSizePolicy = colSizePolicy;
}

void Module::submitForDisplay(ModuleWidget* widget)
{
	this->widget = widget;
	submitForDisplay();
}

void Module::submitForDisplay()
{
	if (!widget)
		throw_exception(0x02, tr("No widget for module."));
//	if (hasParameters())
//	{
//		foreach (ParametersPage *page, parametersPages)
//		{
//			ParametersCategory *category;
//			if (guiCore->getParametersModule()->getCategories().keys().contains(page->getPath()))
//				category = guiCore->getParametersModule()->getCategories()[page->getPath()];
//			else
//			{
//				category = new ParametersCategory(page->getCategory());
//				guiCore->getParametersModule()->registerCategory(category);
//			}
//			category->addPage(page);
//		}

//	}
	guiCore->addModule(this);
}

void Module::addParametersPage(ParametersPage *parameterPage)
{
	parametersPages[parameterPage->getPath()] = parameterPage;
}

bool Module::hasParameters() const
{
	return !parametersPages.isEmpty();
}

const QString& Module::getUniqId() const
{
	return uniqId;
}

int Module::getTabIndex() const
{
	return tabIndex;
}

const QPoint& Module::getPosition() const
{
	return position;
}

int Module::getRow() const
{
	return position.y();
}

int Module::getColumn() const
{
	return position.x();
}

ModuleWidget *Module::getWidget() const
{
	return widget;
}
