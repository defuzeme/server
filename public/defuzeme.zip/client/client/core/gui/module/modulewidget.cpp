/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "modulewidget.hpp"
#include <QDebug>

using namespace Gui;

ModuleWidget::ModuleWidget(QWidget *parent)  : QWidget(parent)
{
}

ModuleWidget::~ModuleWidget()
{
}
