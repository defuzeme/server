/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef MODULEWIDGET_HPP
#define MODULEWIDGET_HPP

#include <QtGui/QWidget>

namespace Gui
{
	/** The widget users will see inside a GridElement.
	  * It has to be include in a Module in order to be submitted to GuiCore, and then displayed.
	  * \attention The top-widget title will become the displayed GridElement title.
	  **/

	class ModuleWidget : public QWidget
	{
	public:
		ModuleWidget(QWidget *parent = 0);
		virtual ~ModuleWidget();
	};
}

#endif // MODULEWIDGET_HPP
