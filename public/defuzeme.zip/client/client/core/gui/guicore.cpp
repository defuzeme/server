/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "guicore.hpp"
#include "parametersmodule.hpp"
#include "exception.hpp"

using namespace Gui;

GuiCore::GuiCore(QStringList __attribute__((unused)) &arguments)
{
	mainWindow = NULL;
	readyToAddModules = false;
	uiConfiguration = new UiConfiguration();
	ModuleFactory::initModuleFactory(this);
}

GuiCore::~GuiCore()
{
	if (mainWindow)
		delete mainWindow;
}

void GuiCore::init(Cores *c)
{
	cores = c;
	setParamsName("gui");
	setParamsBackEnd(Parameterizable::NONE);
	registerToParamsCore(cores->params());
	mainWindow = new MainWindow(this);
	addTab(tr("Broadcast"), ":/icons/note", true);
	addTab(tr("Scheduling"), ":/icons/calendar");
	addTab(tr("Social"), ":/icons/social");
	aboutDialog = new About;
	//parametersModule = new ParametersModule(this, mainWindow);
	readyToAddModules = true;
	addPendingModules();
}

void GuiCore::aboutToQuit()
{
}

MainWindow* GuiCore::getMainWindow()
{
	return mainWindow;
}

ParametersModule *GuiCore::getParametersModule() const
{
	return parametersModule;
}

void GuiCore::defineParams()
{
	setParameter("maximized", true);
	setParameter("windowed", true);
	setParameter("aero", true);
	setParameter("window_title", "Defuze.me");
}

void	GuiCore::popup(QWidget* window)
{
	window->setParent(mainWindow);
	window->setWindowFlags(Qt::Tool);
	if (mainWindow->isVisible())
		window->show();
	else
		connect(this, SIGNAL(showPopups()), window, SLOT(show()));
}

void GuiCore::addTab(const QString &title, const QString &icon, bool active)
{
	mainWindow->addTab(new Tab(title), icon, active);
}

Tab* GuiCore::currentTab() const
{
	return mainWindow->currentTab();
}

Tab* GuiCore::getTab(TAB_INDEX tabIndex) const
{
	if (mainWindow->getTabs().size() >= tabIndex + 1)
		return mainWindow->getTabs().at(tabIndex);
	else
		return 0;
}

void GuiCore::addModule(Module *module)
{
	if (readyToAddModules)
	{
		Tab *tab;
		if ((tab = getTab((TAB_INDEX)module->getTabIndex())))
			tab->addModule(module);
		else
			throw_exception(0x01, "Cannot add module to unknown tab");
	}
	else
	{
		pendingModules << module;
		emit module->displayPending();
	}
}

void GuiCore::addPendingModules()
{
	if (!readyToAddModules)
		return;
	while (pendingModules.size())
		addModule(pendingModules.takeFirst());
}

void GuiCore::toogleParametersModule()
{
	if (parametersModule->isHidden())
		parametersModule->show();
	else
		parametersModule->hide();
}

void	GuiCore::showAll()
{
	mainWindow->show();
	if (getPublicParameter("maximized").toBool())
		mainWindow->showMaximized();
	emit showPopups();
}

About* GuiCore::getAboutDialog() const
{
	return aboutDialog;
}
