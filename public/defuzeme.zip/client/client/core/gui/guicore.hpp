/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

namespace Gui {
	class GuiCore;
}

#ifndef GUICORE_HPP
#define GUICORE_HPP

#include "core.hpp"
#include "mainwindow.hpp"
#include "parameterizable.hpp"
#include "uiconfiguration.hpp"
#include "modulefactory.hpp"
#include "about.hpp"
#include <QtCore/QList>


namespace Gui
{
	class ParametersModule;

	/** The main class handling Gui.
	  **/

	class GuiCore : public Params::Parameterizable, public Core
	{
		Q_OBJECT
		friend void Module::submitForDisplay();

		enum TAB_INDEX
		{
			BROADCAST = 0,
			SCHEDUELING = 1,
			SOCIAL = 2
		};

	public:
		GuiCore(QStringList &arguments);
		~GuiCore();
		void					init(Cores *cores);
		void					aboutToQuit();
		void					popup(QWidget* window);												///< Popup the widget
		MainWindow*				getMainWindow();
		ParametersModule*		getParametersModule() const;
		void					toogleParametersModule();
		void					showAll();
		About*					getAboutDialog() const;

	signals:
		void					showPopups();

	private:
		void					addModule(Module *module);
		void					addPendingModules();

		void					addTab(const QString &title, const QString &icon, bool active = false);
		Tab*					currentTab() const;
		Tab*					getTab(TAB_INDEX tabIndex) const;
		QList<Tab*>				tabs;

		MainWindow				*mainWindow;														///< The window
		About					*aboutDialog;
		UiConfiguration			*uiConfiguration;													///< The Ui Configuration
		bool					readyToAddModules;
		QList<Module*>			pendingModules;
		ParametersModule		*parametersModule;

		void 					defineParams();
	};
}

#endif // GUICORE_HPP
