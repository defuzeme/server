/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "uiconfiguration.hpp"
#include <QtCore/QDebug>

using namespace Gui;

UiConfiguration::UiConfiguration()
{
	desktop = QApplication::desktop();
	_dump();
}

void UiConfiguration::_dump()
{
	qDebug() << "Currently available Ui configuration";
	qDebug() << "  Screen count:" << desktop->screenCount();
	qDebug() << "  Primary screen:" << desktop->primaryScreen();
	for (int i = 0 ; i < desktop->screenCount() ; ++i)
		qDebug() << "  Screen" << i << "\t[Full]" << desktop->screenGeometry(i) << "\t[Available]" << desktop->availableGeometry(i);
}
