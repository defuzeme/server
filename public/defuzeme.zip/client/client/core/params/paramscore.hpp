/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef PARAMSCORE_HPP
#define PARAMSCORE_HPP

#include "core.hpp"
#include "parameterizable.hpp"
#include <QtCore/QHash>
#include <QtCore/QVariant>

namespace Params
{

	/** Register all Parameterizable classes and handle the command line arguments.
	  *
	  * \todo explain the parameters priorities when command line arguments are used.
	  **/

	class ParamsCore : public Core, public Parameterizable
	{
	public:
		ParamsCore(QStringList &arguments);
		~ParamsCore();
		void init(Cores *cores);
		void aboutToQuit();

		void registerParameterizable(Parameterizable *parameterizable);
		const QHash<QString, QVariant> cmdLineParameters(QString paramsName) const;

	private:
		void handleCmdLineParameters(QStringList &arguments);
		void _printCmdLineParameters();
		void defineParams();

		QHash<QString, QHash<QString, QVariant> > _cmdLineParameters;									///< Store the parameters setted via the command line
		QHash<QString, Parameterizable*> _parameterizables;
	};

}

#endif // PARAMSCORE_HPP
