/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "paramscore.hpp"
#include "exception.hpp"
#include <QtCore/QRegExp>
#include <QDebug>

using namespace Params;

ParamsCore::ParamsCore(QStringList &arguments)
{
	handleCmdLineParameters(arguments);
	//_printCmdLineParameters();
}

ParamsCore::~ParamsCore()
{
}

void ParamsCore::init(Cores *cores)
{
	setParamsName("params");
	setParamsBackEnd(Parameterizable::SETTINGS);
	registerToParamsCore(cores->params());
}

void ParamsCore::aboutToQuit()
{
}

const QHash<QString, QVariant> ParamsCore::cmdLineParameters(QString paramsName) const
{
	if (!_cmdLineParameters.contains(paramsName))
		_cmdLineParameters[paramsName];
	return _cmdLineParameters[paramsName];
}

void ParamsCore::handleCmdLineParameters(QStringList &arguments)
{
	QRegExp paramsPattern("--([a-z_]+)-([a-z0-9_-]+)(=(.+))?");

	foreach (QString argument, arguments)
	{
		if (paramsPattern.exactMatch(argument))
		{
			QStringList matches = paramsPattern.capturedTexts();
			if (matches[4] != "")
				_cmdLineParameters[matches[1]][matches[2]] = matches[4];
			else
				_cmdLineParameters[matches[1]][matches[2]] = true;
		}
	}
}

void ParamsCore::registerParameterizable(Parameterizable *parameterizable)
{
	if (_parameterizables.contains(parameterizable->paramsName()))
		throw_exception(0x01, "Can't register a Parameterizable (name is already used)");
	_parameterizables[parameterizable->paramsName()] = parameterizable;
}

void ParamsCore::_printCmdLineParameters()
{
	QHash<QString, QHash<QString, QVariant> >::const_iterator i = _cmdLineParameters.constBegin();
	while (i != _cmdLineParameters.constEnd())
	{
		qDebug() << i.key();
		QHash<QString, QVariant>::const_iterator j = i.value().constBegin();
		while (j != i.value().constEnd())
		{
			qDebug() << "  " << j.key() << "=" << j.value().toString();
			++j;
		}
		++i;
	}
}

void ParamsCore::defineParams()
{
	setParameter("first_launch", true);
}
