/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

class Cores;

#ifndef CORES_HPP
#define CORES_HPP

#include <QtCore/QStringList>
#include <QObject>

namespace Params {
	class ParamsCore;
}

namespace Gui {
	class GuiCore;
}

namespace DB {
	class DBCore;
}

namespace Network {
	class NetworkCore;
}


namespace Audio {
	class AudioCore;
}


/** Kind of a strucure containing all CORES.
  * It also contains some conveniant methods.
  **/

class Cores : public QObject
{
	Q_OBJECT
public:
	Cores(QStringList &arguments);
	~Cores();
	void					init();											///< Call all cores init() method.
	Gui::GuiCore*			gui();
	DB::DBCore*				db();
	Audio::AudioCore*		audio();
	Network::NetworkCore*	net();
	Params::ParamsCore*		params();
public slots:
	void					aboutToQuit();									///< Call all cores aboutToQuit() method.
private:
	Params::ParamsCore		*_params;
	Audio::AudioCore		*_audio;
	Gui::GuiCore			*_gui;
	DB::DBCore				*_db;
	Network::NetworkCore	*_net;
};

#endif // CORES_HPP
