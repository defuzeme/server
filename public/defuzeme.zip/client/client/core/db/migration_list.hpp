/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef MIGRATION_LIST_HPP
#define MIGRATION_LIST_HPP

#include "migration.hpp"


/** This is a template to build quickly a migration class
  * see below for usage.
  **/

#define MIGRATION_TEMPLATE(migClass) class migClass : public Migration \
{ \
public: \
	migClass(const char* name) : Migration(name) {} \
	void	up(); \
	void	down(); \
} \

namespace DB {
	/** This is how you should define a new migration.
	  * You also need to create a cpp file in the migrations folder containing your migration.
	  * The class name is the same as MIGRATION_TEMPLATE argument.
	  * You also need to add your migration to the load list (migration.cpp)
	  **/
	MIGRATION_TEMPLATE(SettingsMigration);
	MIGRATION_TEMPLATE(ConfigurationsMigration);
	MIGRATION_TEMPLATE(AudioTracksMigration);
	MIGRATION_TEMPLATE(SourcesMigration);
	MIGRATION_TEMPLATE(PlaylistsMigration);
	MIGRATION_TEMPLATE(SchedulerMigration);
}

#endif // MIGRATION_LIST_HPP
