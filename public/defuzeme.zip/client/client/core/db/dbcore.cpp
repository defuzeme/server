/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include <iostream>
#include <QDir>
#include "dbcore.hpp"
#include "exception.hpp"
#include "parser.hpp"
#include "status.hpp"

using namespace DB;

DBCore::DBCore(QStringList &)
{
}

DBCore::~DBCore()
{
	while (!locations.empty())
	{
		delete locations.back();
		locations.pop_back();
	}
}

void	DBCore::defineParams()
{
	// Default locations
	QVariantList list;
	list.push_back(QDesktopServices::storageLocation(QDesktopServices::DataLocation) + "/database.db");
	list.push_back(QDesktopServices::storageLocation(QDesktopServices::DocumentsLocation) + "/defuze.me/backup/database.db");
	setParameter("locations", list);
}

void	DBCore::loadLocations()
{
	QVariantList list = getParameter("locations").toList();
	for (int i = 0; i < list.size(); i++)
		locations.push_back(new Location(list.at(i).toString()));
	currentLocation = NULL;
}

void	DBCore::saveLocations()
{
	QVariantList list;
	for (int i = 0; i < locations.size(); i++)
		list.push_back(locations[i]->filePath());
	setParameter("locations", list);
	commitParameters();
}

void DBCore::init(Cores *c)
{
	cores = c;

	setParamsName("db");
	setParamsBackEnd(Params::Parameterizable::SETTINGS);
	registerToParamsCore(cores->params());
	loadLocations();
	// Find the better location
	Location* original = locations.first();

	if (!original->exists() || !openLocation(original))
	{
		// WARNING: can't open original database !!!!!

		// try to load backups
		bool	backupOk = false;
		for(int i = 1; i < locations.size(); ++i)
		{
			if (openLocation(locations.at(i)))
			{
				backupOk = true;
				break;
			}
		}
		if (!backupOk && !openLocation(original))
			throw_exception(0x01, "No database found, no backup available, can't create a new one, please check your persmissions!");
	}

	MigrationEngine	mEngine(*this);
	mEngine.migrate();

	if (getParameter("reset", false) == true)
	{
		qDebug() << "DB reset requested";
		// Undo all migrations
		mEngine.undo();
		// Migrate database to new schema
		mEngine.migrate();
	}
	// self-test
	//test();

	backupAll();
}

void DBCore::aboutToQuit()
{
	connection.close();
	currentLocation = NULL;
}

bool	DBCore::openLocation(Location* loc)
{
	qDebug() << "DB::Core opening database:" << loc->filePath();
	loc->mkPath();
	connection = QSqlDatabase::addDatabase("QSQLITE");
	connection.setDatabaseName(loc->filePath());
	connection.setUserName("defuze.me");
	if (!connection.open())
	{
		std::cerr << connection.lastError().text().toStdString() << std::endl;
		return false;
	}
	loc->open() = true;
	currentLocation = loc;
	return true;
}

QVariant	DBCore::setting(const QString& key) const
{
	QSqlQuery query;
	QVariant value;
	query.prepare("SELECT * FROM settings WHERE key = :key LIMIT 1");
	query.bindValue(":key", key);
	query.exec();
	int fieldNo = query.record().indexOf("value");
	if (query.next())
		value = query.value(fieldNo);
	return (Network::JsonParser().parse(value.toByteArray()));
}

QHash<QString, QVariant> DBCore::settingsStartingWith(const QString &key) const
{
	QHash<QString, QVariant> result;
	QSqlQuery query;
	QVariant value;
	QString fullKey;
	query.prepare("SELECT * FROM settings WHERE key LIKE :key");
	query.bindValue(":key", key + "%");
	query.exec();
	int keyFieldNo = query.record().indexOf("key");
	int valueFieldNo = query.record().indexOf("value");
	while (query.next())
	{
		fullKey = query.value(keyFieldNo).toString();
		value = query.value(valueFieldNo);
		result[fullKey] = Network::JsonParser().parse(value.toByteArray());
	}
	return (result);
}

bool	DBCore::setSetting(const QString& key, const QVariant value) const
{
	QSqlQuery query;
	query.prepare("INSERT OR REPLACE INTO settings (key, value) VALUES (:key, :value)");
	query.bindValue(":key", key);
	query.bindValue(":value", Network::JsonParser().serialize(value));
	if (!query.exec())
		throw_exception(0x02, QString("Can't store setting value: " + query.lastError().text()));
	return true;
}

int		DBCore::currentMigration() const
{
	QVariant	value = setting("migration");
	if (value.isNull())
		return 0;
	else
		return value.toInt();
}

void		DBCore::backupAll()
{
	for(int i = 0; i < locations.size(); ++i)
	{
		Location* loc = locations.at(i);
		if (!loc->open())
		{
			qDebug() << "DB::Core backuping database to" << loc->filePath() << "(age=" << loc->age() << ")";
			loc->mkPath();
			QFile::remove(loc->filePath());
			QFile	database(currentLocation->filePath());
			if (!database.copy(loc->filePath()))
			{
				Notification::Status::gMessage(tr("Can't backup to %1 (%2)").arg(loc->filePath()).arg(database.errorString()), Notification::WARN);
			}
			loc->reload();
		}
	}
}

void		DBCore::test()
{
	// migration tests
	MigrationEngine	mEngine(*this);
	mEngine.undo();
	mEngine.migrate();
	mEngine.undo();
	mEngine.migrate();

	// settings tests
	setSetting("test-foo", 42);
	Q_ASSERT_X(setting("test-foo") == 42, "DBCore::test", "Integer setting error");
	setSetting("test-foo", 40.42);
	Q_ASSERT_X(setting("test-foo") == 40.42, "DBCore::test", "Double setting error");
	setSetting("test-foo", "Hello");
	Q_ASSERT_X(setting("test-foo") == "Hello", "DBCore::test", "String setting error");
	QVariantList list;
	list.append(42);
	list.append(40.42);
	list.append("Hello");
	setSetting("test-foo", list);
	Q_ASSERT_X(setting("test-foo") == list, "DBCore::test", "Array setting error");
	QVariantMap map;
	map["int"] = 42;
	map["double"] = 40.42;
	map["string"] = "Hello";
	setSetting("test-foo", map);
	Q_ASSERT_X(setting("test-foo") == map, "DBCore::test", "Map setting error");
	Q_ASSERT_X(setting("test-empty") == QVariant(), "DBCore::test", "Empty setting error");
}
