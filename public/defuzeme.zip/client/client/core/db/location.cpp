/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "location.hpp"

using namespace DB;

Location::Location(const QString path) : infos(path)
{
	_open = false;
}

QString		Location::filePath() const
{
	return infos.absoluteFilePath();
}

QDir		Location::dirPath() const
{
	return infos.absoluteDir();
}

bool		Location::exists() const
{
	return infos.exists();
}

QDateTime	Location::lastModified() const
{
	return infos.lastModified();
}

int			Location::age() const
{
	if (_open)
		return 0;
	else
		return lastModified().secsTo(QDateTime::currentDateTime());
}

bool&		Location::open()
{
	return _open;
}

void		Location::reload()
{
	infos.refresh();
}

void		Location::mkPath() const
{
	QDir dir(dirPath());
	dir.mkpath("./");
}
