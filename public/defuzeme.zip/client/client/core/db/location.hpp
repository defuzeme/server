/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef LOCATION_HPP
#define LOCATION_HPP

#include <QFile>
#include <QDir>
#include <QFileInfo>
#include <QDateTime>

namespace DB
{
	/** This class is used to store informations about one of the database file.
	  * We will have one instance per replication path.
	  **/

	class Location
	{
	public:
		Location(const QString path);
		QString		filePath() const;
		QDir		dirPath() const;
		bool		exists() const;
		QDateTime	lastModified() const;		///< Return file last modification date
		int			age() const;				///< Return number of seconds since last modification
		bool&		open();						///< Return if this location is the current database
		void		reload();
		void		mkPath() const;				///< Create all folders contained in the path

	private:
		QFileInfo	infos;
		bool		_open;
	};
}

#endif // LOCATION_HPP
