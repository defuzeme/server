/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "migration_list.hpp"

using namespace DB;

void	SourcesMigration::up()
{
	createTable("sources", "id integer primary key, type int, port int, "
				"host varchar(253), path varchar(1000), username varchar(100), "
				"password varchar(100), filename varchar(100), "
				"updatedAt datetime, status int, recursive bool");
	exec("CREATE UNIQUE INDEX source_id ON sources(id)");
}

void	SourcesMigration::down()
{
	dropTable("sources");
}
