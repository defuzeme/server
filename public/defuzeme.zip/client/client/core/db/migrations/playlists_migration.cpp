#include "migration_list.hpp"

using namespace DB;

void	PlaylistsMigration::up()
{
        createTable("playlists", "id integer primary key, name varchar(100) collate nocase, is_dynamic bool, definition text");
	exec("CREATE UNIQUE INDEX playlist_id ON playlists(id)");
}

void	PlaylistsMigration::down()
{
	dropTable("playlists");
}
