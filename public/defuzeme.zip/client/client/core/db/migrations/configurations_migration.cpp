/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "migration_list.hpp"

using namespace DB;

void	ConfigurationsMigration::up()
{
	createTable("configurations", "id int primary key, name varchar(50), author varchar(50)");
	exec("insert into configurations values(1, 'Default', 'defuze.me')");
}

void	ConfigurationsMigration::down()
{
	dropTable("configurations");
}
