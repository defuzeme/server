#include "migration_list.hpp"

using namespace DB;

void	SchedulerMigration::up()
{
	createTable("events", "id INTEGER PRIMARY KEY, title VARCHAR(255), description VARCHAR(255), day INTEGER, start INTEGER, duration INTEGER");
	exec("CREATE UNIQUE INDEX event_id ON events(id)");

	createTable("colors", "id INTEGER PRIMARY KEY, color VARCHAR(6)");
	exec("CREATE UNIQUE INDEX color_id ON colors(id)");

	createTable("colors_events", "event_id INTEGER PRIMARY KEY, color_id INTEGER");
	exec("CREATE UNIQUE INDEX color_event_id ON colors_events(event_id)");

	createTable("events_playlists", "id INTEGER PRIMARY KEY, event_id INTEGER, playlist_id INTEGER");
	exec("CREATE UNIQUE INDEX event_playlist_id ON events_playlists(id)");

	exec("insert into colors values('1', 'FFAD46')");
	exec("insert into colors values('2', 'A4BDFC')");
	exec("insert into colors values('3', '7AE7BF')");
	exec("insert into colors values('4', 'DBADFF')");
	exec("insert into colors values('5', 'FF887C')");
	exec("insert into colors values('6', 'FBD75B')");
	exec("insert into colors values('7', 'FFB878')");
	exec("insert into colors values('8', '46D6DB')");
	exec("insert into colors values('9', 'E1E1E1')");
}

void    SchedulerMigration::down()
{
	dropTable("colors");
	dropTable("events");
	dropTable("colors_events");
	dropTable("events_playlists");
}
