/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "migration_list.hpp"
#include "jsonparser.hpp"

using namespace DB;

void	AudioTracksMigration::up()
{
	createTable("audio_tracks", "id integer primary key, title varchar(100) collate nocase, artist varchar(100) collate nocase, album_artist valchar(100) collate nocase, album varchar(100) collate nocase, year integer, track integer, genre varchar(50) collate nocase, duration integer, path varchar(1000), source integer, attributes text");
	exec("CREATE UNIQUE INDEX audio_track_id ON audio_tracks(id)");
	createTable("queue", "queueable_id integer, queueable_type varchar(20), position integer UNIQUE, attributes text");
	exec("CREATE INDEX queue_position ON queue(position)");
}

void	AudioTracksMigration::down()
{
	dropTable("queue");
	dropTable("audio_tracks");
}
