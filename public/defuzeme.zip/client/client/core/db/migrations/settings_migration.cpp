/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "migration_list.hpp"

using namespace DB;

void	SettingsMigration::up()
{
	createTable("settings", "key varchar(50), configuration_id integer, value varchar(255)");
	exec("CREATE UNIQUE INDEX settings_key ON settings(key)");
	exec("CREATE UNIQUE INDEX settings_config_key ON settings(configuration_id, key)");

	exec("INSERT INTO settings (key, value) VALUES ('migration', 1)");
}

void	SettingsMigration::down()
{
	dropTable("settings");
}
