/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

namespace DB {
	class DBCore;
}

#ifndef DBCORE_HPP
#define DBCORE_HPP

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QSqlRecord>
#include <QVariant>
#include <QStringList>
#include <QDesktopServices>
#include "core.hpp"
#include "migration.hpp"
#include "location.hpp"
#include "parameterizable.hpp"

namespace DB
{

	/** This is the database access wrapper, It manage database and backups locations.
	  **/

	class DBCore : public Core, public Params::Parameterizable
	{
	public:
		DBCore(QStringList &arguments);
		~DBCore();
		void						init(Cores* cores);
		void						aboutToQuit();
		bool						openLocation(Location* loc);									///< Try to open the database at loc
		QVariant					setting(const QString& key) const;								///< Get the value of a setting
		QHash< QString, QVariant>	settingsStartingWith(const QString& key) const;					///< Get the settings where the key start LIKE 'key'
		bool						setSetting(const QString& key, const QVariant value) const;		///< Set the value of a setting
		int							currentMigration() const;										///< Get the current migration number
		void						backupAll();													///< Will copy currentLocation over each other location
		void						test();															///< Some tests

	private:
		void						defineParams();
		void						loadLocations();												///< Load databases locations from settings
		void						saveLocations();												///< save databases locations to settings

		QList<Location*>			locations;														///< Store all locations where the database will be replicated
		QSqlDatabase				connection;
		Location*					currentLocation;
	};
}

#endif // DBCORE_HPP
