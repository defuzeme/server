/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "libraryitem.hpp"
#include "librarymodel.hpp"

using namespace Library;

LibraryItem::LibraryItem(const QString title, int id, int itemKind, TreeItem *parent)
	: TreeItem(title, parent), id(id)
{
	isInAlbum = false;
	if (itemKind == LibraryModel::ALBUM)
		kind = ALBUM;
	else if (itemKind == LibraryModel::ALBUM_ARTIST ||
			 itemKind == LibraryModel::ARTIST)
		kind = ARTIST;
	else if (itemKind == LibraryModel::GENRE)
		kind = GENRE;
	else
	{
		if (itemKind == LibraryModel::TRACK)
			isInAlbum = true;
		kind = TRACK;
	}
}

LibraryItem::Kind LibraryItem::getKind() const
{
	return kind;
}

bool LibraryItem::getIsInAlbum() const
{
	return isInAlbum;
}

AudioTrack*	LibraryItem::getTrack()
{
	return AudioTrack::getTrack(id);
}

int			LibraryItem::getId() const
{
	return id;
}
