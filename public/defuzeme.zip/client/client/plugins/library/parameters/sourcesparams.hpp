/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef SOURCESPARAMS_HPP
#define SOURCESPARAMS_HPP

#include "ui_sourcesparams.h"
#include "parameterspage.hpp"

namespace Library
{
	class SourcesParams : public Gui::ParametersPage, private Ui::SourcesParams
	{
		Q_OBJECT

	public:
		explicit SourcesParams(const QString &title, const QString &category, QWidget *parent = 0);

	protected:
		void changeEvent(QEvent *e);
	};
}

#endif // SOURCESPARAMS_HPP
