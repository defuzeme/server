/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "sourcesparams.hpp"

using namespace Library;

SourcesParams::SourcesParams(const QString &title, const QString &category, QWidget *parent) :
	Gui::ParametersPage(title, category, parent)
{
	setupUi(this);
}

void SourcesParams::changeEvent(QEvent *e)
{
	QWidget::changeEvent(e);
	switch (e->type()) {
	case QEvent::LanguageChange:
		retranslateUi(this);
		break;
	default:
		break;
	}
}
