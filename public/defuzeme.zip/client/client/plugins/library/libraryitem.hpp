/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef LIBRARYITEM_HPP
#define LIBRARYITEM_HPP

#include "treeitem.hpp"
#include "audiotrack.hpp"

namespace Library
{
	class LibraryItem : public TreeItem
	{
	public:
		enum Kind { ALBUM, ARTIST, TRACK, GENRE };

		LibraryItem(const QString title, int id, int itemKind, TreeItem *parent = 0);
		Kind		getKind() const;
		bool		getIsInAlbum() const;
		AudioTrack*	getTrack();
		int			getId() const;

	private:
		int id;
		Kind kind;
		bool isInAlbum;
	};
}
#endif // LIBRARYITEM_HPP
