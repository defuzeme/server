/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef LIBRARYWIDGET_HPP
#define LIBRARYWIDGET_HPP

#include "guicore.hpp"
#include "ui_librarywidget.h"

namespace Library
{

class LibraryPlugin;

class LibraryWidget : public Gui::ModuleWidget, private Ui::LibraryWidget
{
	Q_OBJECT

public:
	explicit LibraryWidget(LibraryPlugin *library, QWidget *parent = 0);
	QTreeView *getTreeViewWidget() const;
	QToolButton *getUpdateSourcesButton() const;
	QToolButton *getAddSourceButton() const;
	QProgressBar *getUpdateProgressBar() const;
	void updatingSources();
	void endUpdatingSources();


protected:
	void changeEvent(QEvent *e);

private slots:

	void toogleItem(const QModelIndex &index);
	void on_updateSourcesButton_clicked();
	void on_addSourceButton_clicked();
	void on_treeView_doubleClicked(const QModelIndex &index);
	void on_sortComboBox_currentIndexChanged(int index);
	void on_searchLineEdit_textChanged(const QString &arg1);

private:
	LibraryPlugin *library;

};

}
#endif // LIBRARYWIDGET_HPP
