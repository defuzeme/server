/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef LIBRARY_HPP
#define LIBRARY_HPP

#include "staticplugin.hpp"
#include "parameterizable.hpp"
#include "librarywidget.hpp"
#include "librarymodel.hpp"
#include "playqueue.hpp"
#include "source.hpp"
#include "locker.hpp"
#include <QUrl>
#include <QtConcurrentMap>

namespace Library
{

/**
  * \todo Gestion du filename lors de l'ajout d'une source
  **/

class LibraryPlugin : public Params::Parameterizable, public StaticPlugin, public Locker
{
	Q_OBJECT
public:
	LibraryPlugin();
	~LibraryPlugin();
	void					init();
	void					aboutToQuit();
	LibraryModel			*getModel() const;
	LibraryWidget			*getWidget() const;
	void					addSource(const QUrl &url, bool recursive = true);
	void					updateSources();
	void					addTrackToQueue(int id);
	static void				updateSource(quintptr &sourceAddr);
	static QStringList		allowedExtension;

public slots:
	void					updateStarted();
	void 					updateFinished();
	void					updateProgress(int progressValue);
	void					updateProgressMax(int maximum);

private:
	void					loadSources();
	void					defineParams();
	QList<Source*>			sources;
	QList<quintptr>			sourcesAddr;
	LibraryModel			*model;
	LibraryWidget			*widget;
	QFutureWatcher<void>	*watcher;
};

}

#endif // LIBRARY_HPP
