/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef SOURCE_HPP
#define SOURCE_HPP

#include <QString>
#include <QDateTime>
#include <QUrl>

namespace Library
{
	class Source : public QObject
	{
		Q_OBJECT

		enum Type
		{
			LOCAL = 0,
			HTTP = 1,
			FTP = 2
		};

		enum Status
		{
			OK = 0,
			OUTDATED = 1,
			ERROR = 2,
			UNINITIALIZED = 3
		};

	public:
		Source(Type type, const QString &path, bool resursive = false,
			   const QString &host = QString(),
			   unsigned short port = 0,
			   const QString &username = QString(),
			   const QString &password = QString(),
			   const QString &filename = QString());
		Source(int id);
		static Source*	getSource(int id);			///< Fetch & cache sources
		Status			update();
		bool			newRecord() const;
		void			save();
		void			merge(Source *oldSource);
		QUrl			toUrl() const;
		bool			isRecursive() const;
		int				getId() const;
		const QString&	getPath() const;
		static Type		typeFromScheme(const QString &scheme);
		void			remove();

	signals:
		void			progressValueChange(int progressValue);
		void			addToMaximumProgress(int maxValue);

	private:
		int				id;
		Type			type;
		unsigned short	port;
		QString			host, path;
		QString			username, password;
		QString			filename;
		QDateTime		updatedAt;
		Status			status;
		bool			recursive;

		static QMap<int, Source*>	sourcesMap;
	};
}
#endif // SOURCE_HPP
