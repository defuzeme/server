/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "audiotrack.hpp"
#include "audiotrackloader.hpp"
#include <QTimer>
#include <QtConcurrentRun>

using namespace Library;

AudioTrackLoader::AudioTrackLoader(int id) : id(id)
{
	QtConcurrent::run(this, &AudioTrackLoader::load);
}

void	AudioTrackLoader::load()
{
	AudioTrack::getTrack(id);
	emit loaded(id);
}
