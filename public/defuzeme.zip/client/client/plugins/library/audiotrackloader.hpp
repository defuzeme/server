/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef AUDIOTRACKLOADER_HPP
#define AUDIOTRACKLOADER_HPP

#include <QObject>

namespace Library {
	/** This class allows to asynchronously load a track and call a slot back after
	  * It is used by AudioTrack::loadAndCall
	  **/
	class AudioTrackLoader : public QObject
	{
		Q_OBJECT
	public:
		explicit AudioTrackLoader(int id);

	signals:
		void		loaded(int id);

	public slots:
		void		load();

	private:
		int	id;
	};
}

#endif // AUDIOTRACKLOADER_HPP
