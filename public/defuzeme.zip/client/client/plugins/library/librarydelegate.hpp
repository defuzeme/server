/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef LIBRARYDELEGATE_HPP
#define LIBRARYDELEGATE_HPP

#include <QStyledItemDelegate>
#include "libraryitem.hpp"

namespace Library
{
	/** The LibraryDelegate class provides a custom visual rendering for library elements
	  **/
	class LibraryDelegate : public QStyledItemDelegate
	{
	public:
		LibraryDelegate(QObject *parent = 0);
		QSize sizeHint(const QStyleOptionViewItem &option, const QModelIndex &index) const;
		void paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const;

		QPixmap	note;
	};
}

#endif // LIBRARYDELEGATE_HPP
