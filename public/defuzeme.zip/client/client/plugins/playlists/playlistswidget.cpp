#include "playlistswidget.hpp"
#include "playlists.hpp"
#include "playliststreeview.hpp"

using namespace Playlists;

PlaylistsWidget::PlaylistsWidget(PlaylistsPlugin *playlists, QWidget *parent) :
	ModuleWidget(parent), playlists(playlists)
{
        setupUi(this);
}

QPushButton     *PlaylistsWidget::getButtonAdd() const
{
	return buttonAdd;
}

QLineEdit       *PlaylistsWidget::getLineEditAdd() const
{
	return lineEditAdd;
}

PlaylistsTreeView    *PlaylistsWidget::getTreeView() const
{
    return playlistsTreeView;
}

void            PlaylistsWidget::changeEvent(QEvent *e)
{
	QWidget::changeEvent(e);
	switch (e->type()) {
	case QEvent::LanguageChange:
		retranslateUi(this);
		break;
	default:
		break;
	}
}

void Playlists::PlaylistsWidget::on_buttonAdd_clicked()
{
	playlists->addPlaylist(getLineEditAdd()->text());
}
