#ifndef PLAYLISTITEM_HPP
#define PLAYLISTITEM_HPP

#include <QStandardItem>
#include <QContextMenuEvent>

namespace Playlists
{
class PlaylistItem : public QObject, public QStandardItem
{
    Q_OBJECT

private:
    int         idItem;
    bool        isPlaylist;
    int         index;
public:
    explicit PlaylistItem();
             PlaylistItem(int id, QString text, bool itemIsPlaylist);
    int         getIdItem() const;
    int         getItemIndex();
    bool        itemIsPlaylist();

};
}

#endif // PLAYLISTITEM_HPP
