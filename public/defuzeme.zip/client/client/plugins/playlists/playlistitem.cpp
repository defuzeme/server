#include "playlistitem.hpp"
#include <QMenu>

using namespace Playlists;

PlaylistItem::PlaylistItem() :
    QStandardItem()
{
}

PlaylistItem::PlaylistItem(int id, QString text, bool itemIsPlaylist) : QStandardItem(text)
{
    this->idItem = id;
    this->isPlaylist = itemIsPlaylist;
    this->setEditable(FALSE);
}

int         PlaylistItem::getIdItem() const
{
    return this->idItem;
}

int         PlaylistItem::getItemIndex()
{
    return this->index;
}

bool        PlaylistItem::itemIsPlaylist()
{
    return isPlaylist;
}
