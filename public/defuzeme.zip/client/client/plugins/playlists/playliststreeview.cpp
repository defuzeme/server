#include "playliststreeview.hpp"
#include "playlists.hpp"
#include "playlistsmodel.hpp"
#include "playlistitem.hpp"
#include <qmenu.h>
#include <QContextMenuEvent>

using namespace Playlists;

PlaylistsTreeView::PlaylistsTreeView(QWidget *parent) :
    QTreeView(parent)
{
    setupUi(this);
    setContextMenuPolicy(Qt::DefaultContextMenu);
    setDragDropMode(QAbstractItemView::DragDrop);
    setHeaderHidden(true);
    idToDelete = -1;
    trackIndexToDelete = -1;
}

void PlaylistsTreeView::changeEvent(QEvent *e)
{
    QWidget::changeEvent(e);
    switch (e->type()) {
    case QEvent::LanguageChange:
        retranslateUi(this);
        break;
    default:
        break;
    }
}

void            PlaylistsTreeView::deletePlaylist()
{
	PlaylistsModel *model = static_cast<PlaylistsModel *>(this->model());
	model->getPlaylists()->deletePlaylist(idToDelete);
    idToDelete = -1;
}

void            PlaylistsTreeView::deleteTrack()
{
    Playlist *playlist = ((PlaylistsModel *)this->model())->getPlaylists()->getPlaylistById(idToDelete);
    playlist->getTrackList()->removeAt(trackIndexToDelete);
    playlist->updatePlaylist();
    ((PlaylistsModel *)this->model())->update(playlist->getId());
    idToDelete = -1;
}

void PlaylistsTreeView::contextMenuEvent(QContextMenuEvent *event)
{
    PlaylistItem *item = static_cast<PlaylistItem *>(((QStandardItemModel *)model())->itemFromIndex(this->indexAt(((QContextMenuEvent *)event)->pos())));
    if (item)
    {
        QMenu* contextMenu = new QMenu ( this );
        Q_CHECK_PTR ( contextMenu );
        if (item->itemIsPlaylist())
        {
            idToDelete = item->getIdItem();
            contextMenu->addAction ( "Supprimer" , this , SLOT (deletePlaylist()));
        }
        else
        {
            idToDelete = ((PlaylistItem*)(item->QStandardItem::parent()))->getIdItem();
            trackIndexToDelete = item->row();
            contextMenu->addAction ( "Supprimer" , this , SLOT (deleteTrack()));
        }
        contextMenu->popup( QCursor::pos() );
        contextMenu->exec ();
        delete contextMenu;
        contextMenu = 0;
    }
}

void	PlaylistsTreeView::dragEnterEvent(QDragEnterEvent *event)
{
        if (event->mimeData()->hasFormat("application/x-defuzeme-audiotrack"))
                event->accept();
        else
                event->ignore();

}

void	PlaylistsTreeView::dragMoveEvent(QDragMoveEvent *event)
{
        event->accept();
}

void    PlaylistsTreeView::dropEvent(QDropEvent *event)
{
    event->pos();
    PlaylistItem *item = static_cast<PlaylistItem *>(((QStandardItemModel *)this->model())->itemFromIndex(this->indexAt(((QContextMenuEvent *)event)->pos())));
	qDebug() << item;
    if (item)
    {
        QByteArray	encodedData;
            if (event->mimeData()->hasFormat("application/x-defuzeme-audiotrack"))
                encodedData = event->mimeData()->data("application/x-defuzeme-audiotrack");
        else
                return;

        QDataStream stream(&encodedData, QIODevice::ReadOnly);
        QList<int> ids;

        while (!stream.atEnd())
        {
                int id;
                stream >> id;
                ids << id;
        }
        Playlist *playlist;
        if (item->itemIsPlaylist())
        {
            playlist = ((PlaylistsModel *)this->model())->getPlaylists()->getPlaylistById(item->getIdItem());
            foreach (int id, ids)
            {
               playlist->addTrack(id);
            }
        }
        else
        {
            playlist = ((PlaylistsModel *)this->model())->getPlaylists()->getPlaylistById(((PlaylistItem*)(item->QStandardItem::parent()))->getIdItem());
            foreach (int id, ids)
            {
                playlist->addTrack(id, item->row());
            }
        }
        playlist->updatePlaylist();
        ((PlaylistsModel *)this->model())->update(playlist->getId());
    }
}
