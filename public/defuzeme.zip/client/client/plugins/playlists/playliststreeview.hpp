#ifndef PLAYLISTSTREEVIEW_HPP
#define PLAYLISTSTREEVIEW_HPP

#include <qtreeview.h>
#include "ui_playliststreeview.h"
#include "playlistitem.hpp"

namespace Playlists
{
class PlaylistsTreeView : public QTreeView, private Ui::PlaylistsTreeView
{
    Q_OBJECT

public:
    explicit PlaylistsTreeView(QWidget *parent = 0);
    void	dragEnterEvent(QDragEnterEvent *event);
    void	dragMoveEvent(QDragMoveEvent *event);
    void    dropEvent(QDropEvent *);

protected:
    void changeEvent(QEvent *e);

private:
    int     idToDelete;
    int     trackIndexToDelete;

private slots:
    void deletePlaylist();
    void deleteTrack();
    void contextMenuEvent(QContextMenuEvent *);
};
}

#endif // PLAYLISTSTREEVIEW_HPP
