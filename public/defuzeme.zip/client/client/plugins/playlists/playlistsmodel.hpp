#ifndef PLAYLISTSMODEL_HPP
#define PLAYLISTSMODEL_HPP

#include "playlistitem.hpp"

#include <QStandardItemModel>

namespace Playlists
{

class PlaylistsPlugin;

class PlaylistsModel : public QStandardItemModel
{
public:
        PlaylistsModel(PlaylistsPlugin *playlists);
        PlaylistsPlugin			*getPlaylists() const;
        void                            update(int playlistId = -1);
        void                            insertPlaylist(int playlistId);
        void                            deletePlaylist(int playlistId);
        int                             getIdByIndex(const QModelIndex &index) const;
        QMimeData*			mimeData(const QModelIndexList &indexes) const;

private:
        PlaylistsPlugin			*playlists;
        QStandardItem                   *rootItem;
};
}

#endif // PLAYLISTSMODEL_HPP
