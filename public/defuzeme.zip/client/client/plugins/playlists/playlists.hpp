#ifndef PLAYLISTS_HPP
#define PLAYLISTS_HPP

#include "staticplugin.hpp"
#include "playlistswidget.hpp"
#include "playlistsmodel.hpp"
#include "playlist.hpp"

namespace Playlists
{
	class PlaylistsPlugin : public QObject, public StaticPlugin
	{
		Q_OBJECT
        public:
                PlaylistsPlugin();
                ~PlaylistsPlugin();
                void				init();
                void				aboutToQuit();
		PlaylistsModel		*getModel() const;
		PlaylistsWidget		*getWidget() const;
                void			addPlaylist(QString name);
                void                    deletePlaylist(int idPlaylist);
		QList<Playlist*>	*getPlaylistList() const;
                Playlist                *getPlaylistById(int playlistId);

        private:
                void				loadPlaylists();
		PlaylistsModel		*model;
		PlaylistsWidget		*widget;
		QList<Playlist*>	*playlistsList;
        };
}

#endif // PLAYLISTS_HPP
