#include "playlistsmodel.hpp"
#include "playlists.hpp"
#include "playlistitem.hpp"

using namespace Playlists;

PlaylistsModel::PlaylistsModel(PlaylistsPlugin *playlists) : playlists(playlists)
{
    rootItem = invisibleRootItem();
}

PlaylistsPlugin *PlaylistsModel::getPlaylists() const
{
	return playlists;
}

void            PlaylistsModel::update(int playlistId)
{
    PlaylistItem    *playlistItem;
    PlaylistItem   *trackItem;

    if (playlistId == -1)
    {
        removeRows(0, rowCount(rootItem->index()), rootItem->index());
        QList<Playlist*> *playlistsList = playlists->getPlaylistList();
        QList<Library::AudioTrack*> *trackList;
        for (int idx = 0; idx < playlistsList->size(); idx++)
        {
            playlistItem = new PlaylistItem(((*playlistsList)[idx])->getId(), ((*playlistsList)[idx])->getName(), TRUE);
            rootItem->appendRow(playlistItem);
            trackList = ((*playlistsList)[idx])->getTrackList();
            for (int trackIdx = 0; trackIdx < trackList->size(); trackIdx++)
            {
                trackItem = new PlaylistItem(((*trackList)[trackIdx])->getUid(), ((*trackList)[trackIdx])->getArtist() + " - " + ((*trackList)[trackIdx])->getTitle(), FALSE);
                playlistItem->appendRow(trackItem);
            }
        }
    }
    else
    {
        for (int idx = 0; idx < rootItem->rowCount(); idx++)
        {
            PlaylistItem *item = static_cast<PlaylistItem*>(rootItem->child(idx));
            if (item->itemIsPlaylist() && (item->getIdItem() == playlistId))
            {
                item->removeRows(0, item->rowCount());
                foreach (Library::AudioTrack *track, *(this->getPlaylists()->getPlaylistById(playlistId)->getTrackList()))
                {
                    trackItem = new PlaylistItem(track->getUid(), track->getArtist() + " - " + track->getTitle(), FALSE);
                    item->appendRow(trackItem);
                };
            }
        }
    }
}

int         PlaylistsModel::getIdByIndex(const QModelIndex &index) const
{
    PlaylistItem *item = static_cast<PlaylistItem *>(this->itemFromIndex(index));
    return item->getIdItem();
}

void        PlaylistsModel::insertPlaylist(int playlistId)
{
    PlaylistItem    *playlistItem;
    playlistItem = new PlaylistItem(playlistId, getPlaylists()->getPlaylistById(playlistId)->getName(), TRUE);
    rootItem->appendRow(playlistItem);
}

void        PlaylistsModel::deletePlaylist(int playlistId)
{
    int rowIndexToRemove = -1;
    for (int idx = 0; idx < rootItem->rowCount(); idx++)
    {
        PlaylistItem *item = static_cast<PlaylistItem*>(rootItem->child(idx));
        if (item->itemIsPlaylist() && (item->getIdItem() == playlistId))
        {
            item->removeRows(0, item->rowCount());
            rowIndexToRemove = idx;
        }
    }
    if(rowIndexToRemove != -1)
        rootItem->removeRow(rowIndexToRemove);
}

QMimeData *PlaylistsModel::mimeData(const QModelIndexList &indexes) const
{
        QMimeData *mimeData = new QMimeData();
        QByteArray encodedData;
        QDataStream stream(&encodedData, QIODevice::WriteOnly);
        PlaylistItem *item;

        foreach (const QModelIndex &index, indexes)
        {
            if (index.isValid())
            {
                item = static_cast<PlaylistItem *>(this->itemFromIndex(index));
                if (item->itemIsPlaylist())
                        foreach (Library::AudioTrack *track, *(playlists->getPlaylistById(item->getIdItem())->getTrackList()))
                            stream << track->getUid();
                else
                    stream << getIdByIndex(index);
            }
        }
        mimeData->setData("application/x-defuzeme-audiotrack", encodedData);
        return mimeData;
}
