#ifndef PLAYLISTSWIDGET_HPP
#define PLAYLISTSWIDGET_HPP

#include "guicore.hpp"
#include "ui_playlistswidget.h"
#include "playliststreeview.hpp"

namespace Playlists
{

class PlaylistsPlugin;

class PlaylistsWidget : public Gui::ModuleWidget, private Ui::PlaylistsWidget
{
	Q_OBJECT

public:
	explicit PlaylistsWidget(PlaylistsPlugin *playlists, QWidget *parent = 0);
	QPushButton		*getButtonAdd() const;
	QLineEdit		*getLineEditAdd() const;
        PlaylistsTreeView               *getTreeView() const;

protected:
	void changeEvent(QEvent *e);

private:
	PlaylistsPlugin *playlists;

private slots:

	void			on_buttonAdd_clicked();
};

}

#endif // PLAYLISTSWIDGET_HPP
