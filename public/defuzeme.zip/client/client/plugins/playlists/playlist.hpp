#ifndef PLAYLIST_HPP
#define PLAYLIST_HPP

#include <QObject>
#include "audiotrack.hpp"

namespace Playlists
{
	class Playlist : public QObject
	{
		Q_OBJECT
	public:
		Playlist(int id);
		int				getId() const;
		const QString&	getName() const;
		bool			getIsDynamic() const;
		void			setName(const QString newName);
                QList<Library::AudioTrack*>	*getTrackList() const;
                void                    addTrack(int trackId, int idx = -1);
                void                    updatePlaylist();

	private:
		int				id;
		QString			name;
		bool			isDynamic;
                QList<Library::AudioTrack*>	*trackList;
	};
}

#endif // PLAYLIST_H
