#include "playlist.hpp"
#include "parser.hpp"

#include <QSqlQuery>
#include <QDebug>

using namespace Playlists;

Playlist::Playlist(int id)
{
	this->trackList = new QList<Library::AudioTrack*>();
	QSqlQuery query;
	query.prepare("SELECT id, name, is_dynamic, definition "
				  "FROM playlists WHERE id = :id LIMIT 1");
	query.bindValue(":id", id);
	query.exec();
	if (query.first())
	{
		this->id = query.value(0).toInt();
		this->name = query.value(1).toString();
		this->isDynamic = query.value(2).toBool();
		QList<QVariant> list = Network::JsonParser().parse(query.value(3).toByteArray()).toList();
		this->trackList = new QList<Library::AudioTrack*>();
		foreach (QVariant id, list)
		{
			this->trackList->append(Library::AudioTrack::getTrack(id.toInt()));
		}

	}
	else
		qDebug() << "No playlist with id " << id;
}

int				Playlist::getId() const
{
	return this->id;
}

const QString	&Playlist::getName() const
{
	return this->name;
}

bool			Playlist::getIsDynamic() const
{
	return this->isDynamic;
}

void			Playlist::setName(const QString newName)
{
	this->name = newName;
}

QList<Library::AudioTrack*>	*Playlist::getTrackList() const
{
	return this->trackList;
}

void    Playlist::addTrack(int trackId, int idx)
{
	if (idx == -1)
		this->trackList->append(Library::AudioTrack::getTrack(trackId));
	else
		this->trackList->insert(idx, Library::AudioTrack::getTrack(trackId));

}

void    Playlist::updatePlaylist()
{
	QSqlQuery query;

	query.prepare("UPDATE playlists SET name = :name, is_dynamic = :is_dynamic, definition = :definition "
				  "WHERE id = :id");
	query.bindValue(":name", name);
	query.bindValue(":is_dynamic", isDynamic);
	QList<QVariant> *list = new QList<QVariant>();
	foreach (Library::AudioTrack* track, *trackList)
	{
		list->append(track->getUid());
	}

	query.bindValue(":definition", Network::JsonParser().serialize(*list));
	query.bindValue(":id", id);
	if (!query.exec())
		qDebug() << "Impossible playlist update " << id;
}
