#include "playlists.hpp"

#include <QSqlQuery>
#include <QListWidget>

using namespace Playlists;

PlaylistsPlugin::PlaylistsPlugin()
{
}

PlaylistsPlugin::~PlaylistsPlugin()
{
}

void    PlaylistsPlugin::init()
{
	widget = new PlaylistsWidget(this);
	model = new PlaylistsModel(this);
	playlistsList = new QList<Playlist*>();
        widget->getTreeView()->setModel(model);
	loadPlaylists();
        this->model->update();
        Gui::Module *playlistsModule = Gui::ModuleFactory::create("Playlists", QPoint(0, 0), widget, 0);
	playlistsModule->submitForDisplay();
}

void    PlaylistsPlugin::aboutToQuit()
{
}

PlaylistsModel  *PlaylistsPlugin::getModel() const
{
	return model;
}

PlaylistsWidget *PlaylistsPlugin::getWidget() const
{
	return widget;
}

QList<Playlist*> *PlaylistsPlugin::getPlaylistList() const
{
	return this->playlistsList;
}

void    PlaylistsPlugin::loadPlaylists()
{

	this->playlistsList->clear();

        QSqlQuery query("SELECT id, name FROM playlists ORDER BY name");

	if (!query.exec())
			throw_exception(0x01, tr("Can't load playlists: %1").arg(query.lastError().text()));
		while (query.next())
		{
			playlistsList->push_back(new Playlist(query.value(0).toInt()));
			playlistsList->back()->setName(query.value(1).toString());
		}
}

void            PlaylistsPlugin::addPlaylist(QString name)
{
	QSqlQuery query;
        if (name.isNull() || name.isEmpty())
            return;
        foreach (Playlist *playlist, *playlistsList)
        {
            if (playlist->getName().trimmed().compare(name.trimmed()) == 0)
                return;
            //TODO: Affichage d'un message d'erreur;
        }

        query.prepare("INSERT INTO playlists(name, is_dynamic, definition) VALUES (:name, :is_dynamic, :definition)");
        query.bindValue(":name", name.trimmed());
        query.bindValue(":is_dynamic", false);
	query.bindValue(":definition", "");
	if (!query.exec())
			throw_exception(0x01, tr("Can't create playlist: %1").arg(query.lastError().text()));
        widget->getLineEditAdd()->setText("");
        loadPlaylists();
        foreach(Playlist *playlist, *playlistsList)
        {
            if (playlist->getName().compare(name.trimmed()) == 0)
                this->model->insertPlaylist(playlist->getId());
        }
}

void            PlaylistsPlugin::deletePlaylist(int idPlaylist)
{
    QSqlQuery query;
    query.prepare("DELETE FROM playlists WHERE (id = :id)");
    query.bindValue(":id", idPlaylist);
    if (!query.exec())
                    throw_exception(0x01, tr("Can't delete playlist: %1").arg(query.lastError().text()));
    loadPlaylists();
    this->model->deletePlaylist(idPlaylist);
}

Playlist  *PlaylistsPlugin::getPlaylistById(int playlistId)
{
    foreach (Playlist *playlist, *playlistsList)
    {
        if (playlist->getId() == playlistId)
            return playlist;
    }
    return NULL;
}
