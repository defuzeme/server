.pragma library

var lastfm_black_logo = "http://cdn.last.fm/flatness/badges/lastfm_black_small.gif"

//***********\\
//** STYLE **\\
//***********\\

var background_color = "#2d2d2d"				/// The main background color
var text_color = "#ffffff"						/// The main text color

/// PageTitle

var title_gradient_top = background_color
var title_gradient_bottom = "#000000"
var title_text_color = text_color
var title_description_color = title_text_color

/// OptionsBar

var options_background_color = title_gradient_bottom
