/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "lastfmwidget.hpp"
#include <QGraphicsObject>
#include <QDebug>
#include <QResource>
#include <QDeclarativeEngine>
#include <QDesktopServices>

using namespace Lastfm;

LastfmWidget::LastfmWidget(QWidget *parent) :
	ModuleWidget(parent)
{
	setupUi(this);
	declarativeView = new QDeclarativeView;
	declarativeView->engine()->setOfflineStoragePath(QDesktopServices::storageLocation(QDesktopServices::DataLocation));
	qDebug() << "Offline storage path: " << declarativeView->engine()->offlineStoragePath();
	declarativeView->setResizeMode(QDeclarativeView::SizeRootObjectToView);
	declarativeView->setSource(QUrl::fromLocalFile("../client/plugins/lastfm/LastfmView.qml"));
//	QResource::registerResource("/usr/local/lib/defuze.me/lastfm.rcc");
//	QResource::registerResource("resources/lastfm.rcc");
//	QResource::registerResource("../resources/lastfm.rcc");
//	QResource::registerResource("/Applications/defuze.me.app/Contents/resources/lastfm.rcc");
//	declarativeView->setSource(QUrl("qrc:/qml/lastfm/LastfmView.qml"));
	verticalLayout->addWidget(declarativeView);
}

void LastfmWidget::changeEvent(QEvent *e)
{
	QWidget::changeEvent(e);
	switch (e->type()) {
	case QEvent::LanguageChange:
		retranslateUi(this);
		break;
	default:
		break;
	}
}
