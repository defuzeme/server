/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef LASTFMWIDGET_HPP
#define LASTFMWIDGET_HPP

#include "ui_lastfmwidget.h"
#include "guicore.hpp"
#include <QDeclarativeView>

namespace Lastfm
{

	/** Contains the QML app allowing to discover music using the lastfm api.
	  **/

	class LastfmWidget : public Gui::ModuleWidget, private Ui::LastfmWidget
	{
		Q_OBJECT

	public:
		explicit LastfmWidget(QWidget *parent = 0);

	protected:
		void changeEvent(QEvent *e);

	private:
		QDeclarativeView *declarativeView;
	};

}

#endif // LASTFMWIDGET_HPP
