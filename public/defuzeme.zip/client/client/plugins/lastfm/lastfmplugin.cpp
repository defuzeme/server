/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "lastfmplugin.hpp"

using namespace Lastfm;

LastfmPlugin::LastfmPlugin()
{
	widget = new LastfmWidget;

	Gui::Module *lastfmModule = Gui::ModuleFactory::create("lastfm", QPoint(0, 0), widget, 2);
	lastfmModule->submitForDisplay();

	Gui::Module *tmp = Gui::ModuleFactory::create("tmp", QPoint(1, 0), new Gui::ModuleWidget, 2);
	tmp->submitForDisplay();

	Gui::Module *tmp2 = Gui::ModuleFactory::create("tmp2", QPoint(2, 0), new Gui::ModuleWidget, 2);
	tmp2->submitForDisplay();
}

void LastfmPlugin::init()
{

}
