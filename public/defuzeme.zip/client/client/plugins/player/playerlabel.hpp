#ifndef PLAYERLABEL_HPP
#define PLAYERLABEL_HPP

#include <QWidget>
#include <QPainter>
#include <QStyledItemDelegate>

namespace Player
{
	class PlayerLabel : public QWidget
	{
		Q_OBJECT
	public:
		explicit PlayerLabel(QWidget *parent = 0);
		void	paintEvent(QPaintEvent *);
		void	setRight();
		void	setCurrent();
		void	setNext();

		static QColor	currentColor();
		static QColor	nextColor();
	signals:

	public slots:

	private:
		QColor			color;
		QString			text;
		bool			right;
		QPainter		painter;
		QPolygon	letterPolygonA, textPolygonA;
		QPolygon	letterPolygonB, textPolygonB;

	};
}

#endif // PLAYERLABEL_HPP
