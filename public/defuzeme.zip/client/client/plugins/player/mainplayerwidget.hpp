/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef MAINPLAYERWIDGET_HPP
#define MAINPLAYERWIDGET_HPP

#include "ui_mainplayerwidget.h"
#include "guicore.hpp"
#include "mainplayer.hpp"

namespace Player
{
	class MainPlayer;

	class MainPlayerWidget : public Gui::ModuleWidget, private Ui::MainPlayerWidget
	{
		Q_OBJECT
		friend class MainPlayer;

	public:
		explicit MainPlayerWidget(MainPlayer *player, QWidget *parent = 0);
		void	setNextButtonIcon(const QIcon &icon);
		void	setACurrent();
		void	setANext();
		void	setBNext();
		void	setBCurrent();
private slots:
		void on_nextButton_clicked();
	signals:
		void	nextButton_clicked();
	};
}
#endif // MAINPLAYERWIDGET_HPP
