/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "mainplayerwidget.hpp"
#include "mainplayer.hpp"

using namespace Player;

MainPlayerWidget::MainPlayerWidget(MainPlayer *player, QWidget *parent) :
	Gui::ModuleWidget(parent)
{
	setupUi(this);

	nextButton->setIcon(this->style()->standardIcon(QStyle::SP_MediaSkipForward));
	labelB->setRight();
	labelA->setCurrent();
	labelB->setNext();
	player->setPlayers(playerA, playerB);
}


void Player::MainPlayerWidget::on_nextButton_clicked()
{
	emit nextButton_clicked();
}

void MainPlayerWidget::setNextButtonIcon(const QIcon &icon)
{
	nextButton->setIcon(icon);
}

void MainPlayerWidget::setACurrent()
{
	labelA->setCurrent();
}

void MainPlayerWidget::setBCurrent()
{
	labelB->setCurrent();
}
void MainPlayerWidget::setANext()
{
	labelA->setNext();
}
void MainPlayerWidget::setBNext()
{
	labelB->setNext();
}
