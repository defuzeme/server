/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef AUDIOPLAYERWIDGET_HPP
#define AUDIOPLAYERWIDGET_HPP

#include "ui_audioplayerwidget.h"
#include "guicore.hpp"
#include "audiotrack.hpp"

namespace Player
{
	enum PlayerWidgetState
	{
		NoFile = -1,
		Stopped,
		Playing,
		Paused,
		Disabled
	};
	class AudioPlayerWidget : public QWidget, private Ui::AudioPlayerWidget
	{
		Q_OBJECT
		friend class MainPlayer;

	public:
		explicit AudioPlayerWidget(QWidget *parent = 0);
		PlayerWidgetState state() const;
		void	setState(PlayerWidgetState);
		void	setTrackName(const QString& name);
		void	setTimeLabel(const QString& time);
		void	setPosition(int position);
		void	setTrackInfo(Library::AudioTrack*track = 0);
		void	setDuration(int duration);
		void	invertDirection();
	protected:
		void changeEvent(QEvent *e);
	private slots:
		void on_playButton_clicked();
		void on_stopButton_clicked();

		void on_positionSlider_valueChanged(int value);
		void on_positionSlider_sliderMoved(int position);
		void on_positionSlider_sliderPressed();
		void on_positionSlider_sliderReleased();

	signals:
		void playButton_clicked();
		void stopButton_clicked();
		void positionSlider_pressed();
		void positionSlider_moved();
		void positionSlider_released(int pos);

	private:
		bool				_updatePosition;
		int					_duration;
		PlayerWidgetState	_state;
	};
}
#endif // AUDIOPLAYERWIDGET_HPP
