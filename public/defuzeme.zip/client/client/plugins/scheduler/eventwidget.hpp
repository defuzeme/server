#ifndef EVENTWIDGET_HPP
#define EVENTWIDGET_HPP

#include <QLabel>
#include <QSqlQuery>
#include <QStandardItemModel>
#include <QTreeView>

#include "guicore.hpp"
#include "ui_eventwidget.h"
#include "scheduler.hpp"
#include "eventmodel.hpp"
#include "eventplaylist.hpp"

namespace Scheduler
{

class EventColor;
class EventModel;
class EventPlaylist;
class SchedulerPlugin;

class EventWidget : public Gui::ModuleWidget, private Ui::EventWidget
{
	Q_OBJECT
public:
	explicit EventWidget(SchedulerPlugin *scheduler, QWidget *parent = 0);

	void						clear();
	void						setUpdate(EventModel *updateEvent);

	QList<EventColor*>			*colors;
	SchedulerPlugin				*scheduler;
	Playlists::PlaylistsPlugin	*playlistsPlugin;
	QList<Playlists::Playlist*>	*playlists;
	EventPlaylist				*playlistsWidget;

private:
	bool						check();
	void						initialize();
	void						updateEvent();

protected:
	EventModel					*event;

signals:
	void						newEvent(Scheduler::EventModel*);
	void						updateEvent(Scheduler::EventModel*);
	void						removeEvent(Scheduler::EventModel*);

public slots:
	void						on_submitEventButton_clicked();
	void						on_deleteEventButton_clicked();
};
}

#endif // EVENTWIDGET_HPP
