#include "schedulermodel.hpp"
#include "scheduler.hpp"
#include "eventmodel.hpp"

using namespace Scheduler;

SchedulerModel::SchedulerModel(SchedulerPlugin *scheduler) : scheduler(scheduler), events(0)
{
}

SchedulerModel::~SchedulerModel()
{
	for (int index = 0; index < this->events->count() ; index += 1)
		delete this->events->at(index);
	delete events;
}

SchedulerPlugin	*SchedulerModel::getScheduler() const
{
	return this->scheduler;
}

void	SchedulerModel::loadEvents()
{
	this->getEvents();

	for (int index = 0; index < events->count(); index += 1 )
	{
		EventModel	*event = events->at(index);
		this->scheduler->getWidget()->displayEvent(event);
		emit loadEvent(event);
	}
}

void	SchedulerModel::clearEvents()
{
	for (int index = 0; index < this->events->count(); index +=1 )
		delete this->events->at(index);
}

QList<EventModel*>	*SchedulerModel::getEvents()
{
	if (!events)
	{
		QSqlQuery	query("SELECT id, title, description, day, start, duration FROM events");
		query.exec();
		events		= new QList<EventModel*>();

		while (query.next())
		{
			int		id			= query.value(0).toInt();
			QString	title		= query.value(1).toString();
			QString	description	= query.value(2).toString();
			short	day			= query.value(3).toInt();
			int		start		= query.value(4).toInt();
			int		duration	= query.value(5).toInt();

			EventModel *event	= new EventModel(scheduler, title, description, day, start, duration, id);

			this->events->append(event);
		}
	}
	return events;
}

EventModel*		SchedulerModel::getEvent(int id)
{
	foreach(EventModel* event, *getEvents())
		if (event->getId() == id)
			return event;
	return 0;
}
