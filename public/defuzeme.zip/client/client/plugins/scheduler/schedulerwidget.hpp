#ifndef SCHEDULERWIDGET_HPP
#define SCHEDULERWIDGET_HPP

#include "guicore.hpp"
#include "ui_schedulerwidget.h"
#include "eventmodel.hpp"

#include <QFont>

namespace Scheduler
{

class EventModel;
class SchedulerPlugin;

class SchedulerWidget : public Gui::ModuleWidget, private Ui::SchedulerWidget
{
	Q_OBJECT

public:
	explicit SchedulerWidget(SchedulerPlugin *scheduler, QWidget *parent = 0);
	QGridLayout			*getLayout() const;

	void				setHorizontalHeader();
	void				setVerticalHeader();
	void				setGrid();
	void				initialize();

	QList<EventModel*>	*getEvents();
	void				displayEvent(EventModel *event);
	void				removeEvent(EventModel *event);

protected:
	void				changeEvent(QEvent *e);
	void				mousePressEvent(QMouseEvent *);

private:
	SchedulerPlugin		*scheduler;
	QList<EventModel*>	*events;

signals:
	void				clicked();

public slots:
	void				gridClicked();

};

}

#endif // SCHEDULERWIDGET_HPP
