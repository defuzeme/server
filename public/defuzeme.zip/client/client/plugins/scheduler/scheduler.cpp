#include "scheduler.hpp"

using namespace Scheduler;

SchedulerPlugin::SchedulerPlugin()
{
}

SchedulerPlugin::~SchedulerPlugin()
{
}

Plugins *SchedulerPlugin::getPlugins()
{
    return this->plugins;
}

void    SchedulerPlugin::init()
{
	eventWidget     = new EventWidget(this);
	schedulerWidget = new SchedulerWidget(this);
	schedulerModel  = new SchedulerModel(this);

	connect(eventWidget, SIGNAL(newEvent(Scheduler::EventModel*)), SIGNAL(newEvent(Scheduler::EventModel*)));
	connect(eventWidget, SIGNAL(updateEvent(Scheduler::EventModel*)), SIGNAL(updateEvent(Scheduler::EventModel*)));
	connect(eventWidget, SIGNAL(removeEvent(Scheduler::EventModel*)), SIGNAL(removeEvent(Scheduler::EventModel*)));
	connect(schedulerModel, SIGNAL(loadEvent(Scheduler::EventModel*)), SIGNAL(loadEvent(Scheduler::EventModel*)));

	loadScheduler();
	Gui::Module *eventModule = Gui::ModuleFactory::create("Event Manager", QPoint(0, 1), eventWidget, 1);
	Gui::Module *schedulerModule = Gui::ModuleFactory::create("Scheduler", QPoint(1, 0), schedulerWidget, 1);
	eventModule->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Maximum);
	eventModule->submitForDisplay();
	schedulerModule->submitForDisplay();
}

EventModel*		SchedulerPlugin::getEvent(int id)
{
	return schedulerModel->getEvent(id);
}

void	SchedulerPlugin::aboutToQuit()
{
}

SchedulerModel  *SchedulerPlugin::getModel() const
{
	return schedulerModel;
}

SchedulerWidget *SchedulerPlugin::getWidget() const
{
	return schedulerWidget;
}

EventWidget *SchedulerPlugin::getEventWidget() const
{
	return eventWidget;
}

void	SchedulerPlugin::loadScheduler()
{
	this->schedulerModel->loadEvents();
}
