#ifndef SCHEDULER_HPP
#define SCHEDULER_HPP

#define	SCALE	4

#include <QColor>
#include <QList>
#include <QSqlQuery>
#include <QTableView>

#include "staticplugin.hpp"
#include "playlists/playlists.hpp"

#include "eventcolor.hpp"
#include "eventmodel.hpp"
#include "eventplaylist.hpp"
#include "eventplaylistitem.hpp"
#include "eventwidget.hpp"

#include "schedulerwidget.hpp"
#include "schedulermodel.hpp"

namespace Scheduler
{

	class EventModel;
	class EventWidget;
	class SchedulerModel;
	class SchedulerWidget;

	class SchedulerPlugin : public QObject, public StaticPlugin
	{
		Q_OBJECT
	public:
		SchedulerPlugin();
		~SchedulerPlugin();
		Plugins					*getPlugins();
		void					init();
		void					aboutToQuit();
		SchedulerModel			*getModel() const;
		SchedulerWidget			*getWidget() const;
		EventWidget				*getEventWidget() const;
		EventModel*				getEvent(int id);
		void					addScheduler(QString name);
		void					loadScheduler();

	signals:
		void					newEvent(Scheduler::EventModel* event);
		void					updateEvent(Scheduler::EventModel* event);
		void					removeEvent(Scheduler::EventModel* event);
		void					loadEvent(Scheduler::EventModel* event);

	private:
		SchedulerModel			*schedulerModel;
		EventWidget				*eventWidget;
		SchedulerWidget			*schedulerWidget;

	};

}

#endif // SCHEDULER_HPP
