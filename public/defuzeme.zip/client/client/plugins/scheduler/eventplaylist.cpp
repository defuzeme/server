#include "eventplaylist.hpp"

using namespace Scheduler;

EventPlaylist::EventPlaylist(EventWidget *parent) : QListWidget((QWidget*)parent), parent(parent)
{
	this->setSelectionMode(QAbstractItemView::ExtendedSelection);

	this->setStyleSheet("min-height: 150px; border-top-right-radius: 8px; border-bottom-right-radius: 8px;");

	return;
}

// @TODO Need to be sync with playlists changes
void	EventPlaylist::loadPlaylists()
{
	this->playlists = QList<EventPlaylistItem*>();

	for (int index = 0; index < this->parent->playlists->count(); index += 1)
	{
		int			id		= this->parent->playlists->at(index)->getId();
		QString		name	= this->parent->playlists->at(index)->getName();

		this->playlists.append(new EventPlaylistItem(this, id, name));
	}

	return;
}

QList<int>	EventPlaylist::getSelectedPlaylists()
{
	QList<int>	items = QList<int>();

	for (int index = 0; index < this->selectedItems().count(); index += 1)
	{
		if (this->selectedItems().at(index)->isSelected())
		{
			items.append(((EventPlaylistItem*)this->selectedItems().at(index))->id);
		}
	}

	return	items;
}

QModelIndex	EventPlaylist::indexFromItem(QListWidgetItem *item) const
{
	return	QListWidget::indexFromItem(item);
}
