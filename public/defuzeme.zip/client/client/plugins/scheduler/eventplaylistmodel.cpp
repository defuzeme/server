#include "eventplaylistmodel.hpp"

using namespace Scheduler;

EventPlaylistModel::EventPlaylistModel()
{
	rootItem = invisibleRootItem();
}
