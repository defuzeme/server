#ifndef EVENTCOLOR_HPP
#define EVENTCOLOR_HPP

#include <QPushButton>

#include "scheduler.hpp"

namespace Scheduler
{

class EventColor : public QPushButton
{
	Q_OBJECT
public:
	EventColor(QWidget *parent = 0, int id = 0, QString color = "FFFFFF");
	virtual		~EventColor();

	int			getId() const;
	QString		getColor() const;

public slots:
	void		on_colorPicker_clicked();

private:
	QWidget		*parent;

	int			id;
	QString		color;
};
}

#endif // EVENTCOLOR_HPP
