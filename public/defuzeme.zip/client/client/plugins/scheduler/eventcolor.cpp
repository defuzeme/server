#include "eventcolor.hpp"

using namespace Scheduler;

EventColor::EventColor(QWidget *parent, int id, QString color) :
	parent(parent), id(id), color(color)
{
	QColor  *newColor				= new QColor("#" + color);
	QString borderColor				= newColor->lighter(95).name();
	QString backgroundColor			= newColor->lighter(70).name();
	QString borderColorSelected		= newColor->lighter(25).name();
	QString backgroundColorSelected	= newColor->lighter(45).name();

	this->setCheckable(true);
	this->setStyleSheet("\
						QPushButton { border: 1px solid " + borderColor + "; border-radius: 5px; background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 " + newColor->name() + ", stop: 1 " + backgroundColor + "); max-width: 20px; min-height: 20px; }\
						QPushButton:checked { border-color: " + borderColorSelected + "; background-color: qlineargradient(x1: 0, y1: 0, x2: 0, y2: 1, stop: 0 " + backgroundColorSelected + ", stop: 1 " + newColor->name() + "); }\
						");

	return;
}

EventColor::~EventColor()
{
}

int		EventColor::getId() const
{
	return this->id;
}

QString	EventColor::getColor() const
{
	return this->color;
}

void EventColor::on_colorPicker_clicked()
{
	if (this->parent)
	{
		int count = ((EventWidget*)this->parent)->colors->count();

		for (int index = 0; index < count; index += 1)
		{
			((EventWidget*)this->parent)->colors->at(index)->setChecked(false);
		}
		this->setChecked(true);
	}

	return;
}
