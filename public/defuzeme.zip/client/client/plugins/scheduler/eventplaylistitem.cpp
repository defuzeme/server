#include "eventplaylistitem.hpp"

using namespace Scheduler;

EventPlaylistItem::EventPlaylistItem(EventPlaylist *parent, int id, QString name) : QListWidgetItem((QListWidget*)parent), id(id), name(name)
{
	this->setText(name);
}
