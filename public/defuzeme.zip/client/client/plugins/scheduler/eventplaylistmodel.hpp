#ifndef EVENTPLAYLISTMODEL_HPP
#define EVENTPLAYLISTMODEL_HPP

#include <QStandardItemModel>

#include "scheduler.hpp"

namespace Scheduler
{

class EventPlaylistModel : public QStandardItemModel
{
public:
	EventPlaylistModel();

private:
	QList<QString>				playlists;
	QStandardItem				*rootItem;
	QHash<QModelIndex, int>		idByIndexes;
};

}

#endif // EVENTPLAYLISTMODEL_HPP
