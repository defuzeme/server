#ifndef EVENTPLAYLISTITEM_HPP
#define EVENTPLAYLISTITEM_HPP

#include <QObject>
#include <QListWidgetItem>

#include "scheduler.hpp"
#include "eventplaylist.hpp"

namespace Scheduler
{

class EventPlaylist;

class EventPlaylistItem : public QObject, public QListWidgetItem
{
    Q_OBJECT
public:
    explicit EventPlaylistItem(EventPlaylist *parent, int id, QString name);

    int             id;
    QString         name;

private:

    EventPlaylist   *parent;

signals:

public slots:

};

}

#endif // EVENTPLAYLISTITEM_HPP
