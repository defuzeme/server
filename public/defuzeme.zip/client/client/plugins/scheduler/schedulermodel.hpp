#ifndef SCHEDULERMODEL_HPP
#define SCHEDULERMODEL_HPP

#include <QStandardItemModel>
#include "eventmodel.hpp"

namespace Scheduler
{

	class EventModel;
	class SchedulerPlugin;

	class SchedulerModel : public QStandardItemModel
	{
		Q_OBJECT

	public:
		SchedulerModel(SchedulerPlugin *scheduler);
		~SchedulerModel();

		SchedulerPlugin		*getScheduler() const;

		void				loadEvents();
		void				clearEvents();
		QList<EventModel*>	*getEvents();
		EventModel*			getEvent(int id);

	signals:
		void				loadEvent(Scheduler::EventModel*);

	private:
		SchedulerPlugin		*scheduler;
		QList<EventModel*>	*events;
	};
}

#endif // SCHEDULERMODEL_HPP
