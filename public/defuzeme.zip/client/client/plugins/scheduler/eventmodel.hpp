#ifndef EVENTMODEL_HPP
#define EVENTMODEL_HPP

#include <QString>
#include <QLabel>
#include <QMouseEvent>
#include <QDebug>
#include <QSqlQuery>

#include "guicore.hpp"
#include "scheduler.hpp"
#include "eventplaylistitem.hpp"

namespace Scheduler
{

class SchedulerPlugin;

class EventModel : public QLabel
{
	Q_OBJECT
	friend class EventWidget;

public:
	EventModel(SchedulerPlugin *scheduler, QString title, QString description, short day, int start, int duration, int id = 0);

	int				save();
	void			saveColor(int color);
	void			savePlaylists(QList<int> playlists);

	int				getId() const;				///< Return the event id according to the database

	QString			getTitle() const;			///< Return the title of the event
	QString			getDescription() const;		///< Return the description

	short			getDay() const;				///< Return the day of the event (1-7)
	int				getStartTime() const;		///< Return the event start time (seconds)
	int				getDuration() const;		///< Return event duration (minutes)

	QDateTime		nextInstance() const;		///< Return next event start from now

	const QString&	getColor();					///< Return the color ( ex: "FFAD46" )
	int				getColorID();				///< Return the color id according to the database
	static const QString&	getColorByID(int colorID);	///< Return the color from database by its id ( ex: "FFAD46" )
	QList<int>		getPlaylists();				///< Return an int list of playlists associated to this event

	// Event styles
	void			focusIn();					///< Give the focus on the current event
	void			focusOut();					///< Get the focus out of the event
	void			setStyle();					///< Set the default style for the event + the appropriate color

	void			remove();					///< Delete the event from the database

private:
	SchedulerPlugin	*scheduler;

	int				id;

	QString			title;
	QString			description;

	short			day;
	int				start;
	int				duration;
	int				color;
	static QMap<int, QString>	colors;

public slots:
	void			eventClicked();

signals:
	void			clicked();

protected:
	void			mousePressEvent(QMouseEvent *);

};

}

#endif // EVENTMODEL_HPP
