#ifndef EVENTPLAYLIST_HPP
#define EVENTPLAYLIST_HPP

#include <QListWidget>

#include "playlists.hpp"
#include "scheduler.hpp"
#include "eventwidget.hpp"
#include "eventplaylistitem.hpp"

namespace Scheduler
{

class EventWidget;
class PlaylistsPlugin;
class EventPlaylistItem;

class EventPlaylist : public QListWidget
{
	Q_OBJECT
public:
	EventPlaylist(EventWidget *parent = 0);

	QModelIndex					indexFromItem(QListWidgetItem *item) const;

	void						loadPlaylists();
	QList<int>					getSelectedPlaylists();

private:
	EventWidget					*parent;
	QList<EventPlaylistItem*>	playlists;
};

}

#endif // EVENTPLAYLIST_HPP
