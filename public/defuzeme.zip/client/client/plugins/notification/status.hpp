/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

namespace Notification {
	class Status;
}

#ifndef STATUS_HPP
#define STATUS_HPP

#include "staticplugin.hpp"
#include "statuswidget.hpp"
#include "message.hpp"

namespace Notification
{
	// Some pre-defined icons
	const QString	OK = ":/icons/tick";
	const QString	INFO = ":/icons/info";
	const QString	SYNC = ":/icons/sync";
	const QString	WARN = ":/icons/warning";
	const QString	ERR = ":/icons/error";
	const QString	DEVICE = ":/icons/device-small";

	/** This class provide central notification methods.
	  * Messages are then stored and displayed in a UI module
	  **/

	class Status : public QObject, public StaticPlugin
	{
		Q_OBJECT
	public:
		explicit Status();
		~Status();
		void				aboutToQuit();
		void				init();
		static void			gMessage(const QString &msg, const QString& pix = INFO);	///< Add a notification message with an optional icon (thread safe)

	signals:
		void				forwardMessage(QString, QString);

	public slots:
		Message*			message(const QString &msg, const QString& pix = INFO);		///< Add a notification message and returns it for futher customization (thread UNSAFE)

	private:
		StatusWidget*		widget;
		Gui::Module			*uiModule;
		Message*			lastMessage;
		static Status		*instance;
		static QList<QPair<QString, QString> >	waitList;
	};
}

#endif // STATUS_HPP
