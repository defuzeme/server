/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

namespace Notification {
	class Message;
}

#ifndef MESSAGE_HPP
#define MESSAGE_HPP

#include <QPushButton>
#include "ui_message.h"

namespace Notification
{
	/** This class is the UI widget representing a notification message
	  **/

	class Message : public QWidget, private Ui::Message
	{
		Q_OBJECT
		friend class Status;

	public:
		void		setMessage(const QString& msg);
		void		setIcon(const QPixmap& pix);
		void		incrementCount();
		void		setAction(const QString& name, const QObject* obj, const char* method);

	protected:
		void		changeEvent(QEvent *e);

	private:
		explicit	Message(QWidget *parent = 0);		// Constructed by factory
		QPushButton	*actionBtn;
		QString		message;
		int			count;
	};
}

#endif // MESSAGE_HPP
