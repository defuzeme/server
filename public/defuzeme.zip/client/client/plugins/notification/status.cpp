/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "status.hpp"

using namespace Notification;

Status	*Status::instance = 0;
QList<QPair<QString, QString> >	Status::waitList;

Status::Status() : lastMessage(0)
{
	instance = this;
	widget = new StatusWidget(this);
	uiModule = Gui::ModuleFactory::create("Status", QPoint(2, 1), widget);
	uiModule->setSizePolicy(QSizePolicy::Maximum, QSizePolicy::Preferred);
	uiModule->submitForDisplay();
	connect(this, SIGNAL(forwardMessage(QString,QString)), SLOT(message(QString,QString)));
	while (!waitList.empty())
	{
		QPair<QString, QString>	&elem = waitList.first();
		emit forwardMessage(elem.first, elem.second);
		waitList.pop_front();
	}
}

Status::~Status()
{
	delete widget;
}

void	Status::init()
{
}

void	Status::aboutToQuit()
{
}

Message*	Status::message(const QString &msg, const QString& pix)
{
	if (lastMessage && lastMessage->message == msg)
	{
		// Message already exists, just increment count
		lastMessage->incrementCount();
		return lastMessage;
	}
	else
	{
		Message*	message = new Message(widget);
		QPixmap		pixmap(pix);

		message->setMessage(msg);
		if (!pixmap.isNull())
			message->setIcon(pixmap);
		widget->addMessage(message);
		lastMessage = message;
		return message;
	}
}

void	Status::gMessage(const QString &msg, const QString& pix)
{
	if (instance)
		emit instance->forwardMessage(msg, pix);
	else
		waitList << QPair<QString, QString>(msg, pix);
}
