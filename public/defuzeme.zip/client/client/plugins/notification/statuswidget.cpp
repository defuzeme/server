/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "statuswidget.hpp"

using namespace Notification;

StatusWidget::StatusWidget(Status *plugin) : plugin(plugin)
{
	setupUi(this);
}

void	StatusWidget::addMessage(Message* widget)
{
	static_cast<QVBoxLayout*>(scrollArea->layout())->insertWidget(0, widget);
}

void	StatusWidget::changeEvent(QEvent *e)
{
	QWidget::changeEvent(e);
	switch (e->type()) {
	case QEvent::LanguageChange:
		retranslateUi(this);
		break;
	default:
		break;
	}
}
