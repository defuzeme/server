/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "message.hpp"
#include <QDateTime>

using namespace Notification;

Message::Message(QWidget *parent) : QWidget(parent), actionBtn(0), count(1)
{
	setupUi(this);
	count_label->hide();
	QDateTime	t = QDateTime::currentDateTime();
	date->setText(t.toString("hh:mm"));
}

void Message::changeEvent(QEvent *e)
{
	QWidget::changeEvent(e);
	switch (e->type()) {
	case QEvent::LanguageChange:
		retranslateUi(this);
		break;
	default:
		break;
	}
}

void	Message::setMessage(const QString& msg)
{
	message = msg;
	label->setText(msg);
}

void	Message::setIcon(const QPixmap& pix)
{
	icon->setPixmap(pix);
}

void	Message::incrementCount()
{
	count++;
	count_label->setText(QString("x%1").arg(count));
	count_label->show();
	QDateTime	t = QDateTime::currentDateTime();
	date->setText(t.toString("hh:mm"));
}

void	Message::setAction(const QString& name, const QObject* obj, const char* method)
{
	actionBtn = new QPushButton(name, this);

	connect(actionBtn, SIGNAL(clicked()), obj, method);
	frame->layout()->addWidget(actionBtn);
}
