/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

namespace Notification {
	class StatusWidget;
}

#ifndef STATUSWIDGET_HPP
#define STATUSWIDGET_HPP

#include "ui_statuswidget.h"
#include "guicore.hpp"
#include "status.hpp"
#include "message.hpp"

namespace Notification
{
	/** This class is the UI module displaying global notifications
	  **/

	class StatusWidget : public Gui::ModuleWidget, private Ui::StatusWidget
	{
		Q_OBJECT
		friend class Status;

	public:
		explicit StatusWidget(Status *plugin);

	protected:
		void		changeEvent(QEvent *e);
		void		addMessage(Message*widget);

	private:
		Status*		plugin;
	};
}

#endif // STATUSWIDGET_HPP
