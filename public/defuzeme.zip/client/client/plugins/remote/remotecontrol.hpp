/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

namespace Remote {
	class RemoteControl;
}

#ifndef REMOTECONTROL_HPP
#define REMOTECONTROL_HPP

#include <QObject>
#include <QSet>
#include "staticplugin.hpp"
#include "networkcore.hpp"
#include "playqueue.hpp"
#include "mainplayer.hpp"

using namespace Network;

namespace Remote
{
	/** This class handle remote control through mobile devices.
	  * Connection & Authentication is handled by the NetworkCore
	  **/

	class RemoteControl : public QObject, public StaticPlugin
	{
		Q_OBJECT
	public:
		explicit RemoteControl();
		virtual ~RemoteControl();
		void				init();								///< Automatically called after plugin referencing
		void				sendToAll(const QString& event, const QVariantMap& data = QVariantMap());

	signals:

	public slots:
		void				newRemoteClient(RemoteSock*);		///< Slot called by doorman when a new client authenticated
		void				removeRemoteClient();				///< Slot called when a client disconnected
		void				receiveEvent(const RemoteEvent&);	///< Slot called when a packet is received from the mobile device

		void				popQueue();
		void				removeQueueElem(Queue::Queueable* elem);
		void				addQueueElem(Queue::Queueable* elem);
		void				removeQueueElem(const RemoteEvent &packet);
		void				addQueueElem(const RemoteEvent &packet);
		void				moveQueueElem(const RemoteEvent &packet);
		void				play(const RemoteEvent &packet);
		void				pause(const RemoteEvent &packet);
		void				stop(const RemoteEvent &packet);
		void				next(const RemoteEvent &packet);
		void				playStatusChanged();

	private:
		void				sendPlayQueue(RemoteSock* client);	///< Send all the current playing queue
		void				sendPlayState(RemoteSock* client);	///< Send the current playing status

		QSet<RemoteSock*>	clients;
		Queue::PlayQueue*	play_queue;
		Player::MainPlayer*	player;
	};
}

#endif // REMOTECONTROL_HPP
