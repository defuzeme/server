/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "plugins.hpp"
#include "exception.hpp"
#include "logger.hpp"
#include "playqueue.hpp"
#include "library.hpp"
#include "playlists.hpp"
#include "listsplugin.hpp"
#include "scheduler.hpp"
#include "remotecontrol.hpp"
#include "mainplayer.hpp"
#include "servicesync.hpp"
#include "audiomixerplugin.hpp"
#include "status.hpp"
#include "lastfmplugin.hpp"

Plugins::Plugins(Cores *c) : QObject(NULL), cores(*c)
{
	add("player", new Player::MainPlayer("Player"));
	add("queue", new Queue::PlayQueue);
	add("mixer", new Mixer::AudioMixerPlugin);
	add("library", new Library::LibraryPlugin);
	add("playlists", new Playlists::PlaylistsPlugin);
	add("lists", new Lists::ListsPlugin);
	add("remote", new Remote::RemoteControl);
	add("web_service", new WebService::ServiceSync);
	add("status", new Notification::Status);
	add("scheduler", new Scheduler::SchedulerPlugin);
	add("lastfm", new Lastfm::LastfmPlugin);
}

Plugins::~Plugins()
{
	QHash<QString, Plugin*>::iterator	it;
	for (it = plugins.begin(); it != plugins.end(); it++)
	{
		Logger::log(QString("Deleting plugin: %1").arg(it.key()));
		delete it.value();
	}
}

void	Plugins::add(const QString& name, Plugin* plugin)
{
	if (plugins.contains(name))
		throw_exception(0x01, tr("2 plugins added with the same name: %1").arg(name));
	plugins[name] = plugin;
	plugin->setReferences(cores, *this);
}

Plugin*		Plugins::get(const QString& name)
{
	return plugins.value(name);
}

void	Plugins::init()
{
	QHash<QString, Plugin*>::iterator	it;
	for (it = plugins.begin(); it != plugins.end(); it++)
	{
		QString	msg = QString("Initializing plugin: %1").arg(it.key());
		Logger::log(msg);
		emit message(msg);
		it.value()->init();
	}
}

void	Plugins::aboutToQuit()
{
	QHash<QString, Plugin*>::iterator	it;
	for (it = plugins.begin(); it != plugins.end(); it++)
	{
		Logger::log(QString("Exiting plugin: %1").arg(it.key()));
		it.value()->aboutToQuit();
	}
	deleteLater();
}
