/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

namespace Queue {
	class QueueTrack;
}

#ifndef QUEUETRACK_HPP
#define QUEUETRACK_HPP

#include <QVariantMap>
#include "queueable.hpp"
#include "library/audiotrack.hpp"

namespace Queue {

	/** This class inherits Queueable an represent a track in the play queue.
	  *
	  * It is used to associate an AudioTrack with a position and a widget in the PlayQueue
	  **/

	class QueueTrack : public Queueable
	{
		Q_OBJECT
	public:
		QueueTrack(Library::AudioTrack& track);
		~QueueTrack();
		Library::AudioTrack*	getTrack() const;
		Library::AudioTrack*	getTrack();
		int						queueDuration(QDateTime from) const;		///< virtual method returning element's duration tu calculate queue length
		QVariantMap				getContent(bool	forWeb = false) const;		///< virtual method returning track's information for mobile devices
		QString					queueType() const;
		int						queueId() const;
		Queueable*				clone() const;

	signals:

	private:
		Library::AudioTrack		&track;
	};
}
#endif // QUEUETRACK_HPP
