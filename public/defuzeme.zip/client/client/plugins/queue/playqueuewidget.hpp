/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef PLAYQUEUEWIDGET_HPP
#define PLAYQUEUEWIDGET_HPP

#include <QWidget>
#include <QAbstractItemModel>
#include "guicore.hpp"
#include "ui_playqueuewidget.h"

namespace Queue {
	/** This is the entire playqueue UI module
	  **/
	class PlayQueueWidget : public Gui::ModuleWidget, private Ui::PlayQueueWidget
	{
		Q_OBJECT

	public:
		explicit PlayQueueWidget(QAbstractItemModel *model);
		~PlayQueueWidget();
		void		setItemWidget(const QModelIndex &index, QWidget *widget);
		void		keyReleaseEvent(QKeyEvent *event);
		QItemSelectionModel*	selectionModel() const;

	signals:
		void		deleteElements();
		void		clearListFocus();
	};
}

#endif // PLAYQUEUEWIDGET_HPP
