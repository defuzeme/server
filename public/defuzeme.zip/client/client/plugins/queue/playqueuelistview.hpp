/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef PLAYQUEUELISTVIEW_HPP
#define PLAYQUEUELISTVIEW_HPP

#include <QListView>
#include <QDragMoveEvent>

/** This is the custom ListView used to display play queue elements
  **/
class PlayQueueListView : public QListView
{
	Q_OBJECT
public:
	explicit PlayQueueListView(QWidget *parent = 0);
	void	dragEnterEvent(QDragEnterEvent *event);
	void	dragMoveEvent(QDragMoveEvent *event);
//	void	focusInEvent(QFocusEvent *event);
	void	focusOutEvent(QFocusEvent *event);

signals:
	void	focusOut();

public slots:

};

#endif // PLAYQUEUELISTVIEW_HPP
