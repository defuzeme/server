/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef PLAYQUEUEDELEGATE_HPP
#define PLAYQUEUEDELEGATE_HPP

#include <QStyledItemDelegate>
#include "plugins.hpp"
#include "playqueue.hpp"

namespace Queue
{
	/** The PlayQueueDelegate class provides a custom visual rendering for play queue elements
	  **/
	class PlayQueueDelegate : public QStyledItemDelegate
	{
		Q_OBJECT
	public:
		explicit	PlayQueueDelegate(PlayQueue *queue);
		void		paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const;
		QSize		sizeHint(const QStyleOptionViewItem &option, const QModelIndex &index) const;

	signals:

	public slots:
	private:
		QPolygon	positionPolygon, timePolygon;
		PlayQueue	*queue;
	};
}

#endif // PLAYQUEUEDELEGATE_HPP
