/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "queuebreak.hpp"

using namespace Queue;

QueueBreak::QueueBreak()
{
}

QueueBreak::QueueBreak(int duration)
{
	setDuration(duration);
}

QueueBreak::QueueBreak(QDateTime end)
{
	setEnd(end);
}

QueueBreak::~QueueBreak()
{
}

int			QueueBreak::duration() const
{
	if (attributes.contains("duration"))
		return attributes["duration"].toInt();
	else
		return -1;
}

QDateTime	QueueBreak::end() const
{
	if (attributes.contains("end"))
		return attributes["end"].toDateTime();
	else
		return QDateTime();
}

void		QueueBreak::setDuration(int duration)
{
	attributes["duration"] = duration;
	saveQueueAttributes();
}

void		QueueBreak::setEnd(QDateTime end)
{
	attributes["end"] = end;
	saveQueueAttributes();
}

QString		QueueBreak::message() const
{
	if (end().isValid())
		return QString(tr("Break until %1").arg(end().toString(tr("dddd hh:mm ap"))));
	else
		return QString(tr("Break during %1").arg(textDuration()));
}

bool		QueueBreak::queueIsFinite() const
{
	return (duration() > 0 || end().isValid());
}

int			QueueBreak::queueDuration(QDateTime from) const
{
	if (end().isValid())
		if (from.secsTo(end()) > 0)
			return from.secsTo(end());
		else
			return 0;
	else
		return duration();
}

QString		QueueBreak::queueType() const
{
	return "QueueBreak";
}

QString		QueueBreak::name() const
{
	return QString("QueueBreak(%1s)").arg(attributes["duration"].toString());
}

Queueable*	QueueBreak::clone() const
{
	QueueBreak	*instance = new QueueBreak();
	instance->attributes = attributes;
	return instance;
}
