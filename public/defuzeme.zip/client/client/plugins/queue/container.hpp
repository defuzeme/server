/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

namespace Queue {
	class Container;
}

#ifndef CONTAINER_HPP
#define CONTAINER_HPP

#include <QObject>
#include <deque>
#include "queueable.hpp"

namespace Queue
{
	/** This container class can bound together multiple Queueable elements.
	  * It allows to group tracks by playlist for example,
	  * in order to be able to operate on them all in one click.
	  *
	  * \attention It is not used yet
	  **/

	class Container : public QObject
	{
		Q_OBJECT
	public:
		explicit Container(QObject *parent = 0);
		unsigned				size() const;
		bool					empty() const;
		const QueueableDeque&	getChildren() const;

		virtual QString			name() const;					///< This virtual method should return a human-readable string describing the element

	signals:

	public slots:
	private:
		QueueableDeque			children;
	};
}

#endif // CONTAINER_HPP
