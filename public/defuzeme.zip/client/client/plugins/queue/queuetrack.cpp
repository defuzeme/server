/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "queuetrack.hpp"

using namespace Queue;

QueueTrack::QueueTrack(Library::AudioTrack &track) : track(track)
{
}

QueueTrack::~QueueTrack()
{}

Library::AudioTrack*	QueueTrack::getTrack() const
{
	return &track;
}

Library::AudioTrack*	QueueTrack::getTrack()
{
	return &track;
}

int			QueueTrack::queueDuration(QDateTime) const
{
	return track.getDuration();
}

QString		QueueTrack::queueType() const
{
	return "QueueTrack";
}

int			QueueTrack::queueId() const
{
	return track.getUid();
}

QVariantMap	QueueTrack::getContent(bool	forWeb) const
{
	QVariantMap	content;

	if (forWeb)
		content["uid"] = track.getUid();
	else
		content["id"] = track.getUid();
	content["title"] = track.getTitle();
	content["artist"] = track.getArtist();
	content["album_artist"] = track.getAlbumArtist();
	content["album"] = track.getAlbum();
	content["year"] = track.getYear();
	content["track"] = track.getTrack();
	content["genre"] = track.getGenre();
	content["duration"] = track.getDuration();
	return content;
}

Queueable*	QueueTrack::clone() const
{
	QueueTrack	*instance = new QueueTrack(track);
	instance->attributes = attributes;
	return instance;
}
