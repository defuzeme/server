/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

namespace Queue {
	class ControlsWidget;
}

#ifndef CONTROLSWIDGET_HPP
#define CONTROLSWIDGET_HPP

#include <QPropertyAnimation>
#include "ui_controlswidget.h"
#include "queueable.hpp"

namespace Queue
{
	/** The ControlsWidget class provide custom action buttons for play queue elements
	  * \attention It is not used since we moved to delegated display
	  **/
	class ControlsWidget : public QWidget, private Ui::ControlsWidget
	{
		Q_OBJECT

	public:
		explicit ControlsWidget(Queueable *parent);
		~ControlsWidget();
		void	dissapear();

	protected:
		void changeEvent(QEvent *e);
	private:
		QPropertyAnimation	*animation;
		Queueable			*queueable;
	};
}
#endif // CONTROLSWIDGET_HPP
