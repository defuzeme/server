/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "playqueuewidget.hpp"
#include "ui_playqueuewidget.h"
#include "playqueue.hpp"
#include "playqueuedelegate.hpp"
#include <QKeyEvent>
#include <QDebug>

using namespace Queue;

PlayQueueWidget::PlayQueueWidget(QAbstractItemModel *model) : Gui::ModuleWidget()
{
	setupUi(this);
	list->setModel(model);
	list->setItemDelegate(new PlayQueueDelegate(static_cast<PlayQueue*>(model)));
	connect(list, SIGNAL(focusOut()), SIGNAL(clearListFocus()));
}

PlayQueueWidget::~PlayQueueWidget()
{
}

void	PlayQueueWidget::setItemWidget(const QModelIndex &index, QWidget *widget)
{
	if (!list->indexWidget(index))
		list->setIndexWidget(index, widget);
}

QItemSelectionModel*	PlayQueueWidget::selectionModel() const
{
	return list->selectionModel();
}

void	PlayQueueWidget::keyReleaseEvent(QKeyEvent *event)
{
	if (event->matches(QKeySequence::Delete) || (event->key() == Qt::Key_Backspace))
	{
		emit deleteElements();
	}
	else
		QWidget::keyReleaseEvent(event);
}
