/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include <QDebug>
#include <QTimer>
#include "controlswidget.hpp"

using namespace Queue;

ControlsWidget::ControlsWidget(Queueable *parent) : /*QWidget(parent->getWidget()),*/ queueable(parent)
{
	setupUi(this);
	if (parent)
	{/*
		setMinimumHeight(parent->getWidget()->height());
		move(parent->getWidget()->width() - sizeHint().width(), 0);
		connect(deleteButton, SIGNAL(clicked()), parent, SLOT(remove()));
		show();

		animation = new QPropertyAnimation(this, "geometry");
		animation->setDuration(200);
		animation->setStartValue(QRect(parent->getWidget()->width(), 0, sizeHint().width(), minimumHeight()));
		animation->setEndValue(QRect(parent->getWidget()->width() - sizeHint().width(), 0, sizeHint().width(), minimumHeight()));
		animation->start();*/
	}
}

ControlsWidget::~ControlsWidget()
{
	delete animation;
}

void	ControlsWidget::dissapear()
{
/*	delete animation;
	animation = new QPropertyAnimation(this, "geometry");
	animation->setDuration(200);
	animation->setStartValue(QRect(queueable->getWidget()->width() - sizeHint().width(), 0, sizeHint().width(), minimumHeight()));
	animation->setEndValue(QRect(queueable->getWidget()->width(), 0, sizeHint().width(), minimumHeight()));
	animation->start();
	QTimer::singleShot(200, this, SLOT(deleteLater()));*/
}

void ControlsWidget::changeEvent(QEvent *e)
{
	QWidget::changeEvent(e);
	switch (e->type()) {
	case QEvent::LanguageChange:
		retranslateUi(this);
		break;
	default:
		break;
	}
}
