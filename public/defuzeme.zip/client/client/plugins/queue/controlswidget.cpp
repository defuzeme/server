/*******************************************************************************
**  defuze.me - modern radio automation software suite
**  
**  Copyright © 2012
**    Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**    Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
**  website: http://defuze.me
**  contact: team@defuze.me
**
**  This program is free software: you can redistribute it and/or modify it
**  under the terms of the GNU Lesser General Public License as published by
**  the Free Software Foundation, either version 3 of the License, or
**  (at your option) any later version.
**
**  This program is distributed in the hope that it will be useful,
**  but WITHOUT ANY WARRANTY; without even the implied warranty of
**  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
**  GNU Lesser General Public License for more details.
**
**  You should have received a copy of the GNU Lesser General Public License
**  along with this program.  If not, see <http://www.gnu.org/licenses/>.
**
**  This software includes code from Nokia (Qt) under the GNU LGPLv2.1
**  This software uses libraries from the FFmpeg project under the GNU LGPLv2.1
**  This software uses libraries from the TagLib project under the GNU LGPLv2.1
**
*******************************************************************************/

#include <QDebug>
#include <QTimer>
#include "controlswidget.hpp"

using namespace Queue;

ControlsWidget::ControlsWidget(Queueable *parent) : /*QWidget(parent->getWidget()),*/ queueable(parent)
{
	setupUi(this);
	if (parent)
	{/*
		setMinimumHeight(parent->getWidget()->height());
		move(parent->getWidget()->width() - sizeHint().width(), 0);
		connect(deleteButton, SIGNAL(clicked()), parent, SLOT(remove()));
		show();

		animation = new QPropertyAnimation(this, "geometry");
		animation->setDuration(200);
		animation->setStartValue(QRect(parent->getWidget()->width(), 0, sizeHint().width(), minimumHeight()));
		animation->setEndValue(QRect(parent->getWidget()->width() - sizeHint().width(), 0, sizeHint().width(), minimumHeight()));
		animation->start();*/
	}
}

ControlsWidget::~ControlsWidget()
{
	delete animation;
}

void	ControlsWidget::dissapear()
{
/*	delete animation;
	animation = new QPropertyAnimation(this, "geometry");
	animation->setDuration(200);
	animation->setStartValue(QRect(queueable->getWidget()->width() - sizeHint().width(), 0, sizeHint().width(), minimumHeight()));
	animation->setEndValue(QRect(queueable->getWidget()->width(), 0, sizeHint().width(), minimumHeight()));
	animation->start();
	QTimer::singleShot(200, this, SLOT(deleteLater()));*/
}

void ControlsWidget::changeEvent(QEvent *e)
{
	QWidget::changeEvent(e);
	switch (e->type()) {
	case QEvent::LanguageChange:
		retranslateUi(this);
		break;
	default:
		break;
	}
}
