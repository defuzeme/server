/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "container.hpp"

using namespace Queue;

Container::Container(QObject *parent) :
    QObject(parent)
{
}

unsigned	Container::size() const
{
	return children.size();
}

bool		Container::empty() const
{
	return children.empty();
}

const QueueableDeque&	Container::getChildren() const
{
	return children;
}

QString		Container::name() const
{
	// This generic method should be overriden to give more details
	return QString("Container<%1>").arg((qlonglong)this);
}
