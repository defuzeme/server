/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

namespace Queue {
	class QueueBreak;
}

#ifndef QUEUEBREAK_HPP
#define QUEUEBREAK_HPP

#include "queueable.hpp"
#include <QDateTime>

namespace Queue {

	/** This class inherits Queueable an represent a break in the play queue.
	  *
	  * It is used to pause the player at a determined time
	  **/

	class QueueBreak : public Queueable
	{
		Q_OBJECT
	public:
		QueueBreak();
		QueueBreak(int duration);
		QueueBreak(QDateTime end);
		~QueueBreak();
		int			duration() const;
		QDateTime	end() const;
		void		setDuration(int duration);
		void		setEnd(QDateTime end);
		QString		message() const;
		bool		queueIsFinite() const;
		int			queueDuration(QDateTime from) const;
		QString		queueType() const;
		QString		name() const;
		Queueable*	clone() const;
	signals:

	public slots:
	private:
	};
}

#endif // QUEUEBREAK_HPP
