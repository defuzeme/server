/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

class Plugin;

#ifndef PLUGIN_HPP
#define PLUGIN_HPP

#include <QObject>
#include "cores.hpp"
#include "plugins.hpp"
#include "guicore.hpp"
#include "dbcore.hpp"
#include "networkcore.hpp"
#include "audiocore.hpp"

/** Abstract class inherited by all PLUGINS.
  *
  * It contain 2 methods handling CORES PLUGINS and releasing.
  * - init() is called at start-up after all CORES and PLUGINS are loaded, contrary to the constructor.
  * - aboutToQuit() is called before quit, when all CORES and PLUGINS are still loaded, contrary to the destuctor.
  *
  **/

class Plugin
{
	friend class Plugins;
public:
	virtual			~Plugin();
	/** Called once, after all CORES and PLUGINS are loaded.
	  **/
	virtual void	init()=0;
	/** Called just before to quit, when CORES and PLUGINS are still loaded.
	  **/
	virtual void	aboutToQuit();

protected:
	/** Constructor is protected because you must not instanciate a plugin **/
	explicit		Plugin();

	Cores			*cores;
	Plugins			*plugins;

private:
	/** This method is automatically called by the Plugins class
	  * when adding the plugin to the list
	  **/
	void			setReferences(Cores &c, Plugins &p);
};

#endif // PLUGIN_HPP
