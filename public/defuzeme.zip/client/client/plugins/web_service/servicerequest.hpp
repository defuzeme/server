/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

namespace WebService {
	class ServiceRequest;
}

#ifndef SERVICEREQUEST_HPP
#define SERVICEREQUEST_HPP

#include <QObject>
#include <QNetworkRequest>
#include "servicesync.hpp"

namespace WebService
{
	class ServiceRequest : public QObject
	{
		Q_OBJECT
		friend class ServiceSync;

	public:
		void			enqueue();				///< Euqueue the request for sending
		void			setData(const QVariantMap& data);
		QVariant&		operator[](const QString& key);
		QVariant		operator[](const QString& key) const;

	signals:

	public slots:

	private:
		explicit ServiceRequest(ServiceSync	*ss, const QString& url);

		ServiceSync		*serviceSync;
		QString			url;
		QVariantMap		data;
		QByteArray		verb;
	};
}

#endif // SERVICEREQUEST_HPP
