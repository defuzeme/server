/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "servicerequest.hpp"

using namespace WebService;

ServiceRequest::ServiceRequest(ServiceSync	*ss, const QString& url) :
	serviceSync(ss), url(url)
{

}

void			ServiceRequest::setData(const QVariantMap& data)
{
	this->data = data;
}

QVariant&		ServiceRequest::operator[](const QString& key)
{
	return data[key];
}

QVariant		ServiceRequest::operator[](const QString& key) const
{
	return data[key];
}

void	ServiceRequest::enqueue()
{
	serviceSync->requests.push_back(this);
	serviceSync->sendNextRequest();
}
