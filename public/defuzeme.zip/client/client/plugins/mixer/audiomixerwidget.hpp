/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef AUDIOMIXERWIDGET_HPP
#define AUDIOMIXERWIDGET_HPP

#include "ui_audiomixerwidget.h"
#include "guicore.hpp"
#include "audioslicewidget.hpp"

namespace Mixer {
	class AudioMixerWidget : public Gui::ModuleWidget, private Ui::AudioMixerWidget
	{
		Q_OBJECT

	public:
		explicit AudioMixerWidget(QWidget *parent = 0);
		void	addSlice(AudioSliceWidget *sliceWidget);
	};
}

#endif // AUDIOMIXERWIDGET_HPP
