/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "audiomixerwidget.hpp"

using namespace Mixer;

AudioMixerWidget::AudioMixerWidget(QWidget *parent) :
	Gui::ModuleWidget(parent)
{
    setupUi(this);
}

void	AudioMixerWidget::addSlice(AudioSliceWidget *sliceWidget)
{
	layout()->addWidget(sliceWidget);
}
