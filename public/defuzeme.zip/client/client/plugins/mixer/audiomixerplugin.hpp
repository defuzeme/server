/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef AUDIOMIXERPLUGIN_HPP
#define AUDIOMIXERPLUGIN_HPP

#include "staticplugin.hpp"
#include "audiomixerwidget.hpp"
#include "audiomixer.hpp"
#include "audioslice.hpp"
#include <QMap>
#include <QList>

namespace Mixer
{
	class AudioMixerPlugin : public StaticPlugin
	{
	public:
		AudioMixerPlugin();
		~AudioMixerPlugin();
		void	init();
		void	refresh();
		void	refreshUI();

	private:
		AudioMixerWidget					*widget;
		Gui::Module							*uiModule;
		QMap<QString, AudioSlice*>			audioSlices;
		QList<Audio::AudioMixer*>	mixers;
	};
}

#endif // AUDIOMIXERPLUGIN_HPP
