/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "audioslicewidget.hpp"

AudioSliceWidget::AudioSliceWidget(QWidget *parent) :
	QWidget(parent)
{
	setupUi(this);
}

void	AudioSliceWidget::refreshUI()
{
	update();
}

void	AudioSliceWidget::setMixerName(const QString &name)
{
	 mixerNameLabel->setText(name);
}

void	AudioSliceWidget::addEffect(AudioEffectWidget *effectWidget)
{
	contentWidget->layout()->addWidget(effectWidget);
//	layout()->addWidget(effectWidget);
}
