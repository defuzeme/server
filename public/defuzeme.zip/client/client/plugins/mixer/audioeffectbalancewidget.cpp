/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "audioeffectbalancewidget.hpp"

AudioEffectBalanceWidget::AudioEffectBalanceWidget(Audio::AudioEffectBalance *effect, QWidget *parent) :
	AudioEffectWidget(effect, parent)
{
    setupUi(this);
}

void AudioEffectBalanceWidget::on_BalanceSlider_valueChanged(int value)
{
	static_cast<Audio::AudioEffectBalance*>(effect)->balance() = value;
}
