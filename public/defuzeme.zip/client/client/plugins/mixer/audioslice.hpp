/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef AUDIOSLICE_HPP
#define AUDIOSLICE_HPP

#include "staticplugin.hpp"
#include "audiomixer.hpp"
#include "audioslicewidget.hpp"

namespace Mixer
{
	class AudioSlice : public QObject
	{
	public:
		AudioSlice(Audio::AudioMixer *mixer);
		AudioSliceWidget *getWidget() const;
	private:
		Audio::AudioMixer	*mixer;
		AudioSliceWidget	*widget;
	};
}
#endif // AUDIOSLICE_HPP
