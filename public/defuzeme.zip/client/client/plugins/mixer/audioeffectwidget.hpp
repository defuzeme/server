/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef AUDIOEFFECTWIDGET_HPP
#define AUDIOEFFECTWIDGET_HPP

#include <QWidget>

namespace Audio
{
	class AudioEffect;
}

class AudioEffectWidget : public QWidget
{
    Q_OBJECT
public:

protected:
	explicit	AudioEffectWidget(Audio::AudioEffect *effect, QWidget *parent = 0);
	Audio::AudioEffect	*effect;

signals:

public slots:

private:
};

#endif // AUDIOEFFECTWIDGET_HPP
