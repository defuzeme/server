/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "audiomixerplugin.hpp"
#include <QDebug>

using namespace Mixer;

AudioMixerPlugin::AudioMixerPlugin()
{
	widget = new AudioMixerWidget();
	uiModule = Gui::ModuleFactory::create("Mixer", QPoint(2, 0), widget);
	//uiModule->setSizePolicy(QSizePolicy::Preferred, QSizePolicy::Maximum);
	uiModule->submitForDisplay();
}

AudioMixerPlugin::~AudioMixerPlugin()
{
	//delete slices
}

void	AudioMixerPlugin::refreshUI()
{
	foreach(AudioSlice *slice, audioSlices)
		slice->getWidget()->refreshUI();
}

void	AudioMixerPlugin::init()
{
/*	mixers = cores->audio()->getMixers();
	foreach(Audio::AudioMixer *mixer, mixers)
	{
		AudioSlice *slice = new AudioSlice(mixer);
		widget->addSlice(slice->getWidget());
		audioSlices.insert(mixer->getName(), slice);
		qDebug() << "add Slice for mixer: " << mixer->getName();
	}*/
}

void	AudioMixerPlugin::refresh()
{
	mixers = cores->audio()->getMixers();
	foreach(Audio::AudioMixer *mixer, mixers)
	{
		if (!audioSlices.contains(mixer->getName()))
		{
			AudioSlice *slice = new AudioSlice(mixer);
			widget->addSlice(slice->getWidget());
			audioSlices.insert(mixer->getName(), slice);
			qDebug() << "add Slice for mixer: " << mixer->getName();
		}
	}
}
