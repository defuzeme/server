/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef VUMETER_HPP
#define VUMETER_HPP

#include "ui_vumeter.h"

class VUMeter : public QWidget, private Ui::VUMeter
{
	Q_OBJECT

public:
	explicit VUMeter(QWidget *parent = 0);
	void		setLevels(double left, double right);

protected:
	void changeEvent(QEvent *e);
};

#endif // VUMETER_HPP
