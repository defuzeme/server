/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef VUMETERDISPLAY_HPP
#define VUMETERDISPLAY_HPP

#include <QGLWidget>
#include <QMutex>

class VUMeterDisplay : public QWidget
{
	Q_OBJECT

public:
	VUMeterDisplay(QWidget *parent = 0);
	void		setLevel(double level);
/*	void		initializeGL();
	void		resizeGL(int w, int h);
	void		paintGL();*/
	void		paintEvent(QPaintEvent *);
	void		resizeEvent(QResizeEvent *);

signals:

public slots:

private slots:
	void		refresh();

private:
	double			level;
	double			peak;
	int				peakDuration;
	QPainter		painter;
	QLinearGradient	gradient;
	QMutex			mutex;
};

#endif // VUMETERDISPLAY_HPP
