/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "audioslice.hpp"

using namespace Mixer;

AudioSlice::AudioSlice(Audio::AudioMixer *mixer) : mixer(mixer)
{
	widget = new AudioSliceWidget();
	widget->setMixerName(mixer->getName());
	foreach(Audio::AudioEffect *effect, mixer->getEffects())
	{
		AudioEffectWidget *w = effect->getWidget();
		widget->addEffect(w);
	}
}

AudioSliceWidget	*AudioSlice::getWidget() const
{
	return widget;
}
