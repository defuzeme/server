/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef AUDIOSLICEWIDGET_HPP
#define AUDIOSLICEWIDGET_HPP

#include "ui_audioslicewidget.h"
#include "audioeffectwidget.hpp"

class AudioSliceWidget : public QWidget, private Ui::AudioSliceWidget
{
	Q_OBJECT

public:
	explicit AudioSliceWidget(QWidget *parent = 0);
	void	refreshUI();
	void	setMixerName(const QString& name);
	void	setOutputName(const QString& name);
	void	addEffect(AudioEffectWidget*effectWidget);
};

#endif // AUDIOSLICEWIDGET_HPP
