/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef AUDIOEFFECTVOLUMEWIDGET_HPP
#define AUDIOEFFECTVOLUMEWIDGET_HPP

#include "ui_audioeffectvolumewidget.h"
#include "audioeffectwidget.hpp"
#include "audioeffectvolume.hpp"

class AudioEffectVolumeWidget : public AudioEffectWidget, private Ui::AudioEffectVolumeWidget
{
	Q_OBJECT

	public:
		explicit AudioEffectVolumeWidget(Audio::AudioEffectVolume *effect, QWidget *parent = 0);
		void	setLevels(double left, double right);
	signals:
		void	volumeSlider_moved(int position);
public slots:
		void	setVolume(int volume);
	private slots:
		void on_muteButton_clicked();
		void on_volumeSlider_valueChanged(int position);

	private:
		bool	_isMuted;
};

#endif // AUDIOEFFECTVOLUMEWIDGET_HPP
