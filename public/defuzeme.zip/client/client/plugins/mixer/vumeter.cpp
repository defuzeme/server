/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "vumeter.hpp"
#include <QDebug>

VUMeter::VUMeter(QWidget *parent) :
    QWidget(parent)
{
    setupUi(this);
}

void	VUMeter::setLevels(double left, double right)
{
	l_level->setLevel(left);
	r_level->setLevel(right);
}

void VUMeter::changeEvent(QEvent *e)
{
	QWidget::changeEvent(e);
	switch (e->type()) {
		case QEvent::LanguageChange:
			retranslateUi(this);
			break;
		default:
			break;
	}
}
