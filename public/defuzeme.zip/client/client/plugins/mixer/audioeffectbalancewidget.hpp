/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef AUDIOEFFECTBALANCEWIDGET_HPP
#define AUDIOEFFECTBALANCEWIDGET_HPP

#include "ui_audioeffectbalancewidget.h"
#include "audioeffectwidget.hpp"
#include "audioeffectbalance.hpp"

class AudioEffectBalanceWidget : public AudioEffectWidget, private Ui::AudioEffectBalanceWidget
{
    Q_OBJECT

public:
	explicit AudioEffectBalanceWidget(Audio::AudioEffectBalance *effect, QWidget *parent = 0);
private slots:
	void on_BalanceSlider_valueChanged(int value);
};

#endif // AUDIOEFFECTBALANCEWIDGET_HPP
