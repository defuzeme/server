/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

class Plugins;

#ifndef PLUGINS_HPP
#define PLUGINS_HPP

#include <QObject>
#include <QHash>
#include "plugin.hpp"

/** Strucure storing references to all plugins.
  * It also contains some conveniant methods.
  **/

class Plugins : public QObject
{
	Q_OBJECT
public:
	explicit Plugins(Cores* c);
	~Plugins();
	void			init();										///< Call all plugins init() method.
	void			add(const QString& name, Plugin* plugin);	///< Add a plugin to the list of loaded plugins
	Plugin*			get(const QString& name);					///< Return the desired plugin
	template<class T> T*	cast(const QString& name) {
		return dynamic_cast<T*>(get(name));
	}

signals:
	void			message(const QString& msg);
public slots:
	void			aboutToQuit();								///< Call all plugins aboutToQuit() method.

private:
	Cores					&cores;
	QHash<QString, Plugin*>	plugins;
};

#endif // PLUGINS_HPP
