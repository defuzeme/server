/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

class StaticPlugin;

#ifndef STATICPLUGIN_HPP
#define STATICPLUGIN_HPP

#include "plugin.hpp"

class StaticPlugin : public Plugin
{
public:

protected:
	/** Constructor is protected because you must not instanciate a plugin **/
	explicit StaticPlugin();

private:
};

#endif // STATICPLUGIN_HPP
