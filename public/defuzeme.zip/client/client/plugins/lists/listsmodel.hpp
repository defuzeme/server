/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2012
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef LISTSMODEL_HPP
#define LISTSMODEL_HPP

#include "editabletreemodel.hpp"
#include "listsitem.hpp"
#include <QHash>
#include <QItemSelectionModel>

namespace Lists
{
	class ListsPlugin;

	class ListsModel : public EditableTreeModel
	{
		Q_OBJECT
	public:
		enum DropAction {
			INVALID_DROP_ACTION,
			ADD_TO_NORMAL_PLAYLIST,
			ADD_TO_DYNAMIC_PLAYLIST,
			CREATE_NORMAL_PLAYLIST,
			CREATE_DYNAMIC_PLAYLIST
		};

		ListsModel(ListsPlugin *lists);
		~ListsModel();
		void setupModelData();
		ListsItem *getRootItem() const;
		QStringList getDropTypesForItem(ListsItem *item) const;
		DropAction getDropActionsForItem(ListsItem *item, const QString &mimeType = "default") const;

		bool insertRows(int position, int rows, const QModelIndex &parent);
		bool dropMimeData(const QMimeData *data, Qt::DropAction action, int row, int column, const QModelIndex &parent);
		QMimeData *mimeData(const QModelIndexList &indexes) const;
		Qt::ItemFlags flags(const QModelIndex &index) const;
		QVariant data(const QModelIndex &index, int role) const;
		ListsItem *getItem(const QModelIndex &index) const;

		ListsItem *normalItem;
		ListsItem *dynamicItem;
		QModelIndex lastDropIndex;

	public slots:
		void dataHaveChanged(const QModelIndex & topLeft, const QModelIndex & bottomRight);
		void dataDeleted();

	signals:
		void playlistContentChanged(int playlistId);
		void playlistNameChanged(int playlistId, QString newName);
		void playlistRemoved(int playlistId);

	private:
		ListsItem *insertCategoryItem(const QString &title, ListsItem::SubKind subKind, int position = 0);
		ListsItem *insertAddItem(const QString &title, ListsItem::SubKind subKind);
		ListsItem *insertDynamicList(const QMimeData *data, ListsItem *parentItem);
		ListsItem *insertNormalList(const QMimeData *data, ListsItem *parentItem);

		ListsItem *insertIntroItem(ListsItem *parentItem);
		ListsItem *insertSeparatorItem(ListsItem::SubKind subKind, ListsItem *parentItem);
		void insertParametersInDynamicList(const QMimeData *data, ListsItem *parentItem);
		void insertParametersInNormalList(const QMimeData *data, ListsItem *parentItem);
		void removeList(const QModelIndex &listIndex);
		void removeSeparatorFromList(const QModelIndex &separatorIndex);
		void removeParameterFromList(const QModelIndex &parameterIndex);

		void updateDBFromTree(ListsItem *list) const;
		void updateTreeFromDB();
		bool hasAction(ListsItem *item, const QStringList &formats, DropAction action);

		ListsPlugin *lists;
		QHash<ListsItem*, QStringList> dropTypesForItem;
		QHash<ListsItem*, QHash<QString, DropAction> > dropActionsForItem;
	};

}

#endif // LISTSMODEL_HPP
