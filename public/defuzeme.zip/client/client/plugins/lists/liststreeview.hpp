/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2012
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef LISTSTREEVIEW_HPP
#define LISTSTREEVIEW_HPP

#include <QTreeView>
#include <QDragMoveEvent>

namespace Lists
{
	class ListsPlugin;

	class ListsTreeView : public QTreeView
	{
		Q_OBJECT
	public:
		explicit ListsTreeView(QWidget *parent = 0);
		void	dragEnterEvent(QDragEnterEvent *event);
		void	dragMoveEvent(QDragMoveEvent *event);
		void dropEvent(QDropEvent *event);
		void keyReleaseEvent(QKeyEvent *event);
		void setListsPlugin(ListsPlugin *lists);

	signals:
		void deleteElements();

	public slots:
	private:
		ListsPlugin *lists;

	};

}

#endif // LISTSTREEVIEW_HPP
