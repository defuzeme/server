/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2012
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "listsdelegate.hpp"
#include "listsitem.hpp"
#include "editabletreeitem.hpp"
#include <QPainter>
#include <QApplication>
#include <QLineEdit>

using namespace Lists;

ListsDelegate::ListsDelegate(QObject *parent) : QStyledItemDelegate(parent)
{
	editorRegEpx = new QRegExp("\\S.{1,99}");
}

QSize ListsDelegate::sizeHint(const QStyleOptionViewItem &option, const QModelIndex &index) const
{
	Q_UNUSED(index);
	int height = 2;

	return QSize(200, QFontMetrics(option.font).height() * height);
}

void ListsDelegate::paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const
{
	painter->save();

	ListsItem *item = static_cast<ListsItem*>(index.internalPointer());
	//EditableTreeItem *item = static_cast<EditableTreeItem*>(index.internalPointer());

	// Draw background when selected
	if (option.state & QStyle::State_Selected)
		painter->fillRect(option.rect, option.palette.highlight());

	// Draw shadows
	painter->setPen(QColor(255, 255, 255, 20));
	painter->drawLine(QPoint(0, option.rect.top()), option.rect.topRight());
	painter->setPen(QColor(0, 0, 0, 60));
	painter->drawLine(QPoint(0, option.rect.bottom()), option.rect.bottomRight());
	// Set text mode
	if (option.state & QStyle::State_Selected)
		painter->setPen(option.palette.highlightedText().color());
	else
		painter->setPen(option.palette.foreground().color());


	// Set the title font
	QFont	font(option.font.family());

	QRect	titleRect = option.rect.adjusted(31, 0, -31, 0);
	QRect	pixmapRect = QRect(option.rect.left(), option.rect.top() + (option.rect.height() - 22) / 2, 22, 22);

	font.setPointSize(11);
	painter->setFont(font);

	painter->fillRect(pixmapRect, QColor(255,255,255,51));

	font.setPointSize(13);
	painter->setFont(font);
	// Draw Title
	painter->drawText(titleRect, Qt::AlignLeft | Qt::AlignVCenter, item->data(0).toString());

	painter->restore();
}

QWidget *ListsDelegate::createEditor(QWidget *parent, const QStyleOptionViewItem &/* option */, const QModelIndex &/* index */) const
{
	QLineEdit *editor = new QLineEdit(parent);
	editor->setValidator(new QRegExpValidator(*editorRegEpx, 0));
	return editor;
}

void ListsDelegate::setEditorData(QWidget *editor, const QModelIndex &index) const
{
	QString value = index.model()->data(index, Qt::EditRole).toString();

	QLineEdit *lineEdit = static_cast<QLineEdit*>(editor);
	lineEdit->setText(value);
}

void ListsDelegate::setModelData(QWidget *editor, QAbstractItemModel *model, const QModelIndex &index) const
{
	QLineEdit *lineEdit = static_cast<QLineEdit*>(editor);
	QString value = lineEdit->text();

	model->setData(index, value, Qt::EditRole);
}

void ListsDelegate::updateEditorGeometry(QWidget *editor, const QStyleOptionViewItem &option, const QModelIndex &/* index */) const
{
	editor->setGeometry(option.rect);
}
