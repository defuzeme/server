/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2012
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "listsitem.hpp"
#include "listsmodel.hpp"
#include <QDebug>

using namespace Lists;

ListsItem::ListsItem(const QString &title, QPixmap icon, ListsModel *model, EditableTreeItem *parent)
	: EditableTreeItem(title, parent), icon(icon), model(model)
{
	id = 0;
}

bool ListsItem::insertChildren(int position, int count, int columns)
{
	Q_UNUSED(columns)

	if (position < 0 || position > childItems.size())
		return false;

	for (int row = 0; row < count; ++row) {
		ListsItem *item = new ListsItem("", QPixmap(), model, this);
		childItems.insert(position, item);
	}

	return true;
}

ListsItem *ListsItem::child(int number)
{
	return static_cast<ListsItem*>(childItems.value(number));
}

ListsItem::Kind ListsItem::getKind() const
{
	return kind;
}

ListsItem::SubKind ListsItem::getSubKind() const
{
	return subKind;
}

void ListsItem::setKind(ListsItem::Kind kind)
{
	this->kind = kind;
}

void ListsItem::setSubKind(ListsItem::SubKind subKind)
{
	this->subKind = subKind;
}

ListsModel *ListsItem::getModel() const
{
	return model;
}

bool ListsItem::isOfKind(Kind _kind)
{
	if (kind == _kind)
		return true;
	return false;
}

bool ListsItem::isOfKind(Kind _kind, SubKind _subKind)
{
	if (kind == _kind && subKind == _subKind)
		return true;
	return false;
}

unsigned int ListsItem::getId() const
{
	return id;
}

void ListsItem::setId(unsigned int id)
{
	this->id = id;
}
