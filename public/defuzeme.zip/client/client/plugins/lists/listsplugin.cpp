/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2012
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "listsplugin.hpp"

using namespace Lists;

ListsPlugin::ListsPlugin()
{
}

ListsPlugin::~ListsPlugin()
{
}

void ListsPlugin::init()
{
	widget = new ListsWidget(this);
	model = new ListsModel(this);
	widget->getTreeViewWidget()->setModel(model);
	Gui::Module *listsModule = Gui::ModuleFactory::create("lists", QPoint(2, 0), widget);
	listsModule->submitForDisplay();
}

void ListsPlugin::aboutToQuit()
{
	delete model;
	delete widget;
}

ListsWidget *ListsPlugin::getWidget() const
{
	return widget;
}

ListsModel *ListsPlugin::getModel() const
{
	return model;
}

QMap<int, QString> ListsPlugin::getPlaylists(bool dynamic)
{
	QSqlQuery query;
	QMap<int, QString> listsMap;

	query.prepare("SELECT id, name FROM playlists WHERE is_dynamic = :dynamic");
	query.bindValue(":dynamic", dynamic);
	query.exec();
	while (query.next())
		listsMap[query.value(0).toInt()] = query.value(1).toString();
	return listsMap;
}

QMap<int, QString> ListsPlugin::getNormalPlaylists()
{
	return getPlaylists(false);
}

QMap<int, QString> ListsPlugin::getDynamicPlaylists()
{
	return getPlaylists(true);
}

QList<int> ListsPlugin::getTracksForNormalPlaylist(int id)
{
	QSqlQuery query;

	query.prepare("SELECT definition FROM playlists WHERE id = :id");
	query.bindValue(":id", id);
	query.exec();

	QList<int> tracksList;
	if (query.next())
	{
		QList<QVariant> data = Network::JsonParser().parse(query.value(0).toByteArray()).toList();
		foreach (QVariant trackId, data)
			tracksList << trackId.toInt();
	}
	return tracksList;
}
