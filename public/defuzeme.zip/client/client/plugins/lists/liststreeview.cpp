/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2012
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "liststreeview.hpp"
#include "listsplugin.hpp"

using namespace Lists;

ListsTreeView::ListsTreeView(QWidget *parent) :
	QTreeView(parent)
{
}

void	ListsTreeView::dragEnterEvent(QDragEnterEvent *event)
{
	if (event->mimeData()->hasFormat("application/x-defuzeme-audiotrack")
			|| event->mimeData()->hasFormat("application/x-defuzeme-artist")
			|| event->mimeData()->hasFormat("application/x-defuzeme-genre")
			|| event->mimeData()->hasFormat("application/x-defuzeme-album"))
		event->accept();
	else
		event->ignore();

}

void	ListsTreeView::dragMoveEvent(QDragMoveEvent *event)
{
	QModelIndex idx = indexAt(event->pos());

	if (!idx.isValid())
	{
		event->ignore();
		return;
	}
	ListsItem *item = static_cast<ListsItem*>(idx.internalPointer());

	foreach (QString format, event->mimeData()->formats())
	{
		if (lists->getModel()->getDropTypesForItem(item).contains(format, Qt::CaseInsensitive))
		{
			event->accept();
			return;
		}
	}
	event->ignore();
}

void ListsTreeView::dropEvent(QDropEvent *event)
{
	lists->getModel()->lastDropIndex = indexAt(event->pos());
	QTreeView::dropEvent(event);
}

void	ListsTreeView::keyReleaseEvent(QKeyEvent *event)
{
	if (event->matches(QKeySequence::Delete) /*|| (event->key() == Qt::Key_Backspace)*/)
	{
		emit deleteElements();
	}
	else
		QWidget::keyReleaseEvent(event);
}

void ListsTreeView::setListsPlugin(ListsPlugin *lists)
{
	this->lists = lists;
}
