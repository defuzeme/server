/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2012
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef LISTSDELEGATE_HPP
#define LISTSDELEGATE_HPP

#include <QStyledItemDelegate>
#include <QRegExpValidator>

namespace Lists
{

	class ListsDelegate : public QStyledItemDelegate
	{
	public:
		ListsDelegate(QObject *parent = 0);
		QSize	sizeHint(const QStyleOptionViewItem &option, const QModelIndex &index) const;
		void	paint(QPainter *painter, const QStyleOptionViewItem &option, const QModelIndex &index) const;

		QWidget *createEditor(QWidget *parent, const QStyleOptionViewItem &option, const QModelIndex &index) const;
		void setEditorData(QWidget *editor, const QModelIndex &index) const;
		void setModelData(QWidget *editor, QAbstractItemModel *model, const QModelIndex &index) const;
		void updateEditorGeometry(QWidget *editor, const QStyleOptionViewItem &option, const QModelIndex &index) const;

	private:
		QRegExp *editorRegEpx;
	};

}

#endif // LISTSDELEGATE_HPP
