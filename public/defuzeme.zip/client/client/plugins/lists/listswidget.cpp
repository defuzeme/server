/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2012
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "listswidget.hpp"
#include "listsdelegate.hpp"
#include "listsplugin.hpp"

using namespace Lists;

ListsWidget::ListsWidget(ListsPlugin *lists, QWidget *parent) :
	ModuleWidget(parent), lists(lists)
{
	setupUi(this);

	QPalette palette;
	palette.setColor(QPalette::Background, QColor::fromRgb(132,130,128));
	palette.setColor(QPalette::Base, QColor::fromRgb(192,192,192));
	palette.setColor(QPalette::AlternateBase, QColor::fromRgb(177,177,177));

	treeView->setListsPlugin(lists);
	treeView->setPalette(palette);
	treeView->setHeaderHidden(true);
	treeView->setItemDelegate(new ListsDelegate);
	treeView->itemDelegate()->setParent(this);
	QObject::connect(treeView, SIGNAL(clicked(const QModelIndex &)), this, SLOT(toogleItem(QModelIndex)));
}

ListsTreeView *ListsWidget::getTreeViewWidget() const
{
	return treeView;
}

void ListsWidget::toogleItem(const QModelIndex &index)
{
	if (treeView->isExpanded(index))
		treeView->collapse(index);
	else
		treeView->expand(index);
}

void ListsWidget::changeEvent(QEvent *e)
{
	QWidget::changeEvent(e);
	switch (e->type()) {
	case QEvent::LanguageChange:
		retranslateUi(this);
		break;
	default:
		break;
	}
}
