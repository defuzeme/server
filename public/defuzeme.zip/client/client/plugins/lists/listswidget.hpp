/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2012
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef LISTSWIDGET_HPP
#define LISTSWIDGET_HPP

#include "ui_listswidget.h"
#include "guicore.hpp"


namespace Lists
{
	class ListsPlugin;

	class ListsWidget : public Gui::ModuleWidget, private Ui::ListsWidget
	{
		Q_OBJECT

	public:
		explicit	ListsWidget(ListsPlugin *lists, QWidget *parent = 0);
		ListsTreeView	*getTreeViewWidget() const;

	public slots:
		void		toogleItem(const QModelIndex &index);

	protected:
		void		changeEvent(QEvent *e);
		ListsPlugin *lists;
	};

}

#endif // LISTSWIDGET_HPP
