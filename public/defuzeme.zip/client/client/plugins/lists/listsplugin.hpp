/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2012
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef LISTSPLUGIN_HPP
#define LISTSPLUGIN_HPP

#include "staticplugin.hpp"
#include "listswidget.hpp"
#include "listsmodel.hpp"

namespace Lists
{

	class ListsPlugin : public StaticPlugin
	{
	public:
		ListsPlugin();
		~ListsPlugin();
		void init();
		void aboutToQuit();
		ListsWidget *getWidget() const;
		ListsModel *getModel() const;

		static QMap<int, QString> getNormalPlaylists();
		static QMap<int, QString> getDynamicPlaylists();
		static QList<int> getTracksForNormalPlaylist(int id);

	private:
		static QMap<int, QString> getPlaylists(bool dynamic);

		ListsWidget *widget;
		ListsModel *model;
	};

}

#endif // LISTSPLUGIN_HPP
