/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "cores.hpp"
#include "starter.hpp"
#include "audiocore.hpp"
#include "audiodecoder.hpp"
#include "defuzemeapplication.hpp"
#include <QtGui/QApplication>
#include <QTranslator>

int main(int argc, char *argv[])
{
	DefuzemeApplication app(argc, argv);

	QTranslator translator;
	translator.load("defuzeme_" + QLocale::system().name(), "translations");
	app.installTranslator(&translator);

	Starter *starter = new Starter();

	Cores *cores = starter->loadCores();
	Plugins *plugins = starter->loadPlugins();
	delete starter;

	if (!cores || !plugins)
		return 1;

	QObject::connect(&app, SIGNAL(aboutToQuit()), plugins, SLOT(aboutToQuit()));
	QObject::connect(&app, SIGNAL(aboutToQuit()), cores, SLOT(aboutToQuit()));

	int out = app.exec();
	return out;
}
