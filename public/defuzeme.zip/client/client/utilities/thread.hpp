/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef THREAD_HPP
#define THREAD_HPP

#include <QThread>
#include "exception.hpp"

/**
  * This class implements out-of-thread exception forwarding mechanism
  * It should be use in place of QThread and programmer may call forward() during thread execution.
  **/

class Thread : public QThread
{
	Q_OBJECT
public:
	explicit Thread(QObject *parent = 0);
	void		forward(const Exception &exc);

signals:
	void		forwardSig(const Exception &exc);

public slots:

private slots:
	void		raise(const Exception& exc);
};

#endif // THREAD_HPP
