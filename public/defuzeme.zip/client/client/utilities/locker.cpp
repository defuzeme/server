/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "locker.hpp"
#include "exception.hpp"

Locker::Locker()
{
}

Locker::~Locker()
{
}

void Locker::setLock(const QString &flag)
{
	if (flags.contains(flag))
		flags[flag] += 1;
	else
		flags[flag] = 1;
}

void Locker::unLock(const QString &flag)
{
	if (flags.contains(flag))
		flags[flag] -= 1;
	else
		flags[flag] = 0;
}

bool Locker::isLocked(const QString &flag) const
{
	if (flags.contains(flag))
		return (flags[flag] != 0);
	else
		return false;
}

void Locker::assertNotLocked(const QString &flag) const
{
	if (isLocked(flag))
		throw_exception(0x01, QObject::tr("Ressource '%1' is locked.").arg(flag));
}
