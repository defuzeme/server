/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef DEFUZEMEAPPLICATION_HPP
#define DEFUZEMEAPPLICATION_HPP

#include <QApplication>
#include "exception.hpp"

class DefuzemeApplication : public QApplication
{
	Q_OBJECT
public:
	DefuzemeApplication(int& argc, char** argv);
	virtual ~DefuzemeApplication();
	virtual bool	notify(QObject *receiver, QEvent *event);

signals:
	void			forwardException(const Exception& e);

private slots:
	void			displayException(const Exception& e) throw();

private:
	QTimer			speedControl;
};

#endif // DEFUZEMEAPPLICATION_HPP
