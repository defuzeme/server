/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2012
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef EDITABLETREEITEM_HPP
#define EDITABLETREEITEM_HPP

#include <QList>
#include <QVariant>
#include <QVector>
#include <QModelIndex>

class EditableTreeItem
{
public:
	EditableTreeItem(const QVector<QVariant> &data, EditableTreeItem *parent = 0);
	EditableTreeItem(const QString &title, EditableTreeItem *parent = 0);
	~EditableTreeItem();

	EditableTreeItem *child(int number);
	int childCount() const;
	int columnCount() const;
	QVariant data(int column) const;
	bool insertChildren(int position, int count, int columns);
	bool insertColumns(int position, int columns);
	EditableTreeItem *parent();
	bool removeChildren(int position, int count);
	bool removeColumns(int position, int columns);
	int childNumber() const;
	bool setData(int column, const QVariant &value);

	QModelIndex index;

protected:
	QList<EditableTreeItem*> childItems;
	QVector<QVariant> itemData;
	EditableTreeItem *parentItem;
};

#endif // EDITABLETREEITEM_HPP
