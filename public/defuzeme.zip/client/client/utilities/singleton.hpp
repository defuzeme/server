/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef SINGLETON_HPP
#define SINGLETON_HPP

/** Singleton template class
  *
  * Meyers' singletons, as define here : http://fr.wikipedia.org/wiki/Singleton_(patron_de_conception)#C.2B.2B.
  * \warning May not be thead-safe.
  **/

template<typename T> class Singleton
{
public:
	static T& instance()
	{
		static T _instance;
		return _instance;
	}
};

#endif // SINGLETON_HPP
