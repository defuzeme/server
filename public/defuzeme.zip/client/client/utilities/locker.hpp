/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef LOCKER_HPP
#define LOCKER_HPP

#include <QString>
#include <QHash>

class Locker
{
public:
	Locker();
	~Locker();
	void setLock(const QString &flag);
	void unLock(const QString &flag);
	bool isLocked(const QString &flag) const;
	void assertNotLocked(const QString &flag) const;

private:
	QHash<const QString, unsigned short> flags;
};

#endif // LOCKER_HPP
