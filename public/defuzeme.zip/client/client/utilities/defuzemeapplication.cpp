/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "defuzemeapplication.hpp"
#include "logger.hpp"
#include <QDebug>
#include <QMessageBox>
#include <QTimer>

DefuzemeApplication::DefuzemeApplication(int &argc, char **argv) :
	QApplication(argc, argv)
{
	qRegisterMetaType<Exception>("Exception");
	connect(this, SIGNAL(forwardException(Exception)), SLOT(displayException(Exception)));
}

DefuzemeApplication::~DefuzemeApplication()
{
}

bool	DefuzemeApplication::notify(QObject *receiver, QEvent *event)
{
	try
	{
		return QApplication::notify(receiver, event);
	}
	catch (Exception &e)
	{
		qDebug() << "APP: " << e.description();
		emit forwardException(e);
	}
	return false;
}

void	DefuzemeApplication::displayException(const Exception& e) throw()
{
	if (!speedControl.isActive())
	{
		speedControl.setSingleShot(true);
		speedControl.start(5000);
		QMessageBox::critical(NULL, "defuze.me", "An fatal error occurred while running defuze.me.<br><i>" +
							  e.msg() + " (error " + e.hexCode() +
							  ")</i><br><br>Get online support about this error <a href='http://defuze.me/support/errors/" +
							  e.hexCode() + "'>here</a>.");
	}
}
