/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#ifndef CLEARABLELINEEDIT_HPP
#define CLEARABLELINEEDIT_HPP

#include <QLineEdit>
#include <QToolButton>

class ClearableLineEdit : public QLineEdit
{
	Q_OBJECT
public:
	explicit	ClearableLineEdit(QWidget *parent = 0);

protected:
	void		resizeEvent(QResizeEvent *);

private slots:
	void		updateCloseButton(const QString &text);

private:
	QToolButton	*clearButton;
};

#endif // CLEARABLELINEEDIT_HPP
