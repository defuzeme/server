/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010-2011
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "thread.hpp"

Thread::Thread(QObject *parent) :
	QThread(parent)
{
	qRegisterMetaType<Exception>("Exception");
	connect(this, SIGNAL(forwardSig(const Exception &)), SLOT(raise(const Exception &)));
}

void	Thread::forward(const Exception &exc)
{
	emit forwardSig(exc);
}

void	Thread::raise(const Exception& exc)
{
	throw exc;
}
