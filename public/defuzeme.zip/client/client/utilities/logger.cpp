/**************************************************************************
** defuze.me Epitech Innovative Project
**
** Copyright 2010
**   Athena Calmettes - Jocelyn De La Rosa - Francois Gaillard
**   Adrien Jarthon - Alexandre Moore - Luc Peres - Arnaud Sellier
**
** All rights reserved.
**************************************************************************/

#include "logger.hpp"
#include <QtCore/QString>
#include <QtCore/QDateTime>
#include <QtCore/QDir>
#include <QDebug>

Logger::Logger()
{
	QDir dir;
	dir.mkpath(QDesktopServices::storageLocation(QDesktopServices::DataLocation) + gl_MAIN_LOG_DIR);// Create the logs directory if needed.
	logFile = new QFile(logFileName());
	if (logFile->open(QIODevice::WriteOnly | QIODevice::Append | QIODevice::Text))
	{
		qDebug() << "Log file is" << QFileInfo(*logFile).absoluteFilePath();
		logFile->write(logHeader());
	}
	else
	{
		qDebug() << "Cannot use Log file" << QFileInfo(*logFile).absoluteFilePath() << ": error" << logFile->error();
	}
}

Logger::~Logger()
{
	logFile->close();
	delete logFile;
}

void Logger::log(const QString &message)
{
	Logger::instance().updateLog(message);
}

void Logger::updateLog(QString msg) const
{
	msg += "\n";
	msg = ". " + msg;
	if (logFile->isOpen())
	{
		logFile->write(msg.toAscii());
		logFile->flush();
	}
}

QByteArray Logger::logHeader() const
{
	QString header(80, '#');
	header += "\n";
	return header.toAscii();
}

QString Logger::logFileName() const
{
	return QDesktopServices::storageLocation(QDesktopServices::DataLocation) + gl_MAIN_LOG_DIR +
			"/" + gl_MAIN_LOG_FILE + "_" +
			QDateTime::currentDateTime().toString("yyyyMMdd") + "." + gl_MAIN_LOG_EXT;
}
